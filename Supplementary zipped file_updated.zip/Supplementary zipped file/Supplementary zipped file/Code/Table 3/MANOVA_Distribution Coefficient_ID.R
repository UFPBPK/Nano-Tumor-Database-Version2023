library(dplyr)

data <- readRDS("AUC_total_0811.RDS")
data <- data[,27:33]
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data)

data.log <- data %>% mutate(log.DE_liver = log(AUC_liver/AUC.plasma, 10),
                            log.DE_heart = log(AUC_heart/AUC.plasma, 10),
                            log.DE_spleen = log(AUC_spleen/AUC.plasma, 10),
                            log.DE_kidney = log(AUC_kidney/AUC.plasma, 10),
                            log.DE_lung  = log(AUC_lung/AUC.plasma, 10))


organ.Type <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Particle.Type, data = data.log)
summary(organ.Type)   # Particle Type is a significant predictor, p = 0.03684 *
summary.aov(organ.Type)   #Liver: 0.2703; Heart: 0.4342; Spleen: 0.02493*, Kidney: 0.6252; Lung: 0.4157

organ.MAT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ material, data = data.log)
summary(organ.MAT)    # Materials is a significant predictor, p = 3.105e-06***
summary.aov(organ.MAT)   #Liver: 0.004687**; Heart: 0.06448; Spleen: 1.693e-05***, Kidney: 0.000695***; Lung: 0.02914

organ.TS <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Targeting.Strategy, data = data.log)
summary(organ.TS)     # Targeting strategy is not a significant predictor, p = 0.2749
summary.aov(organ.TS)   #Liver: 0.8589; Heart:0.9844; Spleen: 0.9694, Kidney: 0.2286; Lung: 0.9696

organ.CT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Cancer, data = data.log)
summary(organ.CT)     # Cancer is a significant predictor, p = 2.787e-09***
summary.aov(organ.CT)   #Liver: 0.002077**; Heart: 0.0008071**; Spleen: 2.867e-06***, Kidney: 0.001148**; Lung: 0.0003215***

organ.TM <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Tumor.Model, data = data.log)
summary(organ.TM)     # Tumor model is a significant predictor, p = 0.0233*
summary.aov(organ.TM)   #Liver: 0.9356; Heart: 0.9519; Spleen: 0.5679, Kidney: 0.9257; Lung: 0.6195

organ.shape <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ NM.Shape, data = data.log)
summary(organ.shape)     # Shape is a significant predictor, p = 4.935e-05 ***
summary.aov(organ.shape)   #Liver: 0.000652 ***; Heart: 0.08779 ; Spleen: 0.0009202***, Kidney: 0.07908; Lung: 0.005314 **

organ.HD <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ HD.category, data = data.log)
summary(organ.HD)     # HD category is a significant predictor, p = 0.0002049 ***
summary.aov(organ.HD)   #Liver: 0.02282*; Heart: 0.09292; Spleen: 0.01392*, Kidney: 0.1184; Lung: 0.02067*

organ.SC <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Surface.Charge, data = data.log)
summary(organ.SC)     # Surface charge is not a significant predictor, p = 0.1483
summary.aov(organ.SC)   #Liver: 0.3378; Heart: 0.2538; Spleen: 0.2952, Kidney: 0.1089; Lung: 0.3013


