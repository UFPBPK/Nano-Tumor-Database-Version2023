library(ggplot2)
library(dplyr)
library(RColorBrewer)
library(stringr)
library(ggpubr)

data <- readRDS("Delivery efficiency_IDg.RDS")
info <- readRDS("nano info.RDS")
data <- cbind.data.frame(info, data)

median.DE <- median(data$DE_tumor)
mean.DE <- mean(data$DE_tumor)
#The box and whisker plot of DE by year
DE.year <- data %>% 
  group_by(Category = Year) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE))

res <- wilcox.test(DE_tumor ~ Data.source, data = data, exact = FALSE)
res

old <- data %>% filter(Data.source == 1)
new <- data %>% filter(Data.source == 2)
medians <- data %>% group_by(Data.source) %>% summarize(median = median(DE_tumor), na.rm = TRUE)

DE.year.cat <- data %>% mutate(Year.category = cut(Year, breaks = c(0, 2010, 2016, Inf), labels = c("2005-2009", "2010-2015", "2016-2021"), include.lowest = TRUE, na.rm = TRUE))
DE.year.sum <- DE.year.cat %>% 
  group_by(Category = Year.category) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE))


getPalette <- colorRampPalette(brewer.pal(9, "Spectral"))

p1 <- ggplot()+
  geom_boxplot(stat = "identity", data  = DE.year,
               aes(x = Category, ymin = bottom, lower = lower, middle = Median, upper = upper, ymax = top, group = Category, fill = factor(Category)), width = 0.6)+
  scale_fill_manual(values = getPalette(17))+
  #scale_fill_manual(values = c("cornflowerblue","orange","red2","black","forestgreen","darkblue","tan4","indianred1","darkolivegreen4","magenta","tan3","lightsalmon","yellowgreen","firebrick4","mediumorchid1","moccasin","seagreen1"))+
  scale_y_continuous(trans = "log10", labels = function(x) format(x, scientific = FALSE, drop0trailing = TRUE))+
  expand_limits(y = c(0,100))+
  geom_hline(yintercept = median.DE, linetype = "dashed", color = "blue")+
  ylab("Delivery efficiency (%ID/g)")+
  xlab("")+
  theme_bw()+ #white background
  ggtitle("A. Year")+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        panel.border = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 16, family = "serif"),
        axis.text.x = element_text(size = 16, family = "serif"),
        plot.title = element_text(size = 22, family = "serif", vjust = 3),
        plot.title.position = "plot")+
  theme(legend.position = "none")



ggsave("DE_Year_AUC_IDg.tiff",scale = 1,
       plot = p1,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 20, height = 10, units = "cm",dpi=320)

#The plot of DE by nanoparticle type: Inorganic, Organic and hybrid

DE.Pt <- data %>% 
  group_by(Category = Particle.Type) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE))

p2 <- ggplot()+
  geom_boxplot(stat = "identity", data  = DE.Pt,
               aes(x = Category, ymin = bottom, lower = lower, middle = Median, upper = upper, ymax = top, group = Category, fill = factor(Category)),
               width = 0.6, alpha = 0.9)+
  scale_x_discrete(limits = c("Organic","Inorganic","Hybrid"))+
  scale_fill_brewer(palette = "Spectral")+
  #scale_fill_manual(values = c("cornflowerblue","orange","red2","black","forestgreen","darkblue","tan4","indianred1","darkolivegreen4","magenta","tan3","lightsalmon","yellowgreen","firebrick4","mediumorchid1","moccasin","seagreen1"))+
  scale_y_continuous(trans = "log10", labels = function(x) format(x, scientific = FALSE, drop0trailing = TRUE),breaks = c(0.01,0.1,1,10,100))+
  expand_limits(y = c(0,100))+
  geom_hline(yintercept = median.DE, linetype = "dashed", color = "blue")+
  #ylab("Delivery efficiency (%ID/g)")+
  ylab("")+
  xlab("")+
  theme_bw()+ #white background
  ggtitle("B. Material")+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        panel.border = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 16, family = "serif"),
        axis.text.x = element_text(size = 16, family = "serif"),
        plot.title = element_text(size = 22, family = "serif", vjust = 3),
        plot.title.position = "plot")+
  theme(legend.position = "none")

ggsave("DE_Particle type_AUC_IDg.tiff",scale = 1,
       plot = p2,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 8, height = 10, units = "cm",dpi=320)

# The plot of DE by targeting strategy: passive and active

DE.TS <- data %>% 
  group_by(Category = Targeting.Strategy) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE))


p3 <- ggplot()+
  geom_boxplot(stat = "identity", data  = DE.TS,
               aes(x = Category, ymin = bottom, lower = lower, middle = Median, upper = upper, ymax = top, group = Category, fill = factor(Category)),
               width = 0.6)+
  scale_fill_manual(values = c("#FDAE61","#ABDDA4"))+
  scale_y_continuous(trans = "log10", labels = function(x) format(x, scientific = FALSE, drop0trailing = TRUE))+
  expand_limits(y = c(0,100))+
  geom_hline(yintercept = median.DE, linetype = "dashed", color = "blue")+
  #ylab("Delivery efficiency (%ID/g)")+
  ylab("")+
  xlab("")+
  theme_bw()+ #white background
  ggtitle("C. Targeting Strategy")+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        panel.border = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 16, family = "serif"),
        axis.text.x = element_text(size = 16, family = "serif"),
        plot.title = element_text(size = 22, family = "serif", vjust = 3),
        plot.title.position = "plot")+
  theme(legend.position = "none")

ggsave("DE_Targeting Strategy_AUC_IDg.tiff",scale = 1,
       plot = p3,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 6, height = 10, units = "cm",dpi=320)

# The plot of DE by surface charge

DE.SC <- data %>% 
  filter(!is.na(Surface.Charge))%>%
  group_by(Category = Surface.Charge) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE))


p4 <- ggplot()+
  geom_boxplot(stat = "identity", data  = DE.SC,
               aes(x = Category, ymin = bottom, lower = lower, middle = Median, upper = upper, ymax = top, group = Category, fill = factor(Category)),
               width = 0.6, alpha = 0.9)+
  scale_fill_brewer(palette = "Spectral")+
  scale_y_continuous(trans = "log10", labels = function(x) format(x, scientific = FALSE, drop0trailing = TRUE))+
  expand_limits(y = c(0,100))+
  geom_hline(yintercept = median.DE, linetype = "dashed", color = "blue")+
  ylab("Delivery efficiency (%ID/g)")+
  xlab("")+
  theme_bw()+ #white background
  ggtitle("D. Surface Charge")+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        panel.border = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 16, family = "serif"),
        axis.text.x = element_text(size = 16, family = "serif"),
        plot.title = element_text(size = 22, family = "serif", vjust = 3),
        plot.title.position = "plot")+
  theme(legend.position = "none")

ggsave("DE_Surface Charge.tiff_AUC_IDg.tiff",scale = 1,
       plot = p4,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 8, height = 10, units = "cm",dpi=320)

# The plot of DE by Cancer type

data <- data %>% mutate(Cancer = recode(Cancer.type,
                                        "Brain"  = "Brain",
                                        "Breast" = "Breast",
                                        "Cervix" = "Cervix",
                                        "Colon"  = "Colon",
                                        "Glioma" = "Glioma",
                                        "Liver"  = "Liver",
                                        "Lung"   = "Lung",
                                        "Ovary"  = "Ovary",
                                        "Pancreas" = "Pancreas",
                                        "Prostate" = "Prostate",
                                        "Sarcoma"= "Sarcoma",
                                        "Skin"   = "Skin",
                                        .default = "Others"))

DE.cancer <- data %>% 
  group_by(Category = Cancer) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE))


DE.cancer$Category <- factor(DE.cancer$Category, levels = c("Brain", "Breast", "Cervix", "Colon", "Glioma", "Liver", "Lung", "Ovary", "Pancreas", "Prostate", "Sarcoma", "Skin", "Others"))

p5 <- ggplot()+
  geom_boxplot(stat = "identity", data  = DE.cancer,
               aes(x = Category, ymin = bottom, lower = lower, middle = Median, upper = upper, ymax = top, group = Category, fill = factor(Category)),width = 0.8)+
  scale_fill_manual(values = getPalette(13))+
  scale_y_continuous(trans = "log10", labels = function(x) format(x, scientific = FALSE, drop0trailing = TRUE), breaks = c(0.01,0.1,1,10,100))+
  expand_limits(y = c(0,100))+
  geom_hline(yintercept = median.DE, linetype = "dashed", color = "blue")+
  #ylab("Delivery efficiency (%ID)")+
  ylab("")+
  xlab("")+
  theme_bw()+ #white background
  ggtitle("J. Cancer Type")+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        panel.border = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.y = element_text(size = 16, family = "serif"),
        axis.text.x = element_text(size = 14, family = "serif"),
        plot.title = element_text(size = 22, family = "serif", vjust = 3),
        plot.title.position = "plot")+
  theme(legend.position = "none")

ggsave("DE_Cancer type_AUC_IDg.tiff",scale = 1,
       plot = p5,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 20, height = 10, units = "cm",dpi=320)

# The plot of DE by Shape
data <- data %>% mutate(NM.Shape = recode(NM.Shape, 
                                          "Rod" = "Rod",
                                          "Spherical" = "Spherical",
                                          "Plate" = "Plate",
                                          .default = "Others"))
DE.shape <- data %>% 
  group_by(Category = NM.Shape) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE))

DE.shape$Category <- factor(DE.shape$Category, levels = c("Spherical", "Rod", "Plate", "Others"))

p6 <- ggplot()+
  geom_boxplot(stat = "identity", data  = DE.shape,
               aes(x = Category, ymin = bottom, lower = lower, middle = Median, upper = upper, ymax = top, group = Category, fill = factor(Category)),
               width = 0.6)+
  scale_fill_brewer(palette = "Spectral")+
  scale_y_continuous(trans = "log10", labels = function(x) format(x, scientific = FALSE, drop0trailing = TRUE))+
  expand_limits(y = c(0,100))+
  geom_hline(yintercept = median.DE, linetype = "dashed", color = "blue")+
  ylab("Delivery efficiency (%ID/g)")+
  xlab("")+
  theme_bw()+ #white background
  ggtitle("H. Shape")+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        panel.border = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 16, family = "serif"),
        axis.text.x = element_text(size = 16, family = "serif"),
        plot.title = element_text(size = 22, family = "serif", vjust = 3),
        plot.title.position = "plot")+
  theme(legend.position = "none")

ggsave("DE_Shape_AUC_IDg.tiff",scale = 1,
       plot = p6,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 12, height = 10, units = "cm",dpi=320)


#The plot of DE by tumor model

DE.TM <- data %>% 
  group_by(Category = Tumor.Model) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE))

p7 <- ggplot()+
  geom_boxplot(stat = "identity", data  = DE.TM,
               aes(x = Category, ymin = bottom, lower = lower, middle = Median, upper = upper, ymax = top, group = Category, fill = factor(Category)),
               width = 0.6)+
  scale_fill_brewer(palette = "Spectral")+
  scale_y_continuous(trans = "log10", labels = function(x) format(x, scientific = FALSE, drop0trailing = TRUE))+
  expand_limits(y = c(0,100))+
  scale_x_discrete(labels = function(x) str_wrap(x, width = 10))+
  geom_hline(yintercept = median.DE, linetype = "dashed", color = "blue")+
  ylab("Delivery efficiency (%ID/g)")+
  xlab("")+
  theme_bw()+ #white background
  ggtitle("I. Tumor Model")+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        panel.border = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 16, family = "serif"),
        axis.text.x = element_text(size = 16, family = "serif"),
        plot.title = element_text(size = 22, family = "serif", vjust = 3),
        plot.title.position = "plot")+
  theme(legend.position = "none")

ggsave("DE_tumor model_AUC_IDg.tiff",scale = 1,
       plot = p7,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 12, height = 10, units = "cm",dpi=320)

# The plot of DE in inorganic nanoparticles

DE.INM <- data %>% 
  filter(Particle.Type == "Inorganic")%>%
  group_by(Category = INM.category) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE))


DE.INM[3,1] <- "Others"

DE.INM$Category <- factor(DE.INM$Category, levels = c("Gold", "Iron Oxide", "Silica", "Others"))


p8 <- ggplot()+
  geom_boxplot(stat = "identity", data  = DE.INM,
               aes(x = Category, ymin = bottom, lower = lower, middle = Median, upper = upper, ymax = top, group = Category, fill = factor(Category)),
               width = 0.6)+
  scale_fill_brewer(palette = "Spectral")+
  scale_y_continuous(trans = "log10", labels = function(x) format(x, scientific = FALSE, drop0trailing = TRUE))+
  expand_limits(y = c(0,100))+
  geom_hline(yintercept = median.DE, linetype = "dashed", color = "blue")+
  ylab("")+
  #ylab("Delivery efficiency (%ID/g)")+
  xlab("")+
  theme_bw()+ #white background
  ggtitle("E. Inorganic Material")+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        panel.border = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 16, family = "serif"),
        axis.text.x = element_text(size = 16, family = "serif"),
        plot.title = element_text(size = 22, family = "serif", vjust = 3),
        plot.title.position = "plot")+
  theme(legend.position = "none")

ggsave("DE_INM_AUC_IDg.tiff",scale = 1,
       plot = p8,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 16, height = 10, units = "cm",dpi=320)


# The plot of DE for ONM

data <- data %>% mutate(ONM.category = recode(Organic.Material,
                                              "Polymeric" = "Polymeric",
                                              "Dendrimer" = "Dendrimer",
                                              "Liposome"  = "Liposome",
                                              "Hydrogel"  = "Hydrogel",
                                              .default    = "ONM others"))
DE.ONM <- data %>% 
  filter(Particle.Type == "Organic")%>%
  group_by(Category = ONM.category) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE))

DE.ONM[4,1] <- "Others"

DE.ONM$Category <- factor(DE.ONM$Category, levels = c("Polymeric", "Dendrimer", "Hydrogel", "Liposome", "Others"))

p9 <- ggplot()+
  geom_boxplot(stat = "identity", data  = DE.ONM,
               aes(x = Category, ymin = bottom, lower = lower, middle = Median, upper = upper, ymax = top, group = Category, fill = factor(Category)),
               width = 0.6)+
  scale_fill_brewer(palette = "Spectral")+
  scale_y_continuous(trans = "log10", labels = function(x) format(x, scientific = FALSE, drop0trailing = TRUE))+
  expand_limits(y = c(0,100))+
  geom_hline(yintercept = median.DE, linetype = "dashed", color = "blue")+
  #ylab("Delivery efficiency (%ID/g)")+
  ylab("")+
  xlab("")+
  theme_bw()+ #white background
  ggtitle("F. Organic Material")+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        panel.border = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 16, family = "serif"),
        axis.text.x = element_text(size = 16, family = "serif"),
        plot.title = element_text(size = 22, family = "serif", vjust = 3),
        plot.title.position = "plot")+
  theme(legend.position = "none")

ggsave("DE_ONM_AUC_IDg.tiff",scale = 1,
       plot = p9,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 16, height = 10, units = "cm",dpi=320)

# The plot of DE by hydrodynamic size

data <- data %>%  
  mutate(HD.category = cut(NM.Hydrodnamic.Size.nm., breaks = c(0,10,100,200,Inf), labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))

DE.HD <- data %>% 
  filter(!is.na(HD.category))%>%
  group_by(Category = HD.category) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE))

DE.HD$Category <- factor(DE.HD$Category, levels = c("<10", "10-100", "100-200", ">200"))

p10 <- ggplot()+
  geom_boxplot(stat = "identity", data  = DE.HD,
               aes(x = Category, ymin = bottom, lower = lower, middle = Median, upper = upper, ymax = top, group = Category, fill = factor(Category)),
               width = 0.6)+
  scale_fill_brewer(palette = "Spectral")+
  scale_y_continuous(trans = "log10", labels = function(x) format(x, scientific = FALSE, drop0trailing = TRUE))+
  expand_limits(y = c(0,100))+
  geom_hline(yintercept = median.DE, linetype = "dashed", color = "blue")+
  #ylab("Delivery efficiency (%ID/g)")+
  ylab("")+
  xlab("")+
  theme_bw()+ #white background
  ggtitle("G. Hydrodynamic Diameter")+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        panel.border = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 16, family = "serif"),
        axis.text.x = element_text(size = 16, family = "serif"),
        plot.title = element_text(size = 22, family = "serif", vjust = 3),
        plot.title.position = "plot")+
  theme(legend.position = "none")

ggsave("DE_HD_AUC_IDg.tiff",scale = 1,
       plot = p10,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 12, height = 10, units = "cm",dpi=320)


C1 <- ggarrange(p1,p2,p3,
                ncol = 3, nrow = 1, widths = c(10, 4, 3))+
  theme(plot.margin = margin(1,1,1,1,"cm"))

C2 <- ggarrange(p4, p8, p9, p10, ncol = 4, nrow = 1, widths = c(3, 4, 5, 4)) + 
  theme(plot.margin = margin(0.1,1,1,1,"cm"))

C3 <- ggarrange(p6, p7+rremove("ylab"), p5, ncol = 3, nrow = 1, widths = c(2.5, 3, 6)) +
  theme(plot.margin = margin(0.1,1,1,1,"cm"))

C4 <- ggarrange(C1, C2, C3, ncol = 1, nrow = 3)

ggsave("Combination 1.tiff",scale = 1,
       plot = C1,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 55, height = 12, units = "cm",dpi=320)

ggsave("Combination 2.tiff",scale = 1,
       plot = C2,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 55, height = 12, units = "cm",dpi=320)

ggsave("Combination 3.tiff",scale = 1,
       plot = C3,
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 55, height = 12, units = "cm",dpi=320)

ggsave("DE_AUC_IDg.tiff", scale = 1, plot = C4, 
       path = "C:/Users/chenqiran/Desktop/Nano data analysis/AUC_IDg",
       width = 55, height = 45, units = "cm", dpi = 320)


Summary <- rbind.data.frame(DE.year.sum, DE.TS,
                            DE.Pt, DE.INM,
                            DE.ONM, DE.shape,
                            DE.HD, DE.SC,
                            DE.TM, DE.cancer)
Summary <- Summary %>% mutate_if(is.numeric, round, 2)
write.csv(Summary, "Summary results_AUC_IDg.csv")

