library(dplyr)
library(PKNCA)
library(tidyr)


data <- read.csv("R dataset_0713.csv",header=TRUE)
Dataset.no <- na.omit(data[,39])
data <- data %>% fill(Dataset.No.)

#AUC calculation based on ID%
AUC <- matrix(NA, nrow = length(Dataset.no), ncol = 6)
DE.AUC <- matrix(NA, ncol = 6, nrow = length(Dataset.no))

for(i in 1: length(Dataset.no)){

  dataset <- data[data$Dataset.No. == i,23:35]
  colnames(dataset) <- c("time","tumor_IDg","tumor_ID","heart_IDg", "heart_ID",
                         "liver_IDg", "liver_ID","spleen_IDg", "spleen_ID", "lung_IDg",
                         "lung_ID", "kidney_IDg", "kidney_ID")
  time <- c(0, as.numeric(dataset$time))
  tumor_ID  <- c(0, as.numeric(dataset$tumor_ID))
  heart_ID  <- c(0, as.numeric((dataset$heart_ID)))
  liver_ID  <- c(0, as.numeric(dataset$liver_ID))
  spleen_ID <- c(0, as.numeric(dataset$spleen_ID))
  lung_ID   <- c(0, as.numeric(dataset$lung_ID))
  kidney_ID <- c(0, as.numeric(dataset$kidney_ID))
  
  AUC.tumor  <- pk.calc.auc(conc = tumor_ID, time = time)
  AUC.heart  <- pk.calc.auc(conc = heart_ID, time = time)
  AUC.liver  <- pk.calc.auc(conc = liver_ID, time = time)
  AUC.spleen <- pk.calc.auc(conc = spleen_ID, time = time)
  AUC.lung   <- pk.calc.auc(conc = lung_ID, time = time)
  AUC.kidney <- pk.calc.auc(conc = kidney_ID, time = time)
  
  DE.tumor  <- AUC.tumor/tail(time, 1)
  DE.heart  <- AUC.heart/tail(time, 1)
  DE.liver  <- AUC.liver/tail(time, 1)
  DE.spleen <- AUC.spleen/tail(time, 1)
  DE.lung   <- AUC.lung/tail(time, 1)
  DE.kidney <- AUC.kidney/tail(time, 1)
  
  AUC[i,] <- c(AUC.tumor, AUC.heart, AUC.liver, AUC.spleen, AUC.lung, AUC.kidney)
  DE.AUC[i,] <- c(DE.tumor, DE.heart, DE.liver, DE.spleen, DE.lung, DE.kidney)
  print(i)
}
colnames(DE.AUC) <- c("DE_tumor", "DE_heart", "DE_liver", "DE_spleen", "DE_lung", "DE_kidney")
colnames(AUC) <- c("AUC_tumor", "AUC_heart", "AUC_liver", "AUC_spleen", "AUC_lung", "AUC_kidney")
DE.AUC[DE.AUC == 0] <-NA
AUC[AUC == 0] <- NA

write.csv(DE.AUC,"Delivery efficiency_AUC.csv")
write.csv(AUC, "AUC_ID_0811.csv")
saveRDS(AUC, "AUC_ID_0811.RDS")


