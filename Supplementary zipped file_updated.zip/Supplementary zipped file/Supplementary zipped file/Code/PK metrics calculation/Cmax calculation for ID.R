library(PKNCA)
library(tidyr)

data <- read.csv("R dataset_0713.csv",header=TRUE)
Dataset.no <- na.omit(data[,39])
data <- data %>% fill(Dataset.No.)

Cmax <- matrix(NA, nrow = length(Dataset.no), ncol = 6)

for(i in 1: length(Dataset.no)){

  dataset <- data[data$Dataset.No. == i,23:35]
  colnames(dataset) <- c("time","tumor_IDg","tumor_ID","heart_IDg", "heart_ID",
                         "liver_IDg", "liver_ID","spleen_IDg", "spleen_ID", "lung_IDg",
                         "lung_ID", "kidney_IDg", "kidney_ID")
  Cmax[i,] <- c(Cmax.tumor = pk.calc.cmax(dataset$tumor_ID),
                Cmax.heart = pk.calc.cmax(dataset$heart_ID),
                Cmax.liver = pk.calc.cmax(dataset$liver_ID),
                Cmax.spleen = pk.calc.cmax(dataset$spleen_ID),
                Cmax.lung = pk.calc.cmax(dataset$lung_ID),
                Cmax.kidney = pk.calc.cmax(dataset$kidney_ID))
}
colnames(Cmax) <-c("Cmax.tumor","Cmax.heart","Cmax.liver","Cmax.spleen","Cmax.lung","Cmax.kidney")
saveRDS(Cmax, file = "Cmax results.RDS")

