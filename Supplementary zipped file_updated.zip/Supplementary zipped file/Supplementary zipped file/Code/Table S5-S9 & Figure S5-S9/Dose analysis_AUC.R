library(dplyr)
library(ggplot2)
library(ggpubr)
data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
AUC_IDg <- readRDS("Delivery efficiency_IDg.RDS")
AUC_IDg <- as.data.frame(AUC_IDg)
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data[2:7])
data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))
data <- read.csv("nano new data.csv", header = TRUE) # in this version, the dose was convert to numeric
data <- data %>% mutate(log.DE_tumor = log10(DE_tumor), 
                        log.DE_heart = log10(DE_heart),
                        log.DE_liver = log10(DE_liver),
                        log.DE_spleen = log10(DE_spleen),
                        log.DE_lung  = log10(DE_lung),
                        log.DE_kidney = log10(DE_kidney))
dose <- as.numeric(data$Dose)

#Table S5: the correlation between dose and delivery efficiency using method 1 in the unit of %ID

cor.tumor.ID <- cor(dose, data$log.DE_tumor, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.heart.ID <- cor(dose, data$log.DE_heart, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.liver.ID <- cor(dose, data$log.DE_liver, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.spleen.ID <- cor(dose, data$log.DE_spleen, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.lung.ID <- cor(dose, data$log.DE_lung, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.kidney.ID <- cor(dose, data$log.DE_kidney, use = "complete.obs", method = c("pearson", "kendall","spearman"))

#Figure S5. linear regression of dose and delivery efficiency
reg <- lm(log.DE_tumor~ dose, data  = data)
#get intercept and slope value
coeff<-coefficients(reg)          
intercept<-coeff[1]
slope<- coeff[2]

p1.All<- ggplot()+
  geom_abline(intercept = intercept, slope = slope, color="red", linewidth = 1)+
  geom_point(data =data, aes(x = dose, y = log.DE_tumor), shape = 21, fill = "darkgreen", color = "black")+
  scale_x_continuous(trans = "log10")+
  xlab("")+
  ylab("")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 14, margin = margin(t = 20)),
        axis.title.y = element_text(family = "serif",size = 12),
        axis.text.y = element_text(size = 12, family = "serif", face = "bold"),
        axis.text.x = element_text(size = 12, family = "serif"),
        plot.title = element_text(size = 12, family = "serif"))+
  annotate("text",x = 7E-9, y = 1.7, label = "All NPs")

INM <- data %>%  filter(Particle.Type == "Inorganic")
ONM <- data %>%  filter(Particle.Type == "Organic")
Polymer <- ONM %>%  filter(Organic.Material == "Polymeric")
Gold <- INM %>%  filter(Inorganic.Material == "Gold")

INM <- INM %>% mutate(dose = as.numeric(Dose), na.rm = TRUE)
reg.INM <- lm(log.DE_tumor~ dose, data  = INM)
summary(reg.INM)
coeff.INM <- coefficients(reg.INM)          
intercept.INM <- coeff.INM[1]
slope.INM <- coeff.INM[2]

p.INM <- ggplot()+
  geom_abline(intercept = intercept.INM, slope = slope.INM, color = "red", linewidth = 1)+
  geom_point(data = INM, aes(x = dose, y = log.DE_tumor), shape = 21, fill = "darkgreen", color = "black")+
  scale_x_continuous(trans = "log10")+
  xlab("")+
  ylab("")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 14, margin = margin(t = 20)),
        axis.title.y = element_text(family = "serif",size = 12),
        axis.text.y = element_text(size = 12, family = "serif", face = "bold"),
        axis.text.x = element_text(size = 12, family = "serif"),
        plot.title = element_text(size = 12, family = "serif"))+
  annotate("text",x = 1E-8, y = 1.7, label = "INMs")

ONM <- ONM %>% mutate(dose = as.numeric(Dose), na.rm = TRUE)
reg.ONM <- lm(log.DE_tumor~ dose, data  = ONM)
summary(reg.ONM)
coeff.ONM <- coefficients(reg.ONM)          
intercept.ONM <- coeff.ONM[1]
slope.ONM <- coeff.ONM[2]

p.ONM <- ggplot()+
  geom_abline(intercept = intercept.ONM, slope = slope.ONM, color = "red", linewidth = 1)+
  geom_point(data = ONM, aes(x = dose, y = log.DE_tumor), shape = 21, fill = "darkgreen", color = "black")+
  scale_x_continuous(trans = "log10", limits = c(10^-5,10^3))+
  xlab("")+
  ylab("")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 14, margin = margin(t = 20)),
        axis.title.y = element_text(family = "serif",size = 12),
        axis.text.y = element_text(size = 12, family = "serif", face = "bold"),
        axis.text.x = element_text(size = 12, family = "serif"),
        plot.title = element_text(size = 12, family = "serif"))+
  annotate("text",x = 1.5E-5, y = 1.7, label = "ONMs")

Gold <- Gold %>% mutate(dose = as.numeric(Dose), na.rm = TRUE)
reg.Gold <- lm(log.DE_tumor~ dose, data  = Gold)
summary(reg.Gold)
coeff.Gold <- coefficients(reg.Gold)          
intercept.Gold <- coeff.Gold[1]
slope.Gold <- coeff.Gold[2]

p.Gold <- ggplot()+
  geom_abline(intercept = intercept.Gold, slope = slope.Gold, color="red", linewidth = 1)+
  geom_point(data = Gold, aes(x = dose, y = log.DE_tumor), shape = 21, fill = "darkgreen", color = "black")+
  scale_x_continuous(trans = "log10")+
  xlab("")+
  ylab("")+
  theme_bw()+
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 14, margin = margin(t = 20)),
        axis.title.y = element_text(family = "serif",size = 12),
        axis.text.y = element_text(size = 12, family = "serif", face = "bold"),
        axis.text.x = element_text(size = 12, family = "serif"),
        plot.title = element_text(size = 12, family = "serif"))+
  annotate("text",x = 3E-9, y = 1.7, label = "Gold NPs")

p.combined <- ggarrange(p1.All, p.ONM, p.INM, p.Gold, ncol = 2, nrow = 2)
  
p.combd <- annotate_figure(p.combined, left = text_grob(expression(log[10]~"DE"), rot = 90, family = "serif", size = 16),
                bottom = text_grob("Dose (mg/kg)", family = "serif", size = 16))

p <- p.combd + theme(plot.margin = unit(c(1,1,1,1), "cm"))


ggsave("Tumor_Dose_ID.tiff", scale = 1,
       plot = p,
       path = "C:/Users/chenqiran/Desktop",
       width = 35, height = 28, units = "cm", dpi = 320)


#Figure S6
data <- data %>% mutate(Dose.category = cut(dose, breaks = c(0, 1E-4,1E-3,1E-2,0.1, 1, 10, 100, Inf), labels = c("1E-4", "1E-3","1E-2", "0.1","1","10","100",">100"),include.lowest = TRUE, na.rm = TRUE))

DE.dose <- data %>% 
  group_by(Category = Dose.category) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE),
            N = length(DE_tumor), na.rm = TRUE)
DE.dose$Category <- c("<0.01","0.01","0.1","1","10","100",">100", "Unknown")
DE.dose$Category <- factor(DE.dose$Category, levels = c("<0.01","0.01","0.1","1","10","100",">100", "Unknown"))

Median.DE <- 0.67
p.Dose <- ggplot()+
  geom_bar(stat = "identity", data  = DE.dose,
               aes(x = Category, y = Median, group = Category, fill = factor(Category)),
               width = 0.6)+
  scale_fill_brewer(palette = "Spectral")+
#  geom_errorbar(data = DE.dose, aes(x = Category, ymin = Median, ymax = top), width = 0.2)
#  scale_y_continuous(trans = "log10", labels = function(x) format(x, scientific = FALSE, drop0trailing = TRUE))+
#  expand_limits(y = c(0,100))+
  geom_hline(yintercept = Median.DE, linetype = "dashed", color = "blue")+
  ylab("Delivery efficiency (%ID)")+
  xlab("Dose")+
  theme_bw()+ #white background
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 14, family = "serif"),
        axis.text.x = element_text(size = 14, family = "serif"),
        plot.title = element_text(size = 22, family = "serif", vjust = 3),
        plot.title.position = "plot")+
  theme(legend.position = "none")

ggsave("tumor_dose ANOVA_ID.tiff", scale = 1,
       plot = p.Dose,
       path = "C:/Users/chenqiran/Desktop",
       width = 15, height = 10, units = "cm", dpi = 320)


#Table S6: the pairwise comparison in Method 1 with the unit of %ID

res.Dose <- bartlett.test(log.DE_tumor ~ Dose.category, data = data)
res.Dose
fit_Dose <- aov(log.DE_tumor ~ Dose.category, data = data)
summary(fit_Dose)
pairwise.wilcox.test(data$log.DE_tumor, data$Dose.category, p.adjust.method = "BH")


#The results of method 1 in the unit of %ID/g
AUC_IDg <- AUC_IDg %>% mutate(log.DE_tumor = log10(DE_tumor), 
                              log.DE_heart = log10(DE_heart),
                              log.DE_liver = log10(DE_liver),
                              log.DE_spleen = log10(DE_spleen),
                              log.DE_lung  = log10(DE_lung),
                              log.DE_kidney = log10(DE_kidney))
AUC_IDg <- cbind.data.frame(AUC_IDg, dose)


#Table S5: the correlation between dose and administration dose using method 1 in the unit of %ID/g
cor.tumor.IDg <- cor(dose, AUC_IDg$log.DE_tumor, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.heart.IDg <- cor(dose, AUC_IDg$log.DE_heart, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.liver.IDg <- cor(dose, AUC_IDg$log.DE_liver, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.spleen.IDg <- cor(dose, AUC_IDg$log.DE_spleen, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.lung.IDg <- cor(dose, AUC_IDg$log.DE_lung, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.kidney.IDg <- cor(dose, AUC_IDg$log.DE_kidney, use = "complete.obs", method = c("pearson", "kendall","spearman"))

reg_IDg <- lm(log.DE_tumor~dose, data  = AUC_IDg)
#get intercept and slope value
coeff<-coefficients(reg_IDg)          
intercept<-coeff[1]
slope<- coeff[2]

# Figure S9: ANOVA of dose groups
AUC_IDg <- AUC_IDg %>% mutate(Dose.category = cut(dose, breaks = c(0, 1E-4,1E-3,1E-2,0.1, 1, 10, 100, Inf), labels = c("1E-4", "1E-3","1E-2", "0.1","1","10","100",">100"),include.lowest = TRUE, na.rm = TRUE))

DE.dose_IDg <- AUC_IDg %>% 
  group_by(Category = Dose.category) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE),
            N = length(DE_tumor), na.rm = TRUE)
DE.dose_IDg$Category <- c("<0.01","0.01","0.1","1","10","100",">100", "Unknown")
DE.dose_IDg$Category <- factor(DE.dose_IDg$Category, levels = c("<0.01","0.01","0.1","1","10","100",">100", "Unknown"))

Median.DE_IDg <- 3.45
p.Dose_IDg <- ggplot()+
  geom_bar(stat = "identity", data  = DE.dose_IDg,
           aes(x = Category, y = Median, group = Category, fill = factor(Category)),
           width = 0.6)+
  scale_fill_brewer(palette = "Spectral")+
  #  geom_errorbar(data = DE.dose, aes(x = Category, ymin = Median, ymax = top), width = 0.2)
  #  scale_y_continuous(trans = "log10", labels = function(x) format(x, scientific = FALSE, drop0trailing = TRUE))+
  #  expand_limits(y = c(0,100))+
  geom_hline(yintercept = Median.DE_IDg, linetype = "dashed", color = "blue")+
  ylab("Delivery efficiency (%ID/g)")+
  xlab("Dose")+
  theme_bw()+ #white background
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 14, family = "serif"),
        axis.text.x = element_text(size = 14, family = "serif"))+
  theme(legend.position = "none")

ggsave("tumor_dose ANOVA_IDg.tiff", scale = 1,
       plot = p.Dose_IDg,
       path = "C:/Users/chenqiran/Desktop",
       width = 15, height = 10, units = "cm", dpi = 320)

#Table S7: pairwise comparison using Method 1 in the unit of %ID/g

res.Dose <- bartlett.test(log.DE_tumor ~ Dose.category, data = AUC_IDg)
res.Dose
fit_Dose <- aov(log.DE_tumor ~ Dose.category, data = AUC_IDg)
summary(fit_Dose)
pairwise.wilcox.test(AUC_IDg$log.DE_tumor, AUC_IDg$Dose.category, p.adjust.method = "BH")
