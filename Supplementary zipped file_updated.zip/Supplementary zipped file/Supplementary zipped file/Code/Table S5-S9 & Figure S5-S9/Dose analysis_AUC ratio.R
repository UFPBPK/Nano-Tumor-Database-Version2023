library(dplyr)
library(ggplot2)
AUC.ratio_ID <- readRDS("AUC_total_0811.RDS")
AUC.ratio_ID <- AUC.ratio_ID[,27:33]
AUC.ratio_ID <- AUC.ratio_ID %>% mutate (DE_tumor = AUC_tumor/AUC.plasma,
                                         log.DE_tumor =log(DE_tumor))
AUC.ratio_ID <- AUC.ratio_ID %>% mutate(log.DE_liver = log(AUC_liver/AUC.plasma, 10),
                                        log.DE_heart = log(AUC_heart/AUC.plasma, 10),
                                        log.DE_spleen = log(AUC_spleen/AUC.plasma, 10),
                                        log.DE_kidney = log(AUC_kidney/AUC.plasma, 10),
                                        log.DE_lung  = log(AUC_lung/AUC.plasma, 10))


AUC.ratio_IDg <- readRDS("AUC ratio_IDg.RDS")
colnames(AUC.ratio_IDg) <- c("DE_tumor", "DE_heart", "DE_liver", "DE_spleen", "DE_lung", "DE_kidney")

dose.data <- read.csv("nano new data.csv", header = TRUE) # In this version, the dose are cleared as numeric.
dose <- as.numeric(dose.data$Dose)

#Table S5: the correlations between dose and delivery efficiency using Method 3 in the unit of %ID

cor.tumor.ID <- cor(dose, AUC.ratio_ID$log.DE_tumor, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.heart.ID <- cor(dose, AUC.ratio_ID$log.DE_heart, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.liver.ID <- cor(dose, AUC.ratio_ID$log.DE_liver, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.spleen.ID <- cor(dose, AUC.ratio_ID$log.DE_spleen, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.lung.ID <- cor(dose, AUC.ratio_ID$log.DE_lung, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.kidney.ID <- cor(dose, AUC.ratio_ID$log.DE_kidney, use = "complete.obs", method = c("pearson", "kendall","spearman"))

#Figure S8
AUC.ratio_ID <- AUC.ratio_ID %>% mutate(Dose.category = cut(dose, breaks = c(0, 1E-4,1E-3,1E-2,0.1, 1, 10, 100, Inf), labels = c("1E-4", "1E-3","1E-2", "0.1","1","10","100",">100"),include.lowest = TRUE, na.rm = TRUE))

DE.dose <- AUC.ratio_ID %>% 
  group_by(Category = Dose.category) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE),
            N = length(DE_tumor), na.rm = TRUE)
DE.dose$Category <- c("<0.01","0.01","0.1","1","10","100",">100", "Unknown")
DE.dose$Category <- factor(DE.dose$Category, levels = c("<0.01","0.01","0.1","1","10","100",">100", "Unknown"))

Median.DE <- 0.21
p.Dose <- ggplot()+
  geom_bar(stat = "identity", data  = DE.dose,
           aes(x = Category, y = Median, group = Category, fill = factor(Category)),
           width = 0.6)+
  scale_fill_brewer(palette = "Spectral")+
  geom_hline(yintercept = Median.DE, linetype = "dashed", color = "blue")+
  ylab(expression(Distribution~ Coefficient[Tumor: Blood]))+
  xlab("Dose")+
  theme_bw()+ #white background
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 14, family = "serif"),
        axis.text.x = element_text(size = 14, family = "serif"),
        plot.title = element_text(size = 22, family = "serif", vjust = 3),
        plot.title.position = "plot")+
  theme(legend.position = "none")

ggsave("tumor_dose ANOVA_AUC ratio_ID.tiff", scale = 1,
       plot = p.Dose,
       path = "C:/Users/chenqiran/Desktop",
       width = 15, height = 10, units = "cm", dpi = 320)

#Table S8: pairwise comparisons for method 3 in the unit of %ID
res.Dose <- bartlett.test(log.DE_tumor ~ Dose.category, data = AUC.ratio_ID)
res.Dose
fit_Dose <- aov(log.DE_tumor ~ Dose.category, data = AUC.ratio_ID)
summary(fit_Dose)
pairwise.wilcox.test(AUC.ratio_ID$log.DE_tumor, AUC.ratio_ID$Dose.category, p.adjust.method = "BH")


AUC.ratio_IDg <- cbind.data.frame(dose, AUC.ratio_IDg)
AUC.ratio_IDg  <- AUC.ratio_IDg  %>%
  mutate(log.DE_tumor = log10(DE_tumor),
         log.DE_heart = log10(DE_heart),
         log.DE_liver = log10(DE_liver),
         log.DE_spleen = log10(DE_spleen),
         log.DE_lung  = log10(DE_lung),
         log.DE_kidney = log10(DE_kidney))

#Table S7: correlation between dose and delivery efficiency in method 3 in the unit of %ID/g
cor.tumor.IDg <- cor(dose, AUC.ratio_IDg $log.DE_tumor, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.heart.IDg <- cor(dose, AUC.ratio_IDg$log.DE_heart, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.liver.IDg <- cor(dose, AUC.ratio_IDg$log.DE_liver, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.spleen.IDg <- cor(dose, AUC.ratio_IDg$log.DE_spleen, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.lung.IDg <- cor(dose, AUC.ratio_IDg$log.DE_lung, use = "complete.obs", method = c("pearson", "kendall","spearman"))
cor.kidney.IDg <- cor(dose, AUC.ratio_IDg$log.DE_kidney, use = "complete.obs", method = c("pearson", "kendall","spearman"))

#Figure S9
AUC.ratio_IDg <- AUC.ratio_IDg %>% mutate(Dose.category = cut(dose, breaks = c(0, 1E-4,1E-3,1E-2,0.1, 1, 10, 100, Inf), labels = c("1E-4", "1E-3","1E-2", "0.1","1","10","100",">100"),include.lowest = TRUE, na.rm = TRUE))

DE.dose_IDg <- AUC.ratio_IDg %>% 
  group_by(Category = Dose.category) %>%
  summarize(Median = median(DE_tumor, na.rm = TRUE),
            bottom = quantile(DE_tumor,0.05, na.rm = TRUE),
            lower  = quantile(DE_tumor,0.25, na.rm = TRUE),
            upper  = quantile(DE_tumor,0.75, na.rm = TRUE),
            top    = quantile(DE_tumor,0.95, na.rm = TRUE),
            mean   = mean(DE_tumor, na.rm = TRUE),
            N = length(DE_tumor), na.rm = TRUE)
DE.dose_IDg$Category <- c("<0.01","0.01","0.1","1","10","100",">100", "Unknown")
DE.dose_IDg$Category <- factor(DE.dose_IDg$Category, levels = c("<0.01","0.01","0.1","1","10","100",">100", "Unknown"))

Median.DE_IDg <- 1.03
p.Dose_IDg <- ggplot()+
  geom_bar(stat = "identity", data  = DE.dose_IDg,
           aes(x = Category, y = Median, group = Category, fill = factor(Category)),
           width = 0.6)+
  scale_fill_brewer(palette = "Spectral")+
  geom_hline(yintercept = Median.DE_IDg, linetype = "dashed", color = "blue")+
  ylab(expression(Distribution~ Coefficient[Tumor: Blood]))+
  xlab("Dose")+
  theme_bw()+ #white background
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 18),
        axis.text.y = element_text(size = 14, family = "serif"),
        axis.text.x = element_text(size = 14, family = "serif"))+
  theme(legend.position = "none")

ggsave("tumor_dose ANOVA_AUC ratio_IDg.tiff", scale = 1,
       plot = p.Dose_IDg,
       path = "C:/Users/chenqiran/Desktop",
       width = 15, height = 10, units = "cm", dpi = 320)

# Table S9
res.Dose <- bartlett.test(log.DE_tumor ~ Dose.category, data = AUC.ratio_IDg)
res.Dose
fit_Dose <- aov(log.DE_tumor ~ Dose.category, data = AUC.ratio_IDg)
summary(fit_Dose)
pairwise.wilcox.test(AUC.ratio_IDg$log.DE_tumor, AUC.ratio_IDg$Dose.category, p.adjust.method = "BH")
