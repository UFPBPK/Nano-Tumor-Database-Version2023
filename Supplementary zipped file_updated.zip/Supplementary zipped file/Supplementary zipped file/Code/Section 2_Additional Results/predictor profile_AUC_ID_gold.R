library(ggpubr)

data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
info <- readRDS("nano info.RDS")
data <- cbind.data.frame(info, data[2:7])

data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))
INM <- data %>%  filter(Particle.Type == "Inorganic")
Gold <- INM %>%  filter(Inorganic.Material == "Gold")
best_final.Gold.1 <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + log.HD + PDI, data = Gold)
Summary <- summary(best_final.Gold.1)


gold.sim <- Gold %>% mutate(TS = recode (Targeting.Strategy,
                                       "Passive" = -0.3591,
                                       "Active" = 0),
                          CCer = recode(Cancer,
                                        "Ovary" = -0.5325,
                                        "Skin" = 0.7321,
                                        "Prostate" = -0.7821,
                                        "Pancreas" = -0.6887,
                                        "Others"  = 0.2899,
                                        .default = 0))

set.seed(1234)


#Targeting Strategy
DE.sim.TS <- NULL
N.TS <- unique(gold.sim$TS)
TS.name <- c("Active", "Passive")
for (i in 1:length(N.TS)){
  
  log.DE <- 2.7591 + N.TS[i]  + gold.sim$CCer - 0.9769 * gold.sim$log.HD - 2.5155 *gold.sim$PDI
  summary <- c(TS = TS.name[i],
               Median = median(log.DE, na.rm = TRUE),
               bottom = quantile(log.DE, 0.025, na.rm = TRUE),
               top = quantile(log.DE, 0.975, na.rm  = TRUE))
  DE.sim.TS <- rbind.data.frame(DE.sim.TS, summary)
}

colnames(DE.sim.TS) <- c("TS","Median","Bottom","Top")
DE.sim.TS$Median = as.numeric(DE.sim.TS$Median)
DE.sim.TS$Bottom = as.numeric(DE.sim.TS$Bottom)
DE.sim.TS$Top  =as.numeric(DE.sim.TS$Top)
DE.sim.TS$TS <- factor(DE.sim.TS$TS, levels = c("Passive", "Active"))


P.TS <- ggplot()+
  geom_line(data = DE.sim.TS, aes(x = TS, y = Median, group = 1), color = "darkgreen")+
  scale_y_continuous(limits = c(-2.5,2.5), breaks = c(-2.5,-1.5,-0.5,0.5,1.5,2.5))+
  geom_errorbar(data = DE.sim.TS, aes(x = TS, ymin = Bottom, ymax = Top, color = "darkgreen"), width = 0.2)+
  scale_color_manual(values = "darkgreen")+
  geom_point(data = DE.sim.TS, aes(x = TS, y = Median), color = "#d12920", size = 3)+
  geom_hline(yintercept = log10(1), color = "blue", size = 0.5, linetype = "twodash")+
  geom_hline(yintercept = log10(3), color = "#422256", size = 0.5, linetype = "twodash")+
  #ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab("Targeting Strategy")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 10, family = "serif"))

#Cancer type

DE.sim.CCer <- NULL
N.CCer <- unique(gold.sim$CCer)
CCer.name <- c("Brain","Skin","Prostate", "Others","Ovary", "Pancreas")
for (i in 1:length(N.CCer)){
  
  log.DE <- 2.7591 + gold.sim$TS  + N.CCer[i] - 0.9769 * gold.sim$log.HD - 2.5155 *gold.sim$PDI
  summary <- c(CCer = CCer.name[i],
               Median = median(log.DE, na.rm = TRUE),
               bottom = quantile(log.DE, 0.025, na.rm = TRUE),
               top = quantile(log.DE, 0.975, na.rm  = TRUE))
  DE.sim.CCer <- rbind.data.frame(DE.sim.CCer, summary)
}

colnames(DE.sim.CCer) <- c("Cancer","Median","Bottom","Top")
DE.sim.CCer$Median = as.numeric(DE.sim.CCer$Median)
DE.sim.CCer$Bottom = as.numeric(DE.sim.CCer$Bottom)
DE.sim.CCer$Top  =as.numeric(DE.sim.CCer$Top)
DE.sim.CCer$Cancer <- factor(DE.sim.CCer$Cancer, levels = c("Brain", "Breast", "Cervix", "Colon", "Lung", "Ovary", "Pancreas", "Prostate", "Skin", "Others"))


P.Cancer <- ggplot()+
  geom_line(data = DE.sim.CCer, aes(x = Cancer, y = Median, group = 1), color = "darkgreen")+
  scale_y_continuous(limits = c(-2.5,2.5), breaks = c(-2.5,-1.5,-0.5,0.5,1.5,2.5))+
  geom_errorbar(data = DE.sim.CCer, aes(x = Cancer, ymin = Bottom, ymax = Top, color = "darkgreen"), width = 0.2)+
  scale_color_manual(values = "darkgreen")+
  geom_point(data = DE.sim.CCer, aes(x = Cancer, y = Median), color = "#d12920", size = 3)+
  geom_hline(yintercept = log10(1), color = "blue", size = 0.5, linetype = "twodash")+
  geom_hline(yintercept = log10(3), color = "#422256", size = 0.5, linetype = "twodash")+
  ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  #  ylab("")+
  xlab("Cancer Type")+
  theme_bw()+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none")+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 10, family = "serif"),
        axis.text.y = element_text(size = 10, family = "serif"))


#PDI
set.seed(1234)
PDI.random <- runif(n = 1000, min = 0, max = 1)

DE.sim.PDI <- NULL

for (i in 1:1000){
  
  PDI <- PDI.random[i]
  log.DE <- 2.7591 + gold.sim$TS  + gold.sim$CCer - 0.9769 * gold.sim$log.HD - 2.5155 *PDI
  DE <- 10^log.DE
  DE <- ifelse(DE > 100, 100, DE)
  DEs <- c(PDI = PDI, 
           DE.median = median(DE, na.rm = TRUE),
           DE.bottom = quantile(DE, 0.075, na.rm = TRUE),
           DE.top = quantile(DE, 0.975, na.rm = TRUE))
  DE.sim.PDI <- rbind.data.frame(DE.sim.PDI, DEs)
  
}

colnames(DE.sim.PDI) <- c("PDI", "Median", "Bottom","Top")

P.PDI <- ggplot(DE.sim.PDI, aes(PDI, Median))+
  geom_smooth(method = loess, color = "darkgreen", size = 1)+
  geom_ribbon(aes(ymin = Bottom, ymax = Top), alpha = 0.2, fill = "pink", color = "white")+
  geom_line(aes(PDI, Bottom), color = "pink", size = 0.5, linetype = "longdash")+
  geom_line(aes(PDI, Top), color = "pink", size = 0.5, linetype = "longdash")+
  geom_hline(yintercept = 1, color = "blue", size = 0.5, linetype = "twodash")+
  geom_hline(yintercept = 3, color = "#422256", size = 0.5, linetype = "twodash")+
  scale_y_continuous(limits = c(10^(-2.5), 10^(2.5)), breaks = c(10^(-2.5), 10^(-1.5), 10^(-0.5), 10^0.5, 10^1.5, 10^2.5), labels = c("-2.5", "-1.5", "-0.5", "0.5", "1.5", "2.5"), trans = "log10")+
  #ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab("Polydispersity Index")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 14, family = "serif"))

#log(HD)

set.seed(1234)

HD.min <- min(gold.sim$NM.Hydrodnamic.Size.nm., na.rm = TRUE)
HD.max <- max(gold.sim$NM.Hydrodnamic.Size.nm., na.rm = TRUE)
HD.random <- runif(n = 1000, min = HD.min, max = 200)
logHD.random <- log10(HD.random)

DE.sim.logHD <- NULL

for (i in 1:1000){
  
  logHD <- logHD.random[i]
  log.DE <- 2.7591 + gold.sim$TS  + gold.sim$CCer - 0.9769 * logHD - 2.5155 * gold.sim$PDI
  DE <- 10^log.DE
  DE <- ifelse(DE > 100, 100, DE)
  DEs <- c(logHD = logHD, 
           DE.median = median(DE, na.rm = TRUE),
           DE.bottom = quantile(DE, 0.075, na.rm = TRUE),
           DE.top = quantile(DE, 0.975, na.rm = TRUE))
  DE.sim.logHD <- rbind.data.frame(DE.sim.logHD, DEs)
  
}

colnames(DE.sim.logHD) <- c("logHD", "Median", "Bottom","Top")

P.logHD <- ggplot(DE.sim.logHD, aes(logHD, Median))+
  geom_smooth(method = loess, color = "darkgreen", size = 1)+
  geom_ribbon(aes(ymin = Bottom, ymax = Top), alpha = 0.2, fill = "pink", color = "white")+
  geom_line(aes(logHD, Bottom), color = "pink", size = 0.5, linetype = "longdash")+
  geom_line(aes(logHD, Top), color = "pink", size = 0.5, linetype = "longdash")+
  geom_hline(yintercept = 1, color = "blue", size = 0.5, linetype = "twodash")+
  geom_hline(yintercept = 3, color = "#422256", size = 0.5, linetype = "twodash")+
  scale_y_continuous(limits = c(10^(-2.5), 10^(2.5)), breaks = c(10^(-2.5), 10^(-1.5), 10^(-0.5), 10^0.5, 10^1.5, 10^2.5), labels = c("-2.5", "-1.5", "-0.5", "0.5", "1.5", "2.5"), trans = "log10")+
  #ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab(expression(Log[10]~"HD"))+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 14, family = "serif"))

p.logHD <- P.logHD + theme(plot.margin = unit(c(0.5, 0.5, 0, 0.5),"cm"))
p.Cancer <- P.Cancer+ theme(plot.margin = unit(c(0.5, 0.5, 0, 0.5), "cm"))
p.TS <- P.TS  + theme(plot.margin = unit(c(0.5, 0.5, 0, 0.5), "cm"))
p.PDI <- P.PDI + theme(plot.margin = unit(c(0.5, 0.5, 0, 0.5), "cm"))


ggsave("gold_logHD_AUC_ID.tiff", scale = 1,
       plot = p.logHD,
       path = "C:/Users/chenqiran/Desktop",
       width = 12, height = 10, units = "cm", dpi = 320)

ggsave("gold_Cancer_AUC_ID.tiff", scale = 1,
       plot = p.Cancer,
       path = "C:/Users/chenqiran/Desktop",
       width = 14, height = 10, units = "cm", dpi = 320)

ggsave("gold_TS_AUC_ID.tiff", scale = 1,
       plot = p.TS,
       path = "C:/Users/chenqiran/Desktop",
       width = 5, height = 10, units = "cm", dpi = 320)

ggsave("gold_PDI_AUC_ID.tiff", scale = 1,
       plot = p.PDI,
       path = "C:/Users/chenqiran/Desktop",
       width = 10, height = 10, units = "cm", dpi = 320)
