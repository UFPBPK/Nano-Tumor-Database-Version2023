library(ggpubr)

data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
info <- readRDS("nano info.RDS")
data <- cbind.data.frame(info, data[2:7])

data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))

data <- data %>% mutate(ONM.category = recode(Organic.Material,
                                              "Polymeric" = "Polymeric",
                                              "Dendrimer" = "Dendrimer",
                                              "Liposome"  = "Liposome",
                                              "Hydrogel"  = "Hydrogel",
                                              .default    = "ONM others"))%>%
  mutate(material = ifelse(Particle.Type == "Inorganic",INM.category,
                           ifelse(Particle.Type == "Organic",ONM.category,"Hybrid")))

data <- data %>% mutate(Cancer = recode(Cancer.type,
                                        "Brain"  = "Brain",
                                        "Breast" = "Breast",
                                        "Cervix" = "Cervix",
                                        "Colon"  = "Colon",
                                        "Glioma" = "Glioma",
                                        "Liver"  = "Liver",
                                        "Lung"   = "Lung",
                                        "Ovary"  = "Ovary",
                                        "Pancreas" = "Pancreas",
                                        "Prostate" = "Prostate",
                                        "Sarcoma"= "Sarcoma",
                                        "Skin"   = "Skin",
                                        .default = "Others"))

data <- data %>% mutate(NM.Shape = recode(NM.Shape, 
                                          "Rod" = "Rod",
                                          "Spherical" = "Spherical",
                                          "Plate" = "Plate",
                                          .default = "Others"))



data.sim <- data %>% mutate(MAT =  recode(material, 
                                          "Gold" = -0.618093,
                                          "Silica" = -1.125463,
                                          "Iron Oxide" = -0.987165,
                                          "Other" = -1.069984,
                                          "Hybrid" = -0.571555,
                                          "Polymeric" = -1.310576,
                                          "Liposome" = -1.938029,
                                          "Hydrogel" = -2.049817,
                                          "ONM others" = -1.655009,
                                          .default = 0),
                            SP = recode(NM.Shape,
                                        "Spherical" = 0.989300,
                                        "Plate" = 0.737649,
                                        "Rod" = 0.848088,
                                        .default = 0),
                            CCer = recode(Cancer,
                                          "Cervix" = 0.449836,
                                          "Colon" = 0.164501,
                                          "Liver" = 0.245365,
                                          "Lung" = 0.242561,
                                          "Breast" = 0.302778,
                                          "Ovary" = 0.059078,
                                          "Skin" = 0.519225,
                                          "Prostate" = -0.419254,
                                          "Pancreas" = -0.106631,
                                          "Sarcoma" = 0.881816,
                                          "Others"  = 0.424575,
                                          .default = 0))

set.seed(1234)

#Profile predictor of zeta potential
zeta.min <- min(data$Zeta.potential.mV., na.rm = TRUE)
zeta.max <- max(data$Zeta.potential.mV., na.rm = TRUE)
zeta.random <- runif(n = 1000, min = zeta.min, max = zeta.max)

DE.sim.zeta <- NULL
for (i in 1:1000){
  
  zeta <- zeta.random[i]
  log.DE <- -0.074859 + data.sim$MAT + data.sim$SP + 0.019268 * data.sim$log.HD  + data.sim$CCer + 0.001511 * zeta + 0.025977 * data.sim$PDI
  DE <- 10^log.DE
  DEs <- c(Zeta = zeta, 
           DE.median = median(DE, na.rm = TRUE),
           DE.bottom = quantile(DE, 0.075, na.rm = TRUE),
           DE.top = quantile(DE, 0.975, na.rm = TRUE))
  DE.sim.zeta <- rbind.data.frame(DE.sim.zeta, DEs)
  
}

colnames(DE.sim.zeta) <- c("Zeta", "Median", "Bottom","Top")
P.ZP <- ggplot(DE.sim.zeta, aes(Zeta, Median))+
  geom_smooth(method = loess, color = "darkgreen", size = 1)+
  geom_ribbon(aes(ymin = Bottom, ymax = Top), alpha = 0.2, fill = "pink", color = "white")+
  geom_line(aes(Zeta, Bottom), color = "pink", size = 0.5, linetype = "longdash")+
  geom_line(aes(Zeta, Top), color = "pink", size = 0.5, linetype = "longdash")+
  geom_hline(yintercept = 1, color = "blue", size = 0.5, linetype = "twodash")+
  scale_y_continuous(limits = c(10^(-2.5), 10^(2.5)), breaks = c(10^(-2.5), 10^(-1.5), 10^(-0.5), 10^0.5, 10^1.5, 10^2.5), labels = c("-2.5", "-1.5", "-0.5", "0.5", "1.5", "2.5"), trans = "log10")+
#  ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab("Zeta potential (mV)")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 14, family = "serif"))

#Material

DE.sim.MAT <- NULL
N.MAT <- unique(data.sim$MAT)
MAT.name <- c("Gold","INM others","Iron oxide", "Hybrid", "Silica","Polymeric","ONM others","Liposome","Hydrogel","Dendrimer")

for (i in 1:length(N.MAT)){
  
  log.DE <- -0.074859 + N.MAT[i] + data.sim$SP + 0.019268 * data.sim$log.HD  + data.sim$CCer + 0.001511 * data.sim$Zeta.potential.mV. + 0.025977 * data.sim$PDI
  summary <- c(MAT = MAT.name[i],
                  Median = median(log.DE, na.rm = TRUE),
                  bottom = quantile(log.DE, 0.025, na.rm = TRUE),
                  top = quantile(log.DE, 0.975, na.rm  = TRUE))
  DE.sim.MAT <- rbind.data.frame(DE.sim.MAT, summary)
}

colnames(DE.sim.MAT) <- c("MAT","Median","Bottom","Top")
DE.sim.MAT$Median = as.numeric(DE.sim.MAT$Median)
DE.sim.MAT$Bottom = as.numeric(DE.sim.MAT$Bottom)
DE.sim.MAT$Top  =as.numeric(DE.sim.MAT$Top)
DE.sim.MAT$MAT <- factor(DE.sim.MAT$MAT, levels = c("Gold", "Iron oxide", "Silica", "INM others", "Hybrid", "Dendrimer", "Polymeric","Liposome","Hydrogel", "ONM others"))


P.MAT <- ggplot()+
  geom_line(data = DE.sim.MAT, aes(x = MAT, y = Median, group = 1), color = "darkgreen")+
  scale_y_continuous(limits = c(-2.5,2.5), breaks = c(-2.5,-1.5,-0.5,0.5,1.5,2.5))+
  geom_errorbar(data = DE.sim.MAT, aes(x = MAT, ymin = Bottom, ymax = Top, color = "darkgreen"), width = 0.2)+
  scale_color_manual(values = "darkgreen")+
  geom_point(data = DE.sim.MAT, aes(x = MAT, y = Median), color = "#d12920", size = 3)+
  geom_hline(yintercept = log10(1), color = "blue", size = 0.5, linetype = "twodash")+
  ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
#  ylab("")+
  xlab("Material")+
  theme_bw()+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none")+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.y = element_text(size = 14, family = "serif"),
        axis.text.x = element_text(size = 10, family = "serif"))



#log(HD)
HD.min <- min(data.sim$NM.Hydrodnamic.Size.nm., na.rm = TRUE)
HD.max <- max(data.sim$NM.Hydrodnamic.Size.nm., na.rm = TRUE)
HD.random <- runif(n = 1000, min = HD.min, max = HD.max)
logHD.random <- log10(HD.random)

DE.sim.logHD <- NULL

for (i in 1:1000){
  
  logHD <- logHD.random[i]
  log.DE <- -0.074859 + data.sim$MAT + data.sim$SP + 0.019268 * logHD  + data.sim$CCer + 0.001511 * data.sim$Zeta.potential.mV. + 0.025977 * data.sim$PDI
  DE <- 10^log.DE
  DEs <- c(logHD = logHD, 
           DE.median = median(DE, na.rm = TRUE),
           DE.bottom = quantile(DE, 0.075, na.rm = TRUE),
           DE.top = quantile(DE, 0.975, na.rm = TRUE))
  DE.sim.logHD <- rbind.data.frame(DE.sim.logHD, DEs)
  
}

colnames(DE.sim.logHD) <- c("logHD", "Median", "Bottom","Top")

P.logHD <- ggplot(DE.sim.logHD, aes(logHD, Median))+
  geom_smooth(method = loess, color = "darkgreen", size = 1)+
  geom_ribbon(aes(ymin = Bottom, ymax = Top), alpha = 0.2, fill = "pink", color = "white")+
  geom_line(aes(logHD, Bottom), color = "pink", size = 0.5, linetype = "longdash")+
  geom_line(aes(logHD, Top), color = "pink", size = 0.5, linetype = "longdash")+
  geom_hline(yintercept = 1, color = "blue", size = 0.5, linetype = "twodash")+
  scale_y_continuous(limits = c(10^(-2.5), 10^(2.5)), breaks = c(10^(-2.5), 10^(-1.5), 10^(-0.5), 10^0.5, 10^1.5, 10^2.5), labels = c("-2.5", "-1.5", "-0.5", "0.5", "1.5", "2.5"), trans = "log10")+
  scale_x_continuous(limits = c(min(logHD.random), max(logHD.random)), breaks = c(1, 2, 3))+
  #ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab(expression(Log[10]~"HD"))+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 14, family = "serif"))

#PDI
set.seed(1234)
PDI.random <- runif(n = 1000, min = 0, max = 1)

DE.sim.PDI <- NULL
for (i in 1:1000){
  
  PDI <- PDI.random[i]
  log.DE <- -0.074859 + data.sim$MAT + data.sim$SP + 0.019268 * data.sim$log.HD  + data.sim$CCer + 0.001511 * data.sim$Zeta.potential.mV. + 0.025977 * PDI
  DE <- 10^log.DE
  DEs <- c(PDI = PDI, 
           DE.median = median(DE, na.rm = TRUE),
           DE.bottom = quantile(DE, 0.075, na.rm = TRUE),
           DE.top = quantile(DE, 0.975, na.rm = TRUE))
  DE.sim.PDI <- rbind.data.frame(DE.sim.PDI, DEs)
  
}

colnames(DE.sim.PDI) <- c("PDI", "Median", "Bottom","Top")

P.PDI <- ggplot(DE.sim.PDI, aes(PDI, Median))+
  geom_smooth(method = loess, color = "darkgreen", size = 1)+
  geom_ribbon(aes(ymin = Bottom, ymax = Top), alpha = 0.2, fill = "pink", color = "white")+
  geom_line(aes(PDI, Bottom), color = "pink", size = 0.5, linetype = "longdash")+
  geom_line(aes(PDI, Top), color = "pink", size = 0.5, linetype = "longdash")+
  geom_hline(yintercept = log10(1), color = "blue", size = 0.5, linetype = "twodash")+
  scale_y_continuous(limits = c(10^(-2.5), 10^(2.5)), breaks = c(10^(-2.5), 10^(-1.5), 10^(-0.5), 10^0.5, 10^1.5, 10^2.5), labels = c("-2.5", "-1.5", "-0.5", "0.5", "1.5", "2.5"), trans = "log10")+
  #ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab("Polydispersity Index")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 14, family = "serif"))


#Cancer type

DE.sim.CCer <- NULL
N.CCer <- unique(data.sim$CCer)
CCer.name <- c("Cervix", "Colon", "Brain", "Breast", "Skin", "Prostate", "Others", "Ovary", "Pancreas", "Lung", "Sarcoma", "Liver")
for (i in 1:length(N.CCer)){
  
  log.DE <- -0.074859 + data.sim$MAT + data.sim$SP + 0.019268 * data.sim$log.HD  + N.CCer[i] + 0.001511 * data.sim$Zeta.potential.mV. + 0.025977 * data.sim$PDI
  summary <- c(CCer = CCer.name[i],
               Median = median(log.DE, na.rm = TRUE),
               bottom = quantile(log.DE, 0.025, na.rm = TRUE),
               top = quantile(log.DE, 0.975, na.rm  = TRUE))
  DE.sim.CCer <- rbind.data.frame(DE.sim.CCer, summary)
}

colnames(DE.sim.CCer) <- c("Cancer","Median","Bottom","Top")
DE.sim.CCer$Median = as.numeric(DE.sim.CCer$Median)
DE.sim.CCer$Bottom = as.numeric(DE.sim.CCer$Bottom)
DE.sim.CCer$Top  =as.numeric(DE.sim.CCer$Top)
DE.sim.CCer$Cancer <- factor(DE.sim.CCer$Cancer, levels = c("Brain", "Breast", "Cervix", "Colon", "Liver", "Lung", "Ovary", "Pancreas", "Prostate", "Sarcoma", "Skin", "Others"))


P.Cancer <- ggplot()+
  geom_line(data = DE.sim.CCer, aes(x = Cancer, y = Median, group = 1), color = "darkgreen")+
  scale_y_continuous(limits = c(-2.5,2.5), breaks = c(-2.5,-1.5,-0.5,0.5,1.5,2.5))+
  geom_errorbar(data = DE.sim.CCer, aes(x = Cancer, ymin = Bottom, ymax = Top, color = "darkgreen"), width = 0.2)+
  scale_color_manual(values = "darkgreen")+
  geom_point(data = DE.sim.CCer, aes(x = Cancer, y = Median), color = "#d12920", size = 3)+
  geom_hline(yintercept = log10(1), color = "blue", size = 0.5, linetype = "twodash")+
  #ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab("Cancer Type")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 10, family = "serif"))

#Shape

DE.sim.SP <- NULL
N.SP <- unique(data.sim$SP)
SP.name <- c("Rod", "Spherical", "Others", "Plate")

for (i in 1:length(N.SP)){
  
  log.DE <- -0.074859 + data.sim$MAT + N.SP[i] + 0.019268 * data.sim$log.HD  + data.sim$CCer + 0.001511 * data.sim$Zeta.potential.mV. + 0.025977 * data.sim$PDI
  summary <- c(SP = SP.name[i],
               Median = median(log.DE, na.rm = TRUE),
               bottom = quantile(log.DE, 0.025, na.rm = TRUE),
               top = quantile(log.DE, 0.975, na.rm  = TRUE))
  DE.sim.SP <- rbind.data.frame(DE.sim.SP, summary)
}

colnames(DE.sim.SP) <- c("Shape","Median","Bottom","Top")
DE.sim.SP$Median = as.numeric(DE.sim.SP$Median)
DE.sim.SP$Bottom = as.numeric(DE.sim.SP$Bottom)
DE.sim.SP$Top  =as.numeric(DE.sim.SP$Top)
DE.sim.SP$Shape <- factor(DE.sim.SP$Shape, levels = c("Spherical", "Rod", "Plate", "Others"))


P.SP <- ggplot()+
  geom_line(data = DE.sim.SP, aes(x = Shape, y = Median, group = 1), color = "darkgreen")+
  scale_y_continuous(limits = c(-2.5,2.5), breaks = c(-2.5,-1.5,-0.5,0.5,1.5,2.5))+
  geom_errorbar(data = DE.sim.SP, aes(x = Shape, ymin = Bottom, ymax = Top, color = "darkgreen"), width = 0.2)+
  scale_color_manual(values = "darkgreen")+
  geom_point(data = DE.sim.SP, aes(x = Shape, y = Median), color = "#d12920", size = 3)+
  geom_hline(yintercept = log10(1), color = "blue", size = 0.5, linetype = "twodash")+
  ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  #ylab("")+
  xlab("Shape")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 14, family = "serif"))

p.MAT <- P.MAT + theme(plot.margin = unit(c(0.5,0.5,0,0.5), "cm"))
p.SP  <- P.SP + theme(aspect.ratio = 1/1,
                      plot.margin = unit(c(0.5, 0, 0.5, 0),"cm"))
p.logHD <- P.logHD + theme(plot.margin = unit(c(0.5, 0, 0.5, 0),"cm"))
p.ZP <- P.ZP + theme(plot.margin = unit(c(0.5, 0, 0.5, 0),"cm"))
p.Cancer <- P.Cancer+ theme(plot.margin = unit(c(0.5,0,0.5,0), "cm"))

ggsave("MAT_AUC_ID.tiff", scale = 1,
       plot = p.MAT,
       path = "C:/Users/chenqiran/Desktop",
       width = 20, height = 10, units = "cm", dpi = 320)

ggsave("SP_AUC_ID.tiff", scale = 1,
       plot = p.SP,
       path = "C:/Users/chenqiran/Desktop",
       width = 10, height = 10, units = "cm", dpi = 320)


ggsave("logHD_AUC_ID.tiff", scale = 1,
       plot = p.logHD,
       path = "C:/Users/chenqiran/Desktop",
       width = 12, height = 10, units = "cm", dpi = 320)

ggsave("ZP_AUC_ID.tiff", scale = 1,
       plot = p.ZP,
       path = "C:/Users/chenqiran/Desktop",
       width = 12, height = 10, units = "cm", dpi = 320)

ggsave("Cancer_AUC_ID.tiff", scale = 1,
       plot = p.Cancer,
       path = "C:/Users/chenqiran/Desktop",
       width = 20, height = 10, units = "cm", dpi = 320)
