library(ggpubr)

data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
info <- readRDS("nano info.RDS")
data <- cbind.data.frame(info, data[2:7])

data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))

data <- data %>% mutate(ONM.category = recode(Organic.Material,
                                              "Polymeric" = "Polymeric",
                                              "Dendrimer" = "Dendrimer",
                                              "Liposome"  = "Liposome",
                                              "Hydrogel"  = "Hydrogel",
                                              .default    = "ONM others"))%>%
  mutate(material = ifelse(Particle.Type == "Inorganic",INM.category,
                           ifelse(Particle.Type == "Organic",ONM.category,"Hybrid")))

data <- data %>% mutate(Cancer = recode(Cancer.type,
                                        "Brain"  = "Brain",
                                        "Breast" = "Breast",
                                        "Cervix" = "Cervix",
                                        "Colon"  = "Colon",
                                        "Glioma" = "Glioma",
                                        "Liver"  = "Liver",
                                        "Lung"   = "Lung",
                                        "Ovary"  = "Ovary",
                                        "Pancreas" = "Pancreas",
                                        "Prostate" = "Prostate",
                                        "Sarcoma"= "Sarcoma",
                                        "Skin"   = "Skin",
                                        .default = "Others"))

data <- data %>% mutate(NM.Shape = recode(NM.Shape, 
                                          "Rod" = "Rod",
                                          "Spherical" = "Spherical",
                                          "Plate" = "Plate",
                                          .default = "Others"))

ONM <- data %>%  filter(Particle.Type == "Organic")

ONM.sim <- ONM %>% mutate(MAT =  recode(material, 
                                          "Polymeric" = -0.760563,
                                          "Liposome" = -1.235406,
                                          "Hydrogel" = -1.113594,
                                          "ONM others" = -0.874236,
                                          .default = 0),
                            SP = recode(NM.Shape,
                                        "Spherical" = 1.358806,
                                        "Plate" = 1.567697,
                                        "Rod" = 1.313831,
                                        .default = 0),
                            TS = recode (Targeting.Strategy,
                                         "Passive" = -0.115569,
                                         "Active" = 0),
                            CCer = recode(Cancer,
                                          "Cervix" = 0.666894,
                                          "Colon" = 0.248087,
                                          "Glioma" = -1.259792,
                                          "Liver" = 0.175012,
                                          "Lung" = 0.049676,
                                          "Breast" = 0.291432,
                                          "Ovary" = 0.295730,
                                          "Skin" = 0.381969,
                                          "Prostate" = 0.514846,
                                          "Pancreas" = 0.448940,
                                          "Sarcoma" = 0.798281,
                                          "Others"  = 0.347417,
                                          .default = 0))

set.seed(1234)

#Profile predictor of zeta potential
zeta.min <- min(ONM.sim$Zeta.potential.mV., na.rm = TRUE)
zeta.max <- max(ONM.sim$Zeta.potential.mV., na.rm = TRUE)
zeta.random <- runif(n = 1000, min = zeta.min, max = zeta.max)

DE.sim.zeta <- NULL
for (i in 1:1000){
  
  zeta <- zeta.random[i]
  log.DE <- -1.351938 + ONM.sim$MAT + ONM.sim$TS + ONM.sim$SP + 0.220389 * ONM.sim$log.HD  + ONM.sim$CCer + 0.004443 * zeta
  DE <- 10^log.DE
  DEs <- c(Zeta = zeta, 
           DE.median = median(DE, na.rm = TRUE),
           DE.bottom = quantile(DE, 0.075, na.rm = TRUE),
           DE.top = quantile(DE, 0.975, na.rm = TRUE))
  DE.sim.zeta <- rbind.data.frame(DE.sim.zeta, DEs)
  
}

colnames(DE.sim.zeta) <- c("Zeta", "Median", "Bottom","Top")
P.ZP <- ggplot(DE.sim.zeta, aes(Zeta, Median))+
  geom_smooth(method = loess, color = "darkgreen", size = 1)+
  geom_ribbon(aes(ymin = Bottom, ymax = Top), alpha = 0.2, fill = "pink", color = "white")+
  geom_line(aes(Zeta, Bottom), color = "pink", size = 0.5, linetype = "longdash")+
  geom_line(aes(Zeta, Top), color = "pink", size = 0.5, linetype = "longdash")+
  geom_hline(yintercept = 1, color = "blue", size = 0.5, linetype = "twodash")+
  scale_y_continuous(limits = c(10^(-2.5), 10^(2.5)), breaks = c(10^(-2.5), 10^(-1.5), 10^(-0.5), 10^0.5, 10^1.5, 10^2.5), labels = c("-2.5", "-1.5", "-0.5", "0.5", "1.5", "2.5"), trans = "log10")+
  #  ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab("Zeta potential (mV)")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 14, family = "serif"))

#Material

DE.sim.MAT <- NULL
N.MAT <- unique(ONM.sim$MAT)
MAT.name <- c("Polymeric","ONM others","Liposome","Hydrogel","Dendrimer")

for (i in 1:length(N.MAT)){
  
  log.DE <- -1.351938 + N.MAT[i] + ONM.sim$TS + ONM.sim$SP + 0.220389 * ONM.sim$log.HD  + ONM.sim$CCer + 0.004443 * ONM.sim$Zeta.potential.mV.
  summary <- c(MAT = MAT.name[i],
               Median = median(log.DE, na.rm = TRUE),
               bottom = quantile(log.DE, 0.025, na.rm = TRUE),
               top = quantile(log.DE, 0.975, na.rm  = TRUE))
  DE.sim.MAT <- rbind.data.frame(DE.sim.MAT, summary)
}

colnames(DE.sim.MAT) <- c("MAT","Median","Bottom","Top")
DE.sim.MAT$Median = as.numeric(DE.sim.MAT$Median)
DE.sim.MAT$Bottom = as.numeric(DE.sim.MAT$Bottom)
DE.sim.MAT$Top  =as.numeric(DE.sim.MAT$Top)
DE.sim.MAT$MAT <- factor(DE.sim.MAT$MAT, levels = c("Dendrimer", "Polymeric","Liposome","Hydrogel", "ONM others"))


P.MAT <- ggplot()+
  geom_line(data = DE.sim.MAT, aes(x = MAT, y = Median, group = 1), color = "darkgreen")+
  scale_y_continuous(limits = c(-2.5,2.5), breaks = c(-2.5,-1.5,-0.5,0.5,1.5,2.5))+
  geom_errorbar(data = DE.sim.MAT, aes(x = MAT, ymin = Bottom, ymax = Top, color = "darkgreen"), width = 0.2)+
  scale_color_manual(values = "darkgreen")+
  geom_point(data = DE.sim.MAT, aes(x = MAT, y = Median), color = "#d12920", size = 3)+
  geom_hline(yintercept = log10(1), color = "blue", size = 0.5, linetype = "twodash")+
  ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  #  ylab("")+
  xlab("Material")+
  theme_bw()+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none")+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.y = element_text(size = 14, family = "serif"),
        axis.text.x = element_text(size = 14, family = "serif"))



#log(HD)
HD.min <- min(ONM.sim$NM.Hydrodnamic.Size.nm., na.rm = TRUE)
HD.max <- max(ONM.sim$NM.Hydrodnamic.Size.nm., na.rm = TRUE)
HD.random <- runif(n = 1000, min = HD.min, max = HD.max)
logHD.random <- log10(HD.random)

DE.sim.logHD <- NULL

for (i in 1:1000){
  
  logHD <- logHD.random[i]
  log.DE <- -1.351938 + ONM.sim$MAT + ONM.sim$TS + ONM.sim$SP + 0.220389 * logHD  + ONM.sim$CCer + 0.004443 * ONM.sim$Zeta.potential.mV.
  DE <- 10^log.DE
  DEs <- c(logHD = logHD, 
           DE.median = median(DE, na.rm = TRUE),
           DE.bottom = quantile(DE, 0.075, na.rm = TRUE),
           DE.top = quantile(DE, 0.975, na.rm = TRUE))
  DE.sim.logHD <- rbind.data.frame(DE.sim.logHD, DEs)
  
}

colnames(DE.sim.logHD) <- c("logHD", "Median", "Bottom","Top")

P.logHD <- ggplot(DE.sim.logHD, aes(logHD, Median))+
  geom_smooth(method = loess, color = "darkgreen", size = 1)+
  geom_ribbon(aes(ymin = Bottom, ymax = Top), alpha = 0.2, fill = "pink", color = "white")+
  geom_line(aes(logHD, Bottom), color = "pink", size = 0.5, linetype = "longdash")+
  geom_line(aes(logHD, Top), color = "pink", size = 0.5, linetype = "longdash")+
  geom_hline(yintercept = 1, color = "blue", size = 0.5, linetype = "twodash")+
  scale_y_continuous(limits = c(10^(-2.5), 10^(2.5)), breaks = c(10^(-2.5), 10^(-1.5), 10^(-0.5), 10^0.5, 10^1.5, 10^2.5), labels = c("-2.5", "-1.5", "-0.5", "0.5", "1.5", "2.5"), trans = "log10")+
  #ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab(expression(Log[10]~"HD"))+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 14, family = "serif"))

#Targeting Strategy
DE.sim.TS <- NULL
N.TS <- unique(ONM.sim$TS)
TS.name <- c("Passive", "Active")
for (i in 1:length(N.TS)){
  
  log.DE <- -1.351938 + ONM.sim$MAT + N.TS[i] + ONM.sim$SP + 0.220389 * logHD  + ONM.sim$CCer + 0.004443 * ONM.sim$Zeta.potential.mV.
  summary <- c(TS = TS.name[i],
               Median = median(log.DE, na.rm = TRUE),
               bottom = quantile(log.DE, 0.025, na.rm = TRUE),
               top = quantile(log.DE, 0.975, na.rm  = TRUE))
  DE.sim.TS <- rbind.data.frame(DE.sim.TS, summary)
}

colnames(DE.sim.TS) <- c("TS","Median","Bottom","Top")
DE.sim.TS$Median = as.numeric(DE.sim.TS$Median)
DE.sim.TS$Bottom = as.numeric(DE.sim.TS$Bottom)
DE.sim.TS$Top  =as.numeric(DE.sim.TS$Top)
DE.sim.TS$TS <- factor(DE.sim.TS$TS, levels = c("Passive", "Active"))


P.TS <- ggplot()+
  geom_line(data = DE.sim.TS, aes(x = TS, y = Median, group = 1), color = "darkgreen")+
  scale_y_continuous(limits = c(-2.5,2.5), breaks = c(-2.5,-1.5,-0.5,0.5,1.5,2.5))+
  geom_errorbar(data = DE.sim.TS, aes(x = TS, ymin = Bottom, ymax = Top, color = "darkgreen"), width = 0.2)+
  scale_color_manual(values = "darkgreen")+
  geom_point(data = DE.sim.TS, aes(x = TS, y = Median), color = "#d12920", size = 3)+
  geom_hline(yintercept = log10(1), color = "blue", size = 0.5, linetype = "twodash")+
  #ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab("Targeting Strategy")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 10, family = "serif"))

#Cancer type

DE.sim.CCer <- NULL
N.CCer <- unique(ONM.sim$CCer)
CCer.name <- c("Lung", "Breast", "Skin", "Ovary", "Colon","Pancreas", "Cervix", "Sarcoma","Liver", "Brain", "Others", "Prostate", "Glioma")
for (i in 1:length(N.CCer)){
  
  log.DE <- -1.351938 + ONM.sim$MAT + ONM.sim$TS + ONM.sim$SP + 0.220389 * logHD  + N.CCer[i] + 0.004443 * ONM.sim$Zeta.potential.mV.
  summary <- c(CCer = CCer.name[i],
               Median = median(log.DE, na.rm = TRUE),
               bottom = quantile(log.DE, 0.025, na.rm = TRUE),
               top = quantile(log.DE, 0.975, na.rm  = TRUE))
  DE.sim.CCer <- rbind.data.frame(DE.sim.CCer, summary)
}

colnames(DE.sim.CCer) <- c("Cancer","Median","Bottom","Top")
DE.sim.CCer$Median = as.numeric(DE.sim.CCer$Median)
DE.sim.CCer$Bottom = as.numeric(DE.sim.CCer$Bottom)
DE.sim.CCer$Top  =as.numeric(DE.sim.CCer$Top)
DE.sim.CCer$Cancer <- factor(DE.sim.CCer$Cancer, levels = c("Brain", "Breast", "Cervix", "Colon", "Glioma", "Liver", "Lung", "Ovary", "Pancreas", "Prostate", "Sarcoma", "Skin", "Others"))


P.Cancer <- ggplot()+
  geom_line(data = DE.sim.CCer, aes(x = Cancer, y = Median, group = 1), color = "darkgreen")+
  scale_y_continuous(limits = c(-2.5,2.5), breaks = c(-2.5,-1.5,-0.5,0.5,1.5,2.5))+
  geom_errorbar(data = DE.sim.CCer, aes(x = Cancer, ymin = Bottom, ymax = Top, color = "darkgreen"), width = 0.2)+
  scale_color_manual(values = "darkgreen")+
  geom_point(data = DE.sim.CCer, aes(x = Cancer, y = Median), color = "#d12920", size = 3)+
  geom_hline(yintercept = log10(1), color = "blue", size = 0.5, linetype = "twodash")+
  #ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab("Cancer Type")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 10, family = "serif"))

#Shape

DE.sim.SP <- NULL
N.SP <- unique(ONM.sim$SP)
SP.name <- c("Spherical","Others", "Rod", "Plate")

for (i in 1:length(N.SP)){
  
  log.DE <- -1.351938 + ONM.sim$MAT + ONM.sim$TS + N.SP[i] + 0.220389 * logHD  + ONM.sim$CCer + 0.004443 * ONM.sim$Zeta.potential.mV.
  summary <- c(SP = SP.name[i],
               Median = median(log.DE, na.rm = TRUE),
               bottom = quantile(log.DE, 0.025, na.rm = TRUE),
               top = quantile(log.DE, 0.975, na.rm  = TRUE))
  DE.sim.SP <- rbind.data.frame(DE.sim.SP, summary)
}

colnames(DE.sim.SP) <- c("Shape","Median","Bottom","Top")
DE.sim.SP$Median = as.numeric(DE.sim.SP$Median)
DE.sim.SP$Bottom = as.numeric(DE.sim.SP$Bottom)
DE.sim.SP$Top  =as.numeric(DE.sim.SP$Top)
DE.sim.SP$Shape <- factor(DE.sim.SP$Shape, levels = c("Spherical", "Rod", "Plate", "Others"))


P.SP <- ggplot()+
  geom_line(data = DE.sim.SP, aes(x = Shape, y = Median, group = 1), color = "darkgreen")+
  scale_y_continuous(limits = c(-2.5,2.5), breaks = c(-2.5,-1.5,-0.5,0.5,1.5,2.5))+
  geom_errorbar(data = DE.sim.SP, aes(x = Shape, ymin = Bottom, ymax = Top, color = "darkgreen"), width = 0.2)+
  scale_color_manual(values = "darkgreen")+
  geom_point(data = DE.sim.SP, aes(x = Shape, y = Median), color = "#d12920", size = 3)+
  geom_hline(yintercept = log10(1), color = "blue", size = 0.5, linetype = "twodash")+
  ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  #ylab("")+
  xlab("Shape")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 14, family = "serif"))

p.MAT <- P.MAT + theme(plot.margin = unit(c(0.5,0.5,0,0.5), "cm"))
p.SP  <- P.SP + theme(aspect.ratio = 1/1,
                      plot.margin = unit(c(0.5, 0.5, 0,0.5),"cm"))
p.logHD <- P.logHD + theme(plot.margin = unit(c(0.5, 0, 0.5, 0),"cm"))
p.ZP <- P.ZP + theme(plot.margin = unit(c(0.5, 0, 0.5, 0),"cm"))
p.Cancer <- P.Cancer+ theme(plot.margin = unit(c(0.5,0,0.5,0), "cm"))
p.TS <- P.TS  + theme(plot.margin = unit(c(0.5,0,0.5,0), "cm"))

ggsave("ONM_MAT_AUC_ID.tiff", scale = 1,
       plot = p.MAT,
       path = "C:/Users/chenqiran/OneDrive - University of Florida/Nano data analysis/Submission_ACS Nano/new plots",
       width = 15, height = 10, units = "cm", dpi = 320)

ggsave("ONM_SP_AUC_ID.tiff", scale = 1,
       plot = p.SP,
       path = "C:/Users/chenqiran/OneDrive - University of Florida/Nano data analysis/Submission_ACS Nano/new plots",
       width = 10, height = 10, units = "cm", dpi = 320)


ggsave("ONM_logHD_AUC_ID.tiff", scale = 1,
       plot = p.logHD,
       path = "C:/Users/chenqiran/OneDrive - University of Florida/Nano data analysis/Submission_ACS Nano/new plots",
       width = 12, height = 10, units = "cm", dpi = 320)

ggsave("ONM_ZP_AUC_ID.tiff", scale = 1,
       plot = p.ZP,
       path = "C:/Users/chenqiran/OneDrive - University of Florida/Nano data analysis/Submission_ACS Nano/new plots",
       width = 12, height = 10, units = "cm", dpi = 320)

ggsave("ONM_Cancer_AUC_ID.tiff", scale = 1,
       plot = p.Cancer,
       path = "C:/Users/chenqiran/OneDrive - University of Florida/Nano data analysis/Submission_ACS Nano/new plots",
       width = 22, height = 10, units = "cm", dpi = 320)

ggsave("ONM_TS_AUC_ID.tiff", scale = 1,
       plot = p.TS,
       path = "C:/Users/chenqiran/OneDrive - University of Florida/Nano data analysis/Submission_ACS Nano/new plots",
       width = 5, height = 10, units = "cm", dpi = 320)
