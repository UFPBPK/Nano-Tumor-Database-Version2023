library(dplyr)

data <- readRDS("Delivery efficiency_IDg.RDS")
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data)

data.log <- data %>% mutate(log.DE_liver = log(DE_liver, 10),
                            log.DE_heart = log(DE_heart, 10),
                            log.DE_spleen = log(DE_spleen, 10),
                            log.DE_kidney = log(DE_kidney, 10),
                            log.DE_lung  = log(DE_lung, 10))



organ.Type <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Particle.Type, data = data.log)
summary(organ.Type)   # Particle Type is a significant predictor, p = 0.0005343**
summary.aov(organ.Type)   #Liver: 0.008879**; Heart: 0.1673; Spleen: 0.0001937***, Kidney: 0.2288; Lung: 0.3444

organ.MAT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ material, data = data.log)
summary(organ.MAT)    # Materials is a significant predictor, p = 3.508e-06***
summary.aov(organ.MAT)   #Liver: 0.0346*; Heart: 0.00542*; Spleen: 8.42e-05***, Kidney: 0.00287**; Lung: 0.1654

organ.TS <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Targeting.Strategy, data = data.log)
summary(organ.TS)     # Targeting strategy is not a significant predictor, p = 0.1417
summary.aov(organ.TS)   #Liver: 0.2573; Heart: 0.988; Spleen: 0.3705, Kidney: 0.2266; Lung: 0.7857

organ.CT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Cancer, data = data.log)
summary(organ.CT)     # Cancer is a significant predictor, p = 2.38e-07***
summary.aov(organ.CT)   #Liver: 0.002171 **; Heart:  0.005653**; Spleen: 0.0003068***, Kidney: 0.004179**; Lung: 0.003108 **

organ.TM <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Tumor.Model, data = data.log)
summary(organ.TM)     # Tumor model is a significant predictor, p = 2.296e-06***
summary.aov(organ.TM)   #Liver: 8.06e-06***; Heart: 0.0342*; Spleen: 0.002999***, Kidney: 0.4896; Lung: 0.008705**

organ.shape <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ NM.Shape, data = data.log)
summary(organ.shape)     # Shape is a significant predictor, p = 1.083e-05 ***
summary.aov(organ.shape)   #Liver: 0.03492*; Heart: 0.8487; Spleen: 0.009585**, Kidney: 0.4834; Lung: 0.239

organ.HD <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ HD.category, data = data.log)
summary(organ.HD)     # HD category is a significant predictor, p = 1.96e-10 ***
summary.aov(organ.HD)   #Liver: 2.801e-06 ***; Heart: 0.01141*; Spleen: 1.111e-05***, Kidney: 0.08061; Lung: 4.5e-05***

organ.SC <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Surface.Charge, data = data.log)
summary(organ.SC)     # Surface charge is not a significant predictor, p = 0.0783
summary.aov(organ.SC)   #Liver: 0.08394 *; Heart: 0.01641 *; Spleen: 0.09703, Kidney: 0.0009109  **; Lung: 0.04067 *


#Y <- cbind(data.log$log.DE_liver, data.log$log.DE_heart, data.log$log.DE_spleen, data.log$log.DE_kidney, data.log$log.DE_lung)

#fit <- manova(Y ~ Particle.Type + material + Targeting.Strategy +  Cancer + Tumor.Model + NM.Shape + HD.category + Surface.Charge, data = data.log)
#summary(fit, test = "Pillai")
#summary.aov(fit)

