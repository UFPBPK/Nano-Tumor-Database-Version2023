library(dplyr)
library(ggplot2)
library(ggdist)
library(ggsci)

DE <- readRDS("Delivery efficiency_IDg.RDS")
DE <- as.data.frame(DE)
heart <- na.omit(cbind(Organ = "Heart", DE = DE$DE_heart))
liver <- na.omit(cbind(Organ = "Liver", DE = DE$DE_liver))
lung  <- na.omit(cbind(Organ = "Lung", DE = DE$DE_lung)) 
spleen <- na.omit(cbind(Organ = "Spleen", DE = DE$DE_spleen))
kidney <- na.omit(cbind(Organ = "Kidney", DE = DE$DE_kidney))

Organs <- rbind.data.frame(heart, liver, lung, spleen, kidney)
Organs.log <- Organs %>% mutate(DE.log = log(as.numeric(DE),10))

p1 <- ggplot(Organs.log,aes(Organ, DE.log))+
  ggdist::stat_halfeye(aes(color = Organ, fill = Organ), adjust = 0.5, width = 0.7, .width = 0, justification = -0.2, point_colour = NA)+
  geom_boxplot(aes(color = Organ),width = 0.2, outlier.shape = NA)+
  geom_jitter(aes(color = Organ), width = 0.05, alpha = 0.2)+
  scale_x_discrete(limits = c("Kidney","Spleen", "Lung", "Liver","Heart" ))+
  coord_flip()+
  scale_color_jco()+
  scale_fill_jco()+
  ylab("Log DE_%ID/g")+
  xlab("")+
  theme_bw()+
  theme(panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        axis.line.x = element_line(),
        axis.line.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 14, margin = margin(t = 20)),
        axis.title.y = element_text(family = "serif",size = 12),
        axis.text.y = element_text(size = 12, family = "serif", face = "bold"),
        axis.text.x = element_text(size = 12, family = "serif"),
        plot.title = element_text(size = 12, family = "serif"),
        plot.title.position = "plot")+
  theme(legend.position = "none")

ggsave("Organ AUC_IDg.tiff",scale = 1,
       plot = p1,
       path = "C:/Users/chenqiran/Desktop",
       width = 20, height = 12, units = "cm",dpi=320)

Organs$DE <- as.numeric(Organs$DE)

summary.DE <- Organs %>% group_by(Organ) %>%
  summarise(median = median(DE),
            mean = mean(DE),
            std = sd(DE),
            lower = quantile(DE, 0.025),
            upper = quantile(DE, 0.975),
            N = length(DE))
