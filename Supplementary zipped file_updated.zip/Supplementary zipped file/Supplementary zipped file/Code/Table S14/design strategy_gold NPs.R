library(dplyr)

#Import the data of AUC-based (Method 1) in the unit of %ID
data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data[2:7])

#Convert variables
data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))%>%
  mutate(ONM.category = recode(Organic.Material,
                               "Polymeric" = "Polymeric",
                               "Dendrimer" = "Dendrimer",
                               "Liposome"  = "Liposome",
                               "Hydrogel"  = "Hydrogel",
                               .default    = "ONM others"))%>%
  mutate(material = ifelse(Particle.Type == "Inorganic",INM.category,
                           ifelse(Particle.Type == "Organic",ONM.category,"Hybrid")))%>%
  mutate(Cancer = recode(Cancer.type,
                         "Brain"  = "Brain",
                         "Breast" = "Breast",
                         "Cervix" = "Cervix",
                         "Colon"  = "Colon",
                         "Glioma" = "Glioma",
                         "Liver"  = "Liver",
                         "Lung"   = "Lung",
                         "Ovary"  = "Ovary",
                         "Pancreas" = "Pancreas",
                         "Prostate" = "Prostate",
                         "Sarcoma"= "Sarcoma",
                         "Skin"   = "Skin",
                         .default = "Others"))%>% 
  mutate(NM.Shape = recode(NM.Shape, 
                           "Rod" = "Rod",
                           "Spherical" = "Spherical",
                           "Plate" = "Plate",
                           .default = "Others"))%>%
  mutate(HD.category = cut(NM.Hydrodnamic.Size.nm., breaks = c(0,10,100,200,Inf), 
                           labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))

INM <- data %>%  filter(Particle.Type == "Inorganic")
Gold <- INM %>%  filter(Inorganic.Material == "Gold")

fit_full.Gold <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = Gold)
best.Gold <- ols_step_best_subset(fit_full.Gold)
print(best.Gold)
best_final.Gold.1 <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer +  log.HD + PDI, data = Gold)
Summary <- summary(best_final.Gold.1)

df <- data.frame(Targeting  = sample(unique(Gold$Targeting.Strategy), 1000, replace = TRUE),
                 Cancer = sample(c("Ovary", "Pancreas", "Prostate", "Skin", "Breast","Others"), 1000, replace = TRUE),
                 log.HD = runif(1000, min = min(Gold$log.HD, na.rm = TRUE), max = quantile(Gold$log.HD, 0.975, na.rm = TRUE)),
                 PDI = runif(1000, min = 0, max = 1.0))

df <- df %>% mutate(TS = recode(Targeting, 
                                "Passive" = Summary$coefficients[2,1],
                                "Active" = 0),
                    cancer = recode(Cancer,
                                    "Ovary" = Summary$coefficients[4,1],
                                    "Pancreas" = Summary$coefficients[5,1],
                                    "Prostate" = Summary$coefficients[6,1],
                                    "Skin" = Summary$coefficients[7,1],
                                    "Others" = Summary$coefficients[3,1],
                                    "Breast" = 0))
df <- df %>% mutate(log.DE = Summary$coefficients[1,1] + TS + Summary$coefficients[8,1] *log.HD + cancer + Summary$coefficients[9,1] * PDI,
                    DE = 10^log.DE)

df <- df %>%  mutate(HD = 10^log.HD,
                     HD.category = cut(HD, breaks = c(0,10,100,200,Inf), labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))
df <- df %>% mutate(PDII = cut(PDI, breaks = c(0, 0.05, 0.3, 1), labels = c("<0.05", "0.05-0.3", ">0.3"), include.lowest = TRUE))
df <- df %>% dplyr :: select(Targeting, Cancer, HD.category, PDII, DE)

write.csv(df, "Gold NP design strategy.csv")
