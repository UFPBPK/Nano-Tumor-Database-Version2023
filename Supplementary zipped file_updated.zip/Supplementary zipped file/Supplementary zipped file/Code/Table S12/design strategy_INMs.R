library(dplyr)

#Import the data of AUC-based (Method 1) in the unit of %ID
data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data[2:7])

#Convert variables
data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))%>%
  mutate(ONM.category = recode(Organic.Material,
                               "Polymeric" = "Polymeric",
                               "Dendrimer" = "Dendrimer",
                               "Liposome"  = "Liposome",
                               "Hydrogel"  = "Hydrogel",
                               .default    = "ONM others"))%>%
  mutate(material = ifelse(Particle.Type == "Inorganic",INM.category,
                           ifelse(Particle.Type == "Organic",ONM.category,"Hybrid")))%>%
  mutate(Cancer = recode(Cancer.type,
                         "Brain"  = "Brain",
                         "Breast" = "Breast",
                         "Cervix" = "Cervix",
                         "Colon"  = "Colon",
                         "Glioma" = "Glioma",
                         "Liver"  = "Liver",
                         "Lung"   = "Lung",
                         "Ovary"  = "Ovary",
                         "Pancreas" = "Pancreas",
                         "Prostate" = "Prostate",
                         "Sarcoma"= "Sarcoma",
                         "Skin"   = "Skin",
                         .default = "Others"))%>% 
  mutate(NM.Shape = recode(NM.Shape, 
                           "Rod" = "Rod",
                           "Spherical" = "Spherical",
                           "Plate" = "Plate",
                           .default = "Others"))%>%
  mutate(HD.category = cut(NM.Hydrodnamic.Size.nm., breaks = c(0,10,100,200,Inf), 
                           labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))

INM <- data %>%  filter(Particle.Type == "Inorganic")
fit_best.INM <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV.+PDI, data = INM)
best.INM <- ols_step_best_subset(fit_best.INM)
print(best.INM)
best_final.INM.1 <- lm(log.DE_tumor ~ material + Cancer + Tumor.Model + log.HD + PDI, data = INM)
Summary <- summary(best_final.INM.1)

df <- data.frame(Material  = sample(unique(INM$material), 1000, replace = TRUE),
                 Cancer = sample(c("Breast", "Cervix", "Colon", "Lung", "Ovary","Pancreas", "Prostate", "Skin", "Others", "Brain"), 1000, replace = TRUE),
                 Tumor.Model = sample(unique(INM$Tumor.Model), 1000, replace = TRUE),
                 log.HD = runif(1000, min = min(INM$log.HD, na.rm = TRUE), max = quantile(INM$log.HD, 0.975, na.rm = TRUE)),
                 PDI = runif(1000, min = 0, max = 1.0))

df <- df %>% mutate(MAT = recode(Material,
                                 "Iron Oxide" = Summary$coefficients[2,1],
                                 "Other"      = Summary$coefficients[3,1],
                                 "Silica"     = Summary$coefficients[4,1],
                                 "Gold"       = 0),
                    cancer = recode(Cancer,
                                    "Breast"   = Summary$coefficients[5,1],
                                    "Cervix"   = Summary$coefficients[6,1],
                                    "Colon"    = Summary$coefficients[7,1],
                                    "Lung"     = Summary$coefficients[8,1],
                                    "Ovary"    = Summary$coefficients[10,1],
                                    "Pancreas" = Summary$coefficients[11,1],
                                    "Prostate" = Summary$coefficients[12,1],
                                    "Skin"     = Summary$coefficients[13,1],
                                    "Others"   = Summary$coefficients[9,1],
                                    .default    = 0),
                    TM = recode(Tumor.Model,
                                "Allograft Orthotopic" = Summary$coefficients[14,1],
                                "Xenograft Heterotopic"= Summary$coefficients[15,1],
                                "Xenograft Orthotopic" = Summary$coefficients[16,1],
                                "Allograft Heterotopic"= 0))
df <- df %>% mutate(log.DE = Summary$coefficients[1,1] + MAT + Summary$coefficients[17,1]*log.HD + cancer + TM + Summary$coefficients[18,1] * PDI,
                    DE = 10^log.DE)

df <- df %>%  mutate(HD = 10^log.HD,
                     HD.category = cut(HD, breaks = c(0,10,100,200,Inf), labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))

df <- df %>% mutate(PDII = cut(PDI, breaks = c(0, 0.05, 0.3, 1), labels = c("<0.05", "0.05-0.3", ">0.3"), include.lowest = TRUE))

df <- df %>% dplyr :: select(Material, Cancer, HD.category, Tumor.Model, PDII, DE)

write.csv(df, "INM design strategy.csv")
