library(dplyr)

data <- readRDS("Cmax results.RDS")
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data)

data.log <- data %>% mutate(log.DE_liver = log(Cmax.liver, 10),
                            log.DE_heart = log(Cmax.heart, 10),
                            log.DE_spleen = log(Cmax.spleen, 10),
                            log.DE_kidney = log(Cmax.kidney, 10),
                            log.DE_lung  = log(Cmax.lung, 10))



organ.Type <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Particle.Type, data = data.log)
summary(organ.Type)   # Particle Type is a significant predictor, p = 0.008872**
summary.Type <- summary.aov(organ.Type)   #Liver: 0.09757; Heart: 0.6596; Spleen: 0.007579**, Kidney: 0.8359; Lung: 0.5422
p.type <- c(summary.Type$` Response log.DE_heart`$`Pr(>F)`[1],
            summary.Type$` Response log.DE_liver`$`Pr(>F)`[1],
            summary.Type$` Response log.DE_spleen`$`Pr(>F)`[1],
            summary.Type$` Response log.DE_kidney`$`Pr(>F)`[1],
            summary.Type$` Response log.DE_lung`$`Pr(>F)`[1])

organ.MAT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ material, data = data.log)
summary(organ.MAT)    # Materials is a significant predictor, p = 1.348e-06 ***
summary.MAT <- summary.aov(organ.MAT)   #Liver: 0.1737; Heart: 0.02611*; Spleen: 0.004261**, Kidney: 0.00525**; Lung: 0.2253
p.MAT <- c(summary.MAT$` Response log.DE_heart`$`Pr(>F)`[1],
            summary.MAT$` Response log.DE_liver`$`Pr(>F)`[1],
            summary.MAT$` Response log.DE_spleen`$`Pr(>F)`[1],
            summary.MAT$` Response log.DE_kidney`$`Pr(>F)`[1],
            summary.MAT$` Response log.DE_lung`$`Pr(>F)`[1])

organ.TS <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Targeting.Strategy, data = data.log)
summary(organ.TS)     # Targeting strategy is not a significant predictor, p = 0.06811 
summary.TS <- summary.aov(organ.TS)   #Liver: 0.2044; Heart: 0.2628; Spleen: 0.07296, Kidney: 0.6338; Lung: 0.2456
p.TS <- c(summary.TS$` Response log.DE_heart`$`Pr(>F)`[1],
           summary.TS$` Response log.DE_liver`$`Pr(>F)`[1],
           summary.TS$` Response log.DE_spleen`$`Pr(>F)`[1],
           summary.TS$` Response log.DE_kidney`$`Pr(>F)`[1],
           summary.TS$` Response log.DE_lung`$`Pr(>F)`[1])

organ.CT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Cancer, data = data.log)
summary(organ.CT)     # Cancer is a significant predictor, p = 3.636e-09 ***
summary.CT <- summary.aov(organ.CT)   #Liver: 0.003262**; Heart: 0.06466; Spleen: 9.689e-05***, Kidney: 0.002515**; Lung: 0.01769*
p.CT <- c(summary.CT$` Response log.DE_heart`$`Pr(>F)`[1],
          summary.CT$` Response log.DE_liver`$`Pr(>F)`[1],
          summary.CT$` Response log.DE_spleen`$`Pr(>F)`[1],
          summary.CT$` Response log.DE_kidney`$`Pr(>F)`[1],
          summary.CT$` Response log.DE_lung`$`Pr(>F)`[1])

organ.TM <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Tumor.Model, data = data.log)
summary(organ.TM)     # Tumor model is a significant predictor, p = 5.646e-06 ***
summary.TM <- summary.aov(organ.TM)   #Liver: 0.0001743***; Heart: 0.02492*; Spleen: 0.0001965***, Kidney: 0.1895; Lung: 0.02462*
p.TM <- c(summary.TM$` Response log.DE_heart`$`Pr(>F)`[1],
          summary.TM$` Response log.DE_liver`$`Pr(>F)`[1],
          summary.TM$` Response log.DE_spleen`$`Pr(>F)`[1],
          summary.TM$` Response log.DE_kidney`$`Pr(>F)`[1],
          summary.TM$` Response log.DE_lung`$`Pr(>F)`[1])

organ.shape <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ NM.Shape, data = data.log)
summary(organ.shape)     # Shape is a significant predictor, p = 7.33e-07 ***
summary.shape <- summary.aov(organ.shape)   #Liver: 0.06937; Heart: 0.9286; Spleen: 0.02943*, Kidney: 0.07096; Lung: 0.1769
p.shape <- c(summary.shape$` Response log.DE_heart`$`Pr(>F)`[1],
          summary.shape$` Response log.DE_liver`$`Pr(>F)`[1],
          summary.shape$` Response log.DE_spleen`$`Pr(>F)`[1],
          summary.shape$` Response log.DE_kidney`$`Pr(>F)`[1],
          summary.shape$` Response log.DE_lung`$`Pr(>F)`[1])

organ.HD <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ HD.category, data = data.log)
summary(organ.HD)     # HD category is a significant predictor, p = 7.006e-09 ***
summary.HD <- summary.aov(organ.HD)   #Liver: 1.19e-06 ***; Heart: 0.08267; Spleen: 3.706e-06***, Kidney: 0.1778; Lung: 0.0003607***
p.HD <- c(as.numeric(summary.HD$` Response log.DE_heart`$`Pr(>F)`[1]),
          as.numeric(summary.HD$` Response log.DE_liver`$`Pr(>F)`[1]),
          as.numeric(summary.HD$` Response log.DE_spleen`$`Pr(>F)`[1]),
          as.numeric(summary.HD$` Response log.DE_kidney`$`Pr(>F)`[1]),
          as.numeric(summary.HD$` Response log.DE_lung`$`Pr(>F)`[1]))

organ.SC <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Surface.Charge, data = data.log)
summary(organ.SC)     # Surface charge is not a significant predictor, p = 0.03139 *
summary.SC <- summary.aov(organ.SC)   #Liver: 0.0646; Heart: 0.002742 **; Spleen: 0.07155, Kidney: 0.003718 **; Lung: 0.1198
p.SC <- c(as.numeric(summary.SC$` Response log.DE_heart`$`Pr(>F)`[1]),
          as.numeric(summary.SC$` Response log.DE_liver`$`Pr(>F)`[1]),
          as.numeric(summary.SC$` Response log.DE_spleen`$`Pr(>F)`[1]),
          as.numeric(summary.SC$` Response log.DE_kidney`$`Pr(>F)`[1]),
          as.numeric(summary.SC$` Response log.DE_lung`$`Pr(>F)`[1]))


#Y <- cbind(data.log$log.DE_liver, data.log$log.DE_heart, data.log$log.DE_spleen, data.log$log.DE_kidney, data.log$log.DE_lung)

#fit <- manova(Y ~ Particle.Type + material + Targeting.Strategy +  Cancer + Tumor.Model + NM.Shape + HD.category + Surface.Charge, data = data.log)
#summary(fit, test = "Pillai")
#summary.aov(fit)

p.table <- rbind.data.frame(p.type, p.MAT, p.TS, p.CT, p.TM, p.shape, p.HD, p.SC)
colnames(p.table) <- c("heart","liver","spleen","kidney","lung")
write.csv(p.table,"P table MANOVA_Cmax_ID.csv")
