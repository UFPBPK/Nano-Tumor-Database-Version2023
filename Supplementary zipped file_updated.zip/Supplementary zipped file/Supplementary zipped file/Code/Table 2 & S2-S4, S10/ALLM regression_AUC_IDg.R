library(MASS)
library(dplyr)
library(olsrr)
library(PMCMRplus)
#1.2 single predictor
#1.3 regression for all data
#1.4 regression for inorganic data
#1.5 regression for organic data
#1.6 regression for polymeric data
#1.7 regression for gold data

data <- readRDS("Delivery efficiency_IDg.RDS")
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data)

hist(data$DE_tumor, probability=T) 

data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))

hist(data$log.DE_tumor, probability=T) 

shapiro.test(data$log.DE_tumor) 
shapiro.test(data$DE_tumor)


######### (1.2.1) Identify single significant predictor for all datasets (alpha=0.05) #############
# (1.2.1.1) Type - ANOVA 
levels(data$Particle.Type)
res.PS <- bartlett.test(log.DE_tumor ~ Particle.Type, data = data)
res.PS  
fit_Type <- aov(log.DE_tumor ~ Particle.Type, data = data)
summary(fit_Type) # Type is not a significant predictor; p = 0.0977
KT <- kruskal.test(log.DE_tumor ~ Particle.Type, data = data)
KT # Type is not a significant predictor; p = 0.05691
dscfAllPairsTest(x = data$log.DE_tumor, g = as.factor(data$Particle.Type))

# (1.2.1.2) MAT - ANOVA 

data <- data %>% mutate(ONM.category = recode(Organic.Material,
                                              "Polymeric" = "Polymeric",
                                              "Dendrimer" = "Dendrimer",
                                              "Liposome"  = "Liposome",
                                              "Hydrogel"  = "Hydrogel",
                                              .default    = "ONM others"))%>%
  mutate(material = ifelse(Particle.Type == "Inorganic",INM.category,
                           ifelse(Particle.Type == "Organic",ONM.category,"Hybrid")))

levels(data$material)
res.MAT <- bartlett.test(log.DE_tumor ~ material, data = data)
res.MAT
fit_MAT <- aov(log.DE_tumor ~ material, data = data)
summary(fit_MAT) # MAT is a significant predictor; p =9.18e-05 ***
KT <- kruskal.test(log.DE_tumor ~ material, data = data)
KT # MAT is a significant predictor; p = 0.0007031***
dscfAllPairsTest(x = data$log.DE_tumor, g = as.factor(data$material))

# (1.2.1.3) TS - ANOVA #
levels(data$Targeting.Strategy)
res.TS <- bartlett.test(log.DE_tumor ~ Targeting.Strategy, data = data)
res.TS
fit_TS <- aov(log.DE_tumor ~ Targeting.Strategy, data = data)
summary(fit_TS) # TS is a significant predictor; p = 0.0185 *
KT <- kruskal.test(log.DE_tumor ~ Targeting.Strategy, data = data)
KT # CT is a significant predictor; p = 0.0306*
dscfAllPairsTest(x = data$log.DE_tumor, g = as.factor(data$Targeting.Strategy))

# (1.2.1.4) CT - ANOVA #
data <- data %>% mutate(Cancer = recode(Cancer.type,
                                        "Brain"  = "Brain",
                                        "Breast" = "Breast",
                                        "Cervix" = "Cervix",
                                        "Colon"  = "Colon",
                                        "Glioma" = "Glioma",
                                        "Liver"  = "Liver",
                                        "Lung"   = "Lung",
                                        "Ovary"  = "Ovary",
                                        "Pancreas" = "Pancreas",
                                        "Prostate" = "Prostate",
                                        "Sarcoma"= "Sarcoma",
                                        "Skin"   = "Skin",
                                        .default = "Others"))
levels(data$Cancer)
res.CT <- bartlett.test(log.DE_tumor ~ Cancer, data = data)
res.CT
fit_CT <- aov(log.DE_tumor ~ Cancer, data = data)
summary(fit_CT) # CT is a significant predictor; p = 7.12e-05 ***
KT <- kruskal.test(log.DE_tumor ~ Cancer, data = data)
KT # CT is a significant predictor; p = 9.669e-06 ***
dscfAllPairsTest(x = data$log.DE_tumor, g = as.factor(data$Cancer))


# (1.2.1.5) TM - ANOVA #
levels(data$Tumor.Model)
res.TM <- bartlett.test(log.DE_tumor ~ Tumor.Model, data = data)
res.TM
fit_TM <- aov(log.DE_tumor ~ Tumor.Model, data = data)
summary(fit_TM) # TM is not a significant predictor; p = 0.215
KT <- kruskal.test(log.DE_tumor ~ Tumor.Model, data = data)
KT # CT is a significant predictor; p = 0.4018
pairwise.wilcox.test(data$log.DE_tumor, data$Tumor.Model, p.adjust.method = "BH")


# (1.2.1.6) Shape - ANOVA #
data <- data %>% mutate(NM.Shape = recode(NM.Shape, 
                                          "Rod" = "Rod",
                                          "Spherical" = "Spherical",
                                          "Plate" = "Plate",
                                          .default = "Others"))
levels(data$NM.Shape)
res.Shape <- bartlett.test(log.DE_tumor ~ NM.Shape, data = data)
res.Shape
fit_SP <- aov(log.DE_tumor ~ NM.Shape, data = data)
summary(fit_SP) # Shape is not a significant predictor; p = 0.642
KT <- kruskal.test(log.DE_tumor ~ NM.Shape, data = data)
KT # Shape is not a significant predictor; p = 0.6891

# (1.2.1.7) log(HD) - simple linear regression #
data <- data %>% mutate(log.HD = log(NM.Hydrodnamic.Size.nm., 10))
plot(data$log.HD, data$log.DE_tumor)
fit_LGHD <- lm(log.DE_tumor ~ log.HD, data = data)
summary(fit_LGHD) # log(HD) is not a significant predictor; p = 0.4693

# (1.2.1.8) HD catagory - ANOVA #
data <- data %>%  mutate(HD.category = cut(NM.Hydrodnamic.Size.nm., breaks = c(0,10,100,200,Inf), labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))
levels(data$HD.category)
res.HD <- bartlett.test(log.DE_tumor ~ HD.category, data = data)
res.HD
fit_HD <- aov(log.DE_tumor ~ HD.category, data = data)
summary(fit_HD) # HD category is not a significant predictor; p = 0.785
KT <- kruskal.test(log.DE_tumor ~ HD.category, data = data)
KT # HD category is not a significant predictor; p = 0.6511


# (1.2.1.9) ZP - simple linear regression #
plot(data$Zeta.potential.mV., data$log.DE_tumor)
fit_ZP <- lm(log.DE_tumor ~ Zeta.potential.mV., data = data)
summary(fit_ZP) # ZP is a significant predictor; p = 3.324e-05 ***

#(1.2.1.10) Surface Charge - ANOVA #
levels(data$Surface.Charge)
res.SC <- bartlett.test(log.DE_tumor ~ Surface.Charge, data = data)
res.SC
fit_SC <- aov(log.DE_tumor ~Surface.Charge, data = data)
summary(fit_SC) # Surface charge is not a significant predictor; p = 0.00112**
KT <- kruskal.test(log.DE_tumor ~ Surface.Charge, data = data)
KT # Surface charge is not a significant predictor; p = 0.001905**
dscfAllPairsTest(x = data$log.DE_tumor, g = as.factor(data$Surface.Charge))

#(1.2.1.11) PDI - simple linear regression #
plot(data$PDI, data$log.DE_tumor)
fit_PDI <- lm(log.DE_tumor ~ PDI, data = data)
summary(fit_PDI) # PDI is not a significant predictor; p = 0.8922


stats <- function(x){
  r2 <- summary(x)$r.squared
  r2a <- summary(x)$adj.r.squared
  f <- summary(x)$fstatistic
  p <- pf(f[1],f[2],f[3],lower.tail=F)
  error <- summary(x)$sigma
  y <- c(r2, r2a, f, p, error)
  return(y)
}

######### (1.3) Multivariable regression model ###################
# (1.3.1.1) Full model - ignore significance of predictors #
fit_full.ZP <- lm(log.DE_tumor ~ Particle.Type + material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = data)
All.full.ZP<- stats(fit_full.ZP)


# (1.3.1.2) Full model - ignore significance of predictors #
fit_full.SC <- lm(log.DE_tumor ~ Particle.Type + material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + PDI + Surface.Charge, data = data)
All.full.SC <- stats(fit_full.SC)

# (1.3.2.1) Automatic best model #
fit_best <- lm(log.DE_tumor ~ Particle.Type + material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV.+ PDI, data = data)
best <- ols_step_best_subset(fit_best)
plot(best)
print(best) # The best subsets of predictors are: material, targeting strategy, Cancer, shape, log.HD, zeta.potential, PDI

# (1.3.2.2) Automatic best model #
fit_best <- lm(log.DE_tumor ~ Particle.Type + material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + PDI + Surface.Charge , data = data)
best <- ols_step_best_subset(fit_best)
plot(best)
print(best) # The best subsets of predictors are: material, targeting strategy, Cancer, tumor model, shape, log.HD, surface charge, PDI

best_final.1 <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + NM.Shape + log.HD + Zeta.potential.mV.+ PDI, data = data)
All.Best.ZP <- stats(best_final.1)

best_final.2 <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + PDI + Surface.Charge, data = data)
All.Best.SC <- stats(best_final.2)


######### (1.4) Multivariable regression model for Inorganic data ###################
INM <- data %>%  filter(Particle.Type == "Inorganic")

# (1.4.1.1) Full model - ignore significance of predictors #
fit_full.INM.ZP <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = INM)
INM.full.ZP <- stats(fit_full.INM.ZP)

# (1.4.1.2) Full model - ignore significance of predictors #
fit_full.INM.SC <- lm(log.DE_tumor ~  material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + PDI + Surface.Charge, data = INM)
INM.full.SC <- stats(fit_full.INM.SC)

# (1.4.2.1) Automatic best model #
fit_best.INM <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV.+ PDI, data = INM)
best.INM <- ols_step_best_subset(fit_best.INM)
plot(best.INM)
print(best.INM) # The best subsets of predictors are: material, targeting strategy, Cancer, Tumor model, log.HD, PDI

# (1.4.2.2) Automatic best model #
fit_best.INM <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + PDI + Surface.Charge , data = INM)
best.INM <- ols_step_best_subset(fit_best.INM)
plot(best.INM)
print(best.INM) # The best subsets of predictors are: Cancer, surface charge, PDI

best_final.INM.1 <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + log.HD + PDI, data = INM)
INM.best.ZP <- stats(best_final.INM.1)

best_final.INM.2 <- lm(log.DE_tumor ~ Cancer + PDI + Surface.Charge, data = INM)
INM.best.SC <- stats(best_final.INM.2)

######### (1.5) Multivariable regression model for Organic data ###################
ONM <- data %>%  filter(Particle.Type == "Organic")

# (1.5.1.1) Full model - ignore significance of predictors #
fit_full.ONM <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = ONM)
ONM.full.ZP <- stats(fit_full.ONM)

# (1.5.1.2) Full model - ignore significance of predictors #
fit_full.ONM <- lm(log.DE_tumor ~  material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + PDI + Surface.Charge, data = ONM)
ONM.full.SC <- stats(fit_full.ONM)

# (1.5.2.1) Automatic best model #
fit_best.ONM <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV.+ PDI, data = ONM)
best.ONM <- ols_step_best_subset(fit_best.ONM)
plot(best.ONM)
print(best.ONM) # The best subsets of predictors are: material, Shape, Cancer, log(HD), zeta.potential

# (1.5.2.2) Automatic best model #
fit_best.ONM <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + PDI + Surface.Charge, data = ONM)
best.ONM <- ols_step_best_subset(fit_best.ONM)
plot(best.ONM)
print(best.ONM) # The best subsets of predictors are: material, Cancer, log.HD, surface charge, Shape

best_final.ONM.1 <- lm(log.DE_tumor ~ material + log.HD + Cancer + NM.Shape + Zeta.potential.mV., data = ONM)
ONM.Best.ZP <- stats(best_final.ONM.1)

best_final.ONM.2 <- lm(log.DE_tumor ~ material + Cancer + NM.Shape + log.HD + Surface.Charge, data = ONM)
ONM.Best.SC <- stats(best_final.ONM.2)


######### (1.6) Multivariable regression model for Polymeric data ###################
Polymer <- ONM %>%  filter(Organic.Material == "Polymeric")

fit_full.poly <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = Polymer)
Poly.full.ZP <- stats(fit_full.poly)

# (1.6.1.2) Full model - ignore significance of predictors #
fit_full.poly <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + PDI + Surface.Charge, data = Polymer)
Poly.full.SC <- stats(fit_full.poly)


# (1.6.2.1) Automatic best model #
fit_best.poly <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV.+ PDI, data = Polymer)
best.poly <- ols_step_best_subset(fit_best.poly)
plot(best.poly)
print(best.poly) # The best subsets of predictors are: Cancer, tumor model, Shape, zeta.potential, PDI

# (1.6.2.2) Automatic best model #
fit_best.poly <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + PDI + Surface.Charge, data = Polymer)
best.poly <- ols_step_best_subset(fit_best.poly)
plot(best.poly)
print(best.poly) # The best subsets of predictors are: Cancer, tumor model, shape, surface charge, PDI

best_final.poly.1 <- lm(log.DE_tumor ~ Cancer + Tumor.Model + NM.Shape + Zeta.potential.mV.+ PDI, data = Polymer)
Poly.Best.ZP <- stats(best_final.poly.1)

best_final.poly.2 <- lm(log.DE_tumor ~ Cancer + Tumor.Model + NM.Shape + PDI + Surface.Charge, data = Polymer)
Poly.Best.SC <- stats(best_final.poly.2)

######### (1.7) Multivariable regression model for GOld data ###################
Gold <- INM %>%  filter(Inorganic.Material == "Gold")

fit_full.Gold <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = Gold)
Gold.full.ZP <- stats(fit_full.Gold)

# (1.7.1.2) Full model - ignore significance of predictors #
fit_full.Gold <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + PDI + Surface.Charge, data = Gold)
Gold.full.SC <- stats(fit_full.Gold)

# (1.7.2.1) Automatic best model #
fit_best.Gold <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV.+ PDI, data = Gold)
best.Gold <- ols_step_best_subset(fit_best.Gold)
plot(best.Gold)
print(best.Gold) # The best subsets of predictors are: Targeting strategy, Cancer, Tumor Model, log.HD, PDI

# (1.7.2.2) Automatic best model #
fit_best.Gold <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + PDI + Surface.Charge, data = Gold)
best.Gold <- ols_step_best_subset(fit_best.Gold)
plot(best.Gold)
print(best.Gold) # The best subsets of predictors are: Targeting strategy, Cancer, log.HD, PDI, Surface Charge

best_final.Gold.1 <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer +  Tumor.Model + log.HD + PDI, data = Gold)
Gold.Best.ZP <- stats(best_final.Gold.1)

best_final.Gold.2 <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + log.HD + PDI + Surface.Charge, data = Gold)
Gold.Best.SC <- stats(best_final.Gold.2)

Stats.ZP <- rbind.data.frame(All.full = All.full.ZP,
                             All.best = All.Best.ZP,
                             INM.full = INM.full.ZP,
                             INM.best = INM.best.ZP,
                             ONM.full = ONM.full.ZP,
                             ONM.best = ONM.Best.ZP,
                             Poly.full = Poly.full.ZP,
                             Poly.best = Poly.Best.ZP,
                             Gold.full = Gold.full.ZP,
                             Gold.best = Gold.Best.ZP)

Stats.SC <- rbind.data.frame(All.full = All.full.SC,
                             All.best = All.Best.SC,
                             INM.full = INM.full.SC,
                             INM.best = INM.best.SC,
                             ONM.full = ONM.full.SC,
                             ONM.best = ONM.Best.SC,
                             Poly.full = Poly.full.SC,
                             Poly.best = Poly.Best.SC,
                             Gold.full = Gold.full.SC,
                             Gold.best = Gold.Best.SC)

colnames(Stats.ZP) <- colnames(Stats.SC) <- c("r2", "Adj R2", "F", "df1" , "df2" , "p", "Residual standard error")

write.csv(Stats.ZP,"Stats ZP_AUC_IDg.csv")
write.csv(Stats.SC,"Stats SC_AUC_IDg.csv")
saveRDS(Stats.ZP,"Stats ZP_AUC_IDg.RDS")
saveRDS(Stats.SC,"Stats SC_AUC_IDg.RDS")
