library(dplyr)
library(heplots)

data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data[2:7])

data.log <- data %>% mutate(log.DE_liver = log(DE_liver, 10),
                            log.DE_heart = log(DE_heart, 10),
                            log.DE_spleen = log(DE_spleen, 10),
                            log.DE_kidney = log(DE_kidney, 10),
                            log.DE_lung  = log(DE_lung, 10))



organ.Type <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Particle.Type, data = data.log)
summary(organ.Type)   # Particle Type is a significant predictor, p = 0.003062 **
summary.aov(organ.Type)   #Liver: 0.00376**; Heart: 0.221; Spleen: 0.0001653***, Kidney: 0.2022; Lung: 0.2402

organ.MAT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ material, data = data.log)
summary(organ.MAT)    # Materials is a significant predictor, p = 3.739e-08***
summary.aov(organ.MAT)   #Liver: 0.0271*; Heart: 0.01117*; Spleen: 2.975e-05***, Kidney: 0.003792 **; Lung: 0.1234

organ.TS <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Targeting.Strategy, data = data.log)
summary(organ.TS)     # Targeting strategy is not a significant predictor, p = 0.04088 *
summary.aov(organ.TS)   #Liver: 0.2538; Heart: 0.628; Spleen: 0.2986, Kidney: 0.1973; Lung: 0.8977

organ.CT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Cancer, data = data.log)
summary(organ.CT)     # Cancer is a significant predictor, p = 2.195e-08***
summary.aov(organ.CT)   #Liver: 0.00208**; Heart: 0.004022**; Spleen: 0.0002147***, Kidney: 0.00814**; Lung: 0.00198**

organ.TM <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Tumor.Model, data = data.log)
summary(organ.TM)     # Tumor model is a significant predictor, p = 6.23e-05***
summary.aov(organ.TM)   #Liver: 2.608e-05***; Heart: 0.03977*; Spleen: 0.005344 ***, Kidney: 0.5016; Lung: 0.008178**

organ.shape <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ NM.Shape, data = data.log)
summary(organ.shape)     # Shape is a significant predictor, p = 9.174e-06 ***
summary.aov(organ.shape)   #Liver: 0.02729*; Heart: 0.8679; Spleen: 0.009336 **, Kidney: 0.5349; Lung: 0.2989

organ.HD <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ HD.category, data = data.log)
summary(organ.HD)     # HD category is a significant predictor, p = 8.334e-12***
summary.aov(organ.HD)   #Liver: 4.642e-07 ***; Heart: 0.004497*; Spleen: 1.569e-05***, Kidney: 0.06832; Lung: 1.48e-05***

organ.SC <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Surface.Charge, data = data.log)
summary(organ.SC)     # Surface charge is not a significant predictor, p = 0.03304*
summary.aov(organ.SC)   #Liver: 0.08925; Heart: 0.001084**; Spleen: 0.05233, Kidney: 0.002063**; Lung: 0.04034


#Y <- cbind(data.log$log.DE_liver, data.log$log.DE_heart, data.log$log.DE_spleen, data.log$log.DE_kidney, data.log$log.DE_lung)

#fit <- manova(Y ~ Particle.Type + material + Targeting.Strategy +  Cancer + Tumor.Model + NM.Shape + HD.category + Surface.Charge, data = data.log)
#summary(fit, test = "Pillai")
#summary.aov(fit)

