library(dplyr)
library(olsrr)
#Import the data of AUC-based (Method 1) in the unit of %ID
data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data[2:7])

#Convert variables
data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))%>%
  mutate(ONM.category = recode(Organic.Material,
                               "Polymeric" = "Polymeric",
                               "Dendrimer" = "Dendrimer",
                               "Liposome"  = "Liposome",
                               "Hydrogel"  = "Hydrogel",
                               .default    = "ONM others"))%>%
  mutate(material = ifelse(Particle.Type == "Inorganic",INM.category,
                           ifelse(Particle.Type == "Organic",ONM.category,"Hybrid")))%>%
  mutate(Cancer = recode(Cancer.type,
                         "Brain"  = "Brain",
                         "Breast" = "Breast",
                         "Cervix" = "Cervix",
                         "Colon"  = "Colon",
                         "Glioma" = "Glioma",
                         "Liver"  = "Liver",
                         "Lung"   = "Lung",
                         "Ovary"  = "Ovary",
                         "Pancreas" = "Pancreas",
                         "Prostate" = "Prostate",
                         "Sarcoma"= "Sarcoma",
                         "Skin"   = "Skin",
                         .default = "Others"))%>% 
  mutate(NM.Shape = recode(NM.Shape, 
                           "Rod" = "Rod",
                           "Spherical" = "Spherical",
                           "Plate" = "Plate",
                           .default = "Others"))%>%
  mutate(HD.category = cut(NM.Hydrodnamic.Size.nm., breaks = c(0,10,100,200,Inf), 
                           labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))

#Fit the best model of multivariate linear regression for all nanoparticles.

fit_best <- lm(log.DE_tumor ~ Particle.Type + material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV.+ PDI, data = data)
best <- ols_step_best_subset(fit_best)
print(best) # The best subsets of predictors are: material, Cancer, NM.Shape, log.HD, zeta.potential, PDI

best_final <- lm(log.DE_tumor ~ material + Cancer + NM.Shape + log.HD + Zeta.potential.mV.+ PDI, data = data)
Summary <- summary(best_final)

#Recode the nanoparticle features with the regression coefficients

data.sim <- data %>% mutate(MAT = recode(material,
                                         "Gold" = Summary$coefficients[2,1],
                                         "Hybrid" = Summary$coefficients[3,1],
                                         "Hydrogel" = Summary$coefficients[4,1],
                                         "Iron Oxide" = Summary$coefficients[5,1],
                                         "Liposome" = Summary$coefficients[6,1],
                                         "ONM others" = Summary$coefficients[7,1],
                                         "Other" = Summary$coefficients[8,1],
                                         "Polymeric" = Summary$coefficients[9,1],
                                         "Silica" = Summary$coefficients[10,1],
                                         .default = 0),
                            cancer = recode(Cancer.type,
                                            "Breast" = Summary$coefficients[11,1],
                                            "Cervix" = Summary$coefficients[12,1],
                                            "Colon" = Summary$coefficients[13,1],
                                            "Liver" = Summary$coefficients[14,1],
                                            "Lung" = Summary$coefficients[15,1],
                                            "Other" = Summary$coefficients[16,1],
                                            "Ovary" = Summary$coefficients[17,1],
                                            "Pancreas" = Summary$coefficients[18,1],
                                            "Prostate" = Summary$coefficients[19,1],
                                            "Sarcoma" = Summary$coefficients[20,1],
                                            "Skin" = Summary$coefficients[21,1],
                                            .default = 0),
                            SP = recode(NM.Shape,
                                        "Plate" = Summary$coefficients[22,1],
                                        "Rod" = Summary$coefficients[23,1],
                                        "Spherical" = Summary$coefficients[24,1],
                                        "Others" = 0))



#Simulate the independent variables in the best model
df <- data.frame(MAT = sample(data.sim$MAT, 10000, replace = TRUE),
                 SP  = sample(data.sim$SP, 10000, replace = TRUE),
                 Cancer = sample(data.sim$cancer, 10000, replace = TRUE),
                 log.HD = runif(10000, min = min(data.sim$log.HD, na.rm = TRUE), max = max(data.sim$log.HD, na.rm = TRUE)),
                 zeta = runif(10000, min = min(data.sim$Zeta.potential.mV., na.rm = TRUE), max = max(data.sim$Zeta.potential.mV., na.rm = TRUE)),
                 PDI = runif(10000, min = 0.5, max = 1.0))


df <- df %>% mutate(log.DE = Summary$coefficients[1,1] + MAT + SP + Summary$coefficients[25,1] * log.HD  + Cancer + Summary$coefficients[26,1] * zeta + Summary$coefficients[27,1] * PDI,
                    DE = 10^log.DE)

df <- round(df,6)

#Convert the results to nanoparticle information 
df.results <- df %>% mutate(Material =  recode(MAT, 
                                          "-0.618093" = "Gold"  ,
                                          "-1.125463" = "Silica" ,
                                          "-0.987165" = "Iron Oxide",
                                          "-1.069984" = "Other",
                                          "-0.571555" = "Hybrid",
                                          "-1.310576" = "Polymeric",
                                          "-1.938029" = "Liposome",
                                          "-2.049817" = "Hydrogel",
                                          "-1.655009" = "ONM others",
                                          .default = "Dendrimer"),
                            Shape = recode(SP,
                                           "0.989300" = "Spherical",
                                           "0.737649" = "Plate",
                                           "0.848088" = "Rod",
                                            .default = "Others"),
                            CCer = recode(Cancer,
                                          "0.449836" = "Cervix",
                                          "0.164501" = "Colon",
                                          "0.245365" = "Liver",
                                          "0.242561" = "Lung",
                                          "0.302778" = "Breast",
                                          "0.059078" = "Ovary",
                                          "0.519225" = "Skin",
                                          "-0.419254" = "Prostate",
                                          "-0.106631" = "Pancreas",
                                          "0.881816" = "Sarcoma",
                                          "0.424575" = "Others",
                                          .default = "Brain"))

#Categorize the NP features
df.results <- df.results %>% arrange(-DE) %>% 
  mutate(HD = 10^log.HD) %>%
  mutate(HD.category = cut(HD, breaks = c(0,10,100,200,Inf), 
                           labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE),
         surface.charge = cut(zeta, breaks = c(-Inf, -10, 10, Inf), labels = c("Negative", "Neutral", "Positive"), include.lowest = TRUE)) %>%
  select(Material, Shape, CCer,HD.category, surface.charge, DE)


write.csv(df.results, "DE strategy.csv")
