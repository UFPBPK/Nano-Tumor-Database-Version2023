library(dplyr)

data <- readRDS("Cmax results_IDg.RDS")
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data)

data.log <- data %>% mutate(log.DE_liver = log(Cmax.liver, 10),
                            log.DE_heart = log(Cmax.heart, 10),
                            log.DE_spleen = log(Cmax.spleen, 10),
                            log.DE_kidney = log(Cmax.kidney, 10),
                            log.DE_lung  = log(Cmax.lung, 10))



organ.Type <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Particle.Type, data = data.log)
summary(organ.Type)   # Particle Type is a significant predictor, p = 0.001339 **
summary.Type <- summary.aov(organ.Type)   #Liver: 0.1664; Heart: 0.5391; Spleen: 0.009496 **, Kidney: 0.827; Lung: 0.4651
p.type <- c(summary.Type$` Response log.DE_heart`$`Pr(>F)`[1],
            summary.Type$` Response log.DE_liver`$`Pr(>F)`[1],
            summary.Type$` Response log.DE_spleen`$`Pr(>F)`[1],
            summary.Type$` Response log.DE_kidney`$`Pr(>F)`[1],
            summary.Type$` Response log.DE_lung`$`Pr(>F)`[1])

organ.MAT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ material, data = data.log)
summary(organ.MAT)    # Materials is a significant predictor, p = 2.916e-05 ***
summary.MAT <- summary.aov(organ.MAT)   #Liver: 0.1927; Heart: 0.02191*; Spleen: 0.01072*, Kidney: 0.003218 **; Lung: 0.1357
p.MAT <- c(summary.MAT$` Response log.DE_heart`$`Pr(>F)`[1],
           summary.MAT$` Response log.DE_liver`$`Pr(>F)`[1],
           summary.MAT$` Response log.DE_spleen`$`Pr(>F)`[1],
           summary.MAT$` Response log.DE_kidney`$`Pr(>F)`[1],
           summary.MAT$` Response log.DE_lung`$`Pr(>F)`[1])

organ.TS <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Targeting.Strategy, data = data.log)
summary(organ.TS)     # Targeting strategy is not a significant predictor, p = 0.1677
summary.TS <- summary.aov(organ.TS)   #Liver: 0.213; Heart: 0.609; Spleen: 0.1059, Kidney: 0.6951; Lung: 0.1937
p.TS <- c(summary.TS$` Response log.DE_heart`$`Pr(>F)`[1],
          summary.TS$` Response log.DE_liver`$`Pr(>F)`[1],
          summary.TS$` Response log.DE_spleen`$`Pr(>F)`[1],
          summary.TS$` Response log.DE_kidney`$`Pr(>F)`[1],
          summary.TS$` Response log.DE_lung`$`Pr(>F)`[1])

organ.CT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Cancer, data = data.log)
summary(organ.CT)     # Cancer is a significant predictor, p = 9.753e-07 ***
summary.CT <- summary.aov(organ.CT)   #Liver: 0.003898 **; Heart: 0.08476; Spleen: 8.294e-05 ***, Kidney: 0.001921 **; Lung: 0.03988 *
p.CT <- c(summary.CT$` Response log.DE_heart`$`Pr(>F)`[1],
          summary.CT$` Response log.DE_liver`$`Pr(>F)`[1],
          summary.CT$` Response log.DE_spleen`$`Pr(>F)`[1],
          summary.CT$` Response log.DE_kidney`$`Pr(>F)`[1],
          summary.CT$` Response log.DE_lung`$`Pr(>F)`[1])

organ.TM <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Tumor.Model, data = data.log)
summary(organ.TM)     # Tumor model is a significant predictor, p = 3.524e-07 ***
summary.TM <- summary.aov(organ.TM)   #Liver: 5.861e-05 ***; Heart: 0.02035 *; Spleen: 6.443e-05 ***, Kidney: 0.2302; Lung: 0.03742 *
p.TM <- c(summary.TM$` Response log.DE_heart`$`Pr(>F)`[1],
          summary.TM$` Response log.DE_liver`$`Pr(>F)`[1],
          summary.TM$` Response log.DE_spleen`$`Pr(>F)`[1],
          summary.TM$` Response log.DE_kidney`$`Pr(>F)`[1],
          summary.TM$` Response log.DE_lung`$`Pr(>F)`[1])

organ.shape <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ NM.Shape, data = data.log)
summary(organ.shape)     # Shape is a significant predictor, p = 4.677e-07 ***
summary.shape <- summary.aov(organ.shape)   #Liver: 0.07202; Heart: 0.9458; Spleen: 0.03163 *, Kidney: 0.06175; Lung: 0.1169
p.shape <- c(summary.shape$` Response log.DE_heart`$`Pr(>F)`[1],
             summary.shape$` Response log.DE_liver`$`Pr(>F)`[1],
             summary.shape$` Response log.DE_spleen`$`Pr(>F)`[1],
             summary.shape$` Response log.DE_kidney`$`Pr(>F)`[1],
             summary.shape$` Response log.DE_lung`$`Pr(>F)`[1])

organ.HD <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ HD.category, data = data.log)
summary(organ.HD)     # HD category is a significant predictor, p = 3.416e-08 ***
summary.HD <- summary.aov(organ.HD)   #Liver: 6.147e-06 ***; Heart: 0.182; Spleen: 3.171e-06 ***, Kidney: 0.1885; Lung: 0.00076 ***
p.HD <- c(as.numeric(summary.HD$` Response log.DE_heart`$`Pr(>F)`[1]),
          as.numeric(summary.HD$` Response log.DE_liver`$`Pr(>F)`[1]),
          as.numeric(summary.HD$` Response log.DE_spleen`$`Pr(>F)`[1]),
          as.numeric(summary.HD$` Response log.DE_kidney`$`Pr(>F)`[1]),
          as.numeric(summary.HD$` Response log.DE_lung`$`Pr(>F)`[1]))

organ.SC <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Surface.Charge, data = data.log)
summary(organ.SC)     # Surface charge is not a significant predictor, p = 0.06263
summary.SC <- summary.aov(organ.SC)   #Liver: 0.05453; Heart: 0.03724 *; Spleen: 0.1249, Kidney: 0.001248 **; Lung: 0.1036
p.SC <- c(as.numeric(summary.SC$` Response log.DE_heart`$`Pr(>F)`[1]),
          as.numeric(summary.SC$` Response log.DE_liver`$`Pr(>F)`[1]),
          as.numeric(summary.SC$` Response log.DE_spleen`$`Pr(>F)`[1]),
          as.numeric(summary.SC$` Response log.DE_kidney`$`Pr(>F)`[1]),
          as.numeric(summary.SC$` Response log.DE_lung`$`Pr(>F)`[1]))


#Y <- cbind(data.log$log.DE_liver, data.log$log.DE_heart, data.log$log.DE_spleen, data.log$log.DE_kidney, data.log$log.DE_lung)

#fit <- manova(Y ~ Particle.Type + material + Targeting.Strategy +  Cancer + Tumor.Model + NM.Shape + HD.category + Surface.Charge, data = data.log)
#summary(fit, test = "Pillai")
#summary.aov(fit)

p.table <- rbind.data.frame(p.type, p.MAT, p.TS, p.CT, p.TM, p.shape, p.HD, p.SC)
colnames(p.table) <- c("heart","liver","spleen","kidney","lung")
write.csv(p.table,"P table MANOVA_Cmax_IDg.csv")

