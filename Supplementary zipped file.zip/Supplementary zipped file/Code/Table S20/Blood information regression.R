library(dplyr)
library(olsrr)

data <- readRDS("AUC_total_0811.RDS")
data <- data[,27:33]
data <- data %>% mutate (DE_tumor = 100*AUC_tumor/AUC.plasma)

info <- readRDS("nano info.RDS")
blood <- read.csv("Plasma data_0802.csv",header = TRUE)

blood.info <- blood$Blood.or.plasma[!is.na(blood$Dataset.No.)]
data <- cbind.data.frame(info, data, blood.info)

data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))

data <- data %>% mutate(ONM.category = recode(Organic.Material,
                                              "Polymeric" = "Polymeric",
                                              "Dendrimer" = "Dendrimer",
                                              "Liposome"  = "Liposome",
                                              "Hydrogel"  = "Hydrogel",
                                              .default    = "ONM others"))%>%
  mutate(material = ifelse(Particle.Type == "Inorganic",INM.category,
                           ifelse(Particle.Type == "Organic",ONM.category,"Hybrid")))

data <- data %>% mutate(Cancer = recode(Cancer.type,
                                        "Brain"  = "Brain",
                                        "Breast" = "Breast",
                                        "Cervix" = "Cervix",
                                        "Colon"  = "Colon",
                                        "Glioma" = "Glioma",
                                        "Liver"  = "Liver",
                                        "Lung"   = "Lung",
                                        "Ovary"  = "Ovary",
                                        "Pancreas" = "Pancreas",
                                        "Prostate" = "Prostate",
                                        "Sarcoma"= "Sarcoma",
                                        "Skin"   = "Skin",
                                        .default = "Others"))

data <- data %>% mutate(NM.Shape = recode(NM.Shape, 
                                          "Rod" = "Rod",
                                          "Spherical" = "Spherical",
                                          "Plate" = "Plate",
                                          .default = "Others"))

data <- data %>% mutate(log.HD = log(NM.Hydrodnamic.Size.nm., 10))

data <- data %>%  mutate(HD.category = cut(NM.Hydrodnamic.Size.nm., breaks = c(0,10,100,200,Inf), labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))

stats <- function(x){
  r2 <- summary(x)$r.squared
  r2a <- summary(x)$adj.r.squared
  f <- summary(x)$fstatistic
  p <- pf(f[1],f[2],f[3],lower.tail=F)
  error <- summary(x)$sigma
  y <- c(r2, r2a, f, p, error)
  return(y)
}

######### (1.3) Multivariable regression model for all data ###################

fit_full.ZP <- lm(log.DE_tumor ~ Particle.Type + material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = data)
All.full.ZP <- stats(fit_full.ZP)
best <- ols_step_best_subset(fit_full.ZP)
print(best) # The best subsets of predictors are: material,Targeting strategy, Cancer, Tumor model, NM.Shape, log.HD, zeta.potential, PDI

best_final.1 <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV.+ PDI, data = data)
All.Best.ZP <- stats(best_final.1)


######### (1.4) Multivariable regression model for plasma data ###################
plasma <- data %>% filter(blood.info == "plasma")

# (1.4.1) Full model - ignore significance of predictors #
fit_full.ZP.Plas <- lm(log.DE_tumor ~ Particle.Type + material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = plasma)
All.full.ZP.Plas<- stats(fit_full.ZP.Plas)
best <- ols_step_best_subset(fit_full.ZP.Plas)
print(best) # The best subsets of predictors are: material,Cancer, NM.Shape, log.HD,  PDI

best_final.1 <- lm(log.DE_tumor ~ material +  Cancer + NM.Shape + log.HD + PDI, data = plasma)
All.Best.ZP.Plas <- stats(best_final.1)


######### (1.5) Multivariable regression model for plasma data ###################
blood <- data %>% filter(blood.info == "blood")

# (1.4.1) Full model - ignore significance of predictors #
fit_full.ZP.bld <- lm(log.DE_tumor ~ Particle.Type + material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = blood)
All.full.ZP.bld<- stats(fit_full.ZP.bld)
best <- ols_step_best_subset(fit_full.ZP.bld)
print(best) # The best subsets of predictors are: material,Targeting strategy, Cancer, Tumor model, NM.Shape, log.HD, zeta.potential, PDI

best_final.1 <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV.+ PDI, data = blood)
All.Best.ZP.bld <- stats(best_final.1)

######### (1.6) Multivariable regression model for ONM data ###################
ONM <- data %>% filter(Particle.Type == "Organic")

# (1.6.1) Full model - ignore significance of predictors #
fit_full.ONM <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = ONM)
ONM.full.ZP <- stats(fit_full.ONM)
best.ONM <- ols_step_best_subset(fit_full.ONM)# The best subsets of predictors are: material, Cancer, tumor model, NM.Shape, log.HD, Zeta potential, PDI
print(best.ONM)

best_final.ONM.1 <- lm(log.DE_tumor ~ material + Tumor.Model + log.HD + Cancer + NM.Shape + Zeta.potential.mV. + PDI, data = ONM)
summary(best_final.ONM.1)
ONM.Best.ZP <- stats(best_final.ONM.1)

######### (1.7) Multivariable regression model for ONM plasma data ###################

Plasma.ONM <- ONM %>% filter(blood.info == "plasma")

# (1.7.1) Full model - ignore significance of predictors #
fit_full.ONM.plas <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = Plasma.ONM)
ONM.full.ZP.plas <- stats(fit_full.ONM.plas)
best.ONM.plas <- ols_step_best_subset(fit_full.ONM.plas)# The best subsets of predictors are: material, targeting strategy, Cancer, NM.Shape, log.HD, Zeta potential, PDI
print(best.ONM.plas)

best_final.ONM.1 <- lm(log.DE_tumor ~ material + Targeting.Strategy + log.HD + Cancer + NM.Shape + Zeta.potential.mV. + PDI, data = Plasma.ONM)
summary(best_final.ONM.1)
ONM.Best.ZP.Plas <- stats(best_final.ONM.1)


######### (1.8) Multivariable regression model for ONM blood data ###################

Bld.ONM <- ONM %>% filter(blood.info == "blood")

# (1.8.1) Full model - ignore significance of predictors #
fit_full.ONM.bld <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + log.HD + Zeta.potential.mV. + PDI, data = Bld.ONM)
ONM.full.ZP.bld <- stats(fit_full.ONM.bld)
best.ONM.bld <- ols_step_best_subset(fit_full.ONM.bld)# The best subsets of predictors are: material, Cancer, tumor model,  log.HD, Zeta potential, PDI
print(best.ONM.bld)

best_final.ONM.1 <- lm(log.DE_tumor ~ material + Targeting.Strategy + log.HD + Cancer + NM.Shape + Zeta.potential.mV. + PDI, data = Bld.ONM)
summary(best_final.ONM.1)
ONM.Best.ZP.bld <- stats(best_final.ONM.1)


table.ZP <- rbind(All.full.ZP,
               All.Best.ZP,
               All.full.ZP.Plas,
               All.Best.ZP.Plas,
               All.full.ZP.bld,
               All.Best.ZP.bld)

table.SC <- rbind(All.full.SC,
                  All.Best.SC,
                  All.full.SC.Plas,
                  All.Best.SC.Plas,
                  All.full.SC.bld,
                  All.Best.SC.bld)


colnames(table.ZP) <- colnames(table.SC) <- c("r2", "Adj R2", "F", "df1" , "df2" , "p", "Residual standard error")
