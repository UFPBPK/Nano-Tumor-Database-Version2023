library(dplyr)

#Import the data of AUC-based (Method 1) in the unit of %ID
data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data[2:7])

#Convert variables
data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))%>%
  mutate(ONM.category = recode(Organic.Material,
                               "Polymeric" = "Polymeric",
                               "Dendrimer" = "Dendrimer",
                               "Liposome"  = "Liposome",
                               "Hydrogel"  = "Hydrogel",
                               .default    = "ONM others"))%>%
  mutate(material = ifelse(Particle.Type == "Inorganic",INM.category,
                           ifelse(Particle.Type == "Organic",ONM.category,"Hybrid")))%>%
  mutate(Cancer = recode(Cancer.type,
                         "Brain"  = "Brain",
                         "Breast" = "Breast",
                         "Cervix" = "Cervix",
                         "Colon"  = "Colon",
                         "Glioma" = "Glioma",
                         "Liver"  = "Liver",
                         "Lung"   = "Lung",
                         "Ovary"  = "Ovary",
                         "Pancreas" = "Pancreas",
                         "Prostate" = "Prostate",
                         "Sarcoma"= "Sarcoma",
                         "Skin"   = "Skin",
                         .default = "Others"))%>% 
  mutate(NM.Shape = recode(NM.Shape, 
                           "Rod" = "Rod",
                           "Spherical" = "Spherical",
                           "Plate" = "Plate",
                           .default = "Others"))%>%
  mutate(HD.category = cut(NM.Hydrodnamic.Size.nm., breaks = c(0,10,100,200,Inf), 
                           labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))


ONM <- data %>%  filter(Particle.Type == "Organic")

df <- data.frame(Materials = sample(unique(ONM$material), 1000, replace = TRUE),
                 Targeting  = sample(unique(ONM$Targeting.Strategy), 1000, replace = TRUE),
                 Cancer = sample(c("Breast", "Cervix", "Colon", "Glioma", "Liver", "Lung", "Ovary","Pancreas", "Prostate", "Sarcoma","Skin", "Others", "Brain"), 1000, replace = TRUE),
                 log.HD = runif(1000, min = median(ONM$log.HD, na.rm = TRUE), max = quantile(ONM$log.HD, 0.975, na.rm = TRUE)),
                 zeta = runif(1000, min = quantile(ONM$Zeta.potential.mV., 0.025, na.rm = TRUE), max = quantile(ONM$Zeta.potential.mV., 0.975, na.rm = TRUE)),
                 Shape = sample(c("Spherical", "Plate", "Rod", "Others"), 1000, replace = TRUE))

df <- df %>% mutate(TS = recode(Targeting, 
                                "Passive" = -0.115569,
                                "Active" = 0),
                    cancer = recode(Cancer,
                                    "Breast" = 0.291432,
                                    "Cervix" = 0.666894,
                                    "Colon" = 0.248087,
                                    "Glioma" = -1.259792,
                                    "Liver" = 0.175012,
                                    "Lung" = 0.049676,
                                    "Ovary" = 0.295730,
                                    "Pancreas" = 0.448940,
                                    "Prostate" = 0.514846,
                                    "Sarcoma" = 0.798281,
                                    "Skin" = 0.381969,
                                    "Others" = 0.347417,
                                    "Brain" = 0),
                    MAT = recode(Materials, 
                                 "Polymeric" = -0.760563,
                                 "Hydrogel" = -1.113594,
                                 "Liposome" = -1.235406,
                                 "ONM others" = -0.874236,
                                 "Dendrimer" = 0),
                    SP = recode(Shape,
                                "Spherical" = 1.358806,
                                "Plate" = 1.567697,
                                "Rod" = 1.313831,
                                "Others" = 0))
df <- df %>% mutate(log.DE = -1.351938 + MAT + TS + SP + 0.220389*log.HD + cancer + 0.004443 * zeta,
                    DE = 10^log.DE)

df <- df %>%  mutate(HD = 10^log.HD,
                     HD.category = cut(HD, breaks = c(0,10,100,200,Inf), labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))

df <- df %>% mutate(surface.charge = cut(zeta, breaks = c(-Inf, -10, 10, Inf), labels = c("Negative", "Neutral", "Positive"), include.lowest = TRUE))

df <- df %>% dplyr :: select(Materials, Targeting, Cancer, Shape, HD.category, surface.charge, DE)

write.csv(df, "ONM design strategy.csv")
