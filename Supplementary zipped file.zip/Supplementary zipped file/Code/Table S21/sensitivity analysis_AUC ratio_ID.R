library(dplyr)
library(olsrr)
data <- readRDS("AUC_total_0811.RDS")

data <- data[,27:33]
info <- readRDS("nano info.RDS")
data <- data %>% mutate (DE_tumor = 100*AUC_tumor/AUC.plasma)
data <- cbind.data.frame(info, data)

data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))


data <- data %>% mutate(ONM.category = recode(Organic.Material,
                                              "Polymeric" = "Polymeric",
                                              "Dendrimer" = "Dendrimer",
                                              "Liposome"  = "Liposome",
                                              "Hydrogel"  = "Hydrogel",
                                              .default    = "ONM others"))%>%
  mutate(material = ifelse(Particle.Type == "Inorganic",INM.category,
                           ifelse(Particle.Type == "Organic",ONM.category,"Hybrid")))

data <- data %>% mutate(Cancer = recode(Cancer.type,
                                        "Brain"  = "Brain",
                                        "Breast" = "Breast",
                                        "Cervix" = "Cervix",
                                        "Colon"  = "Colon",
                                        "Glioma" = "Glioma",
                                        "Liver"  = "Liver",
                                        "Lung"   = "Lung",
                                        "Ovary"  = "Ovary",
                                        "Pancreas" = "Pancreas",
                                        "Prostate" = "Prostate",
                                        "Sarcoma"= "Sarcoma",
                                        "Skin"   = "Skin",
                                        .default = "Others"))

data <- data %>% mutate(NM.Shape = recode(NM.Shape, 
                                          "Rod" = "Rod",
                                          "Spherical" = "Spherical",
                                          "Plate" = "Plate",
                                          .default = "Others"))

data <- data %>% mutate(log.HD = log(NM.Hydrodnamic.Size.nm., 10))

data <- data %>%  mutate(HD.category = cut(NM.Hydrodnamic.Size.nm., breaks = c(0,10,100,200,Inf), labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))

stats <- function(x){
  r2 <- summary(x)$r.squared
  r2a <- summary(x)$adj.r.squared
  f <- summary(x)$fstatistic
  p <- pf(f[1],f[2],f[3],lower.tail=F)
  error <- summary(x)$sigma
  y <- c(r2, r2a, f, p, error)
  return(y)
}
###Original Results
######### (1.4) Multivariable regression model for Inorganic data ###################
INM <- data %>%  filter(Particle.Type == "Inorganic")

mean.INM <- mean(INM$log.DE_tumor, na.rm = TRUE)
std.INM <- sd(INM$log.DE_tumor, na.rm = TRUE)

upper.INM <- mean.INM + 1.96 * std.INM
lower.INM <- mean.INM - 1.96 * std.INM


INM$outlier <- upper.INM < INM$log.DE_tumor | lower.INM > INM$log.DE_tumor

INM.excld <- INM %>% filter(!outlier)

# (1.4.1) original results
fit_full.INM.ZP <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = INM)
INM.full.ZP <- stats(fit_full.INM.ZP)
best.INM <- ols_step_best_subset(fit_full.INM.ZP)
print(best.INM) # The best subsets of predictors are: material, Cancer, PDI

best_final.INM.1 <- lm(log.DE_tumor ~  material + Cancer + PDI, data = INM)
INM.best.ZP <- stats(best_final.INM.1)

# (1.4.2) results after removing outliers
fit_full.INM.ZP.ex <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = INM.excld)
INM.full.ZP.ex <- stats(fit_full.INM.ZP.ex)
best.INM.ex <- ols_step_best_subset(fit_full.INM.ZP.ex)
print(best.INM.ex) # The best subsets of predictors are: material, Cancer,  PDI

best_final.INM.2 <- lm(log.DE_tumor ~  material + Cancer + PDI, data = INM.excld)

INM.best.ZP.2 <- stats(best_final.INM.2)

######### (1.5) Multivariable regression model for Gold data ###################
Gold <- INM %>%  filter(Inorganic.Material == "Gold")

Gold.excld <- Gold %>% filter(!outlier)

# (1.4.1) original results
fit_full.Gold.ZP <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = Gold)
Gold.full.ZP <- stats(fit_full.Gold.ZP)
best.Gold <- ols_step_best_subset(fit_full.Gold.ZP)
print(best.Gold) # The best subsets of predictors are: Cancer,  PDI

best_final.Gold.1 <- lm(log.DE_tumor ~  Cancer + PDI, data = Gold)
Gold.best.ZP <- stats(best_final.Gold.1)

# (1.4.2) results after removing outliers
fit_full.Gold.ZP.ex <- lm(log.DE_tumor ~ Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = Gold.excld)
Gold.full.ZP.ex <- stats(fit_full.Gold.ZP.ex)
best.Gold <- ols_step_best_subset(fit_full.Gold.ZP.ex)
print(best.Gold) # The best subsets of predictors are: Targeting strategy, Cancer, PDI, ZP

best_final.Gold.2 <- lm(log.DE_tumor ~ Cancer + PDI, data = Gold.excld)
Gold.best.ZP.2 <- stats(best_final.Gold.2)

stats <- rbind.data.frame(INM.full.ZP,
                          INM.best.ZP,
                          INM.full.ZP.ex,
                          INM.best.ZP.2, 
                          Gold.full.ZP,
                          Gold.best.ZP,
                          Gold.full.ZP.ex,
                          Gold.best.ZP.2)

colnames(stats) <- c("r2", "Adj R2", "F", "df1" , "df2" , "p", "Residual standard error")
write.csv(stats, "sensitivity analysis_AUC ratio_ID.csv")

Rosner.test.INM <- rosnerTest(INM$log.DE_tumor, k = 10)
Rosner.test.INM
Outliers <- Rosner.test.INM$all.stats$Value[Rosner.test.INM$all.stats$Outlier ==TRUE]

INM.Rosner <- INM %>% filter(!log.DE_tumor %in% Outliers)

Rosner.test.gold <- rosnerTest(Gold$log.DE_tumor, k = 10)
Rosner.test.gold

fit_full.INM.ZP.Rosner <- lm(log.DE_tumor ~ material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV. + PDI, data = INM.Rosner)
INM.full.ZP.Rosner <- stats(fit_full.INM.ZP.Rosner)
best.INM.Rosner <- ols_step_best_subset(fit_full.INM.ZP.Rosner)
print(best.INM.Rosner) # The best subsets of predictors are: material, Cancer,  PDI

best_final.INM.R <- lm(log.DE_tumor ~  material + Cancer + PDI, data = INM.Rosner)

INM.best.ZP.R <- stats(best_final.INM.R)
