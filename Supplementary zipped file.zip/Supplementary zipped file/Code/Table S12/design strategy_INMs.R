library(dplyr)

#Import the data of AUC-based (Method 1) in the unit of %ID
data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data[2:7])

#Convert variables
data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))%>%
  mutate(ONM.category = recode(Organic.Material,
                               "Polymeric" = "Polymeric",
                               "Dendrimer" = "Dendrimer",
                               "Liposome"  = "Liposome",
                               "Hydrogel"  = "Hydrogel",
                               .default    = "ONM others"))%>%
  mutate(material = ifelse(Particle.Type == "Inorganic",INM.category,
                           ifelse(Particle.Type == "Organic",ONM.category,"Hybrid")))%>%
  mutate(Cancer = recode(Cancer.type,
                         "Brain"  = "Brain",
                         "Breast" = "Breast",
                         "Cervix" = "Cervix",
                         "Colon"  = "Colon",
                         "Glioma" = "Glioma",
                         "Liver"  = "Liver",
                         "Lung"   = "Lung",
                         "Ovary"  = "Ovary",
                         "Pancreas" = "Pancreas",
                         "Prostate" = "Prostate",
                         "Sarcoma"= "Sarcoma",
                         "Skin"   = "Skin",
                         .default = "Others"))%>% 
  mutate(NM.Shape = recode(NM.Shape, 
                           "Rod" = "Rod",
                           "Spherical" = "Spherical",
                           "Plate" = "Plate",
                           .default = "Others"))%>%
  mutate(HD.category = cut(NM.Hydrodnamic.Size.nm., breaks = c(0,10,100,200,Inf), 
                           labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))

INM <- data %>%  filter(Particle.Type == "Inorganic")

df <- data.frame(Targeting  = sample(unique(INM$Targeting.Strategy), 1000, replace = TRUE),
                 Cancer = sample(c("Breast", "Cervix", "Colon", "Liver", "Lung", "Ovary","Pancreas", "Prostate", "Skin", "Others", "Brain"), 1000, replace = TRUE),
                 log.HD = runif(1000, min = median(INM$log.HD, na.rm = TRUE), max = quantile(INM$log.HD, 0.975, na.rm = TRUE)),
                 zeta = runif(1000, min = quantile(INM$Zeta.potential.mV., 0.025, na.rm = TRUE), max = quantile(INM$Zeta.potential.mV., 0.975, na.rm = TRUE)),
                 PDI = runif(1000, min = 0, max = 1.0))

df <- df %>% mutate(TS = recode(Targeting, 
                                "Passive" = -0.28359,
                                "Active" = 0),
                    cancer = recode(Cancer,
                                    "Breast" = 0.785283,
                                    "Cervix" = 0.994487,
                                    "Colon" = 0.292673,
                                    "Liver" = 0.271296,
                                    "Lung" = 0.940636,
                                    "Ovary" = 0.609650,
                                    "Pancreas" = -0.177318,
                                    "Prostate" = 0.157904,
                                    "Skin" = 1.711868,
                                    "Others" = 0.996406,
                                    "Brain" = 0))
df <- df %>% mutate(log.DE = -0.478161 + TS + 0.120009*log.HD + cancer -0.003101 * zeta + 0.322322 * PDI,
                    DE = 10^log.DE)

df <- df %>%  mutate(HD = 10^log.HD,
                     HD.category = cut(HD, breaks = c(0,10,100,200,Inf), labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))

df <- df %>% mutate(surface.charge = cut(zeta, breaks = c(-Inf, -10, 10, Inf), labels = c("Negative", "Neutral", "Positive"), include.lowest = TRUE),
                    PDII = cut(PDI, breaks = c(0, 0.05, 0.3, 1), labels = c("<0.05", "0.05-0.3", ">0.3"), include.lowest = TRUE))

df <- df %>% dplyr :: select(Targeting, Cancer, HD.category, surface.charge, PDII, DE)

write.csv(df, "INM design strategy.csv")