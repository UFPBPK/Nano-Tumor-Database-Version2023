library(dplyr)
library(heplots)

data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data[2:7])

data.log <- data %>% mutate(log.DE_liver = log(DE_liver, 10),
                            log.DE_heart = log(DE_heart, 10),
                            log.DE_spleen = log(DE_spleen, 10),
                            log.DE_kidney = log(DE_kidney, 10),
                            log.DE_lung  = log(DE_lung, 10))



organ.Type <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Particle.Type, data = data.log)
summary(organ.Type)   # Particle Type is a significant predictor, p = 0.003637 **
summary.aov(organ.Type)   #Liver: 0.003811**; Heart: 0.2113; Spleen: 0.0001581***, Kidney: 0.1892; Lung: 0.2257

organ.MAT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ material, data = data.log)
summary(organ.MAT)    # Materials is a significant predictor, p = 6.906e-08***
summary.aov(organ.MAT)   #Liver: 0.02704*; Heart: 0.01094*; Spleen: 0.0001411***, Kidney: 0.004042 **; Lung: 0.1299

organ.TS <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Targeting.Strategy, data = data.log)
summary(organ.TS)     # Targeting strategy is not a significant predictor, p = 0.03639 *
summary.aov(organ.TS)   #Liver: 0.2545; Heart: 0.6503; Spleen: 0.1184, Kidney: 0.2656; Lung: 0.589

organ.CT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Cancer, data = data.log)
summary(organ.CT)     # Cancer is a significant predictor, p = 6.243e-08***
summary.aov(organ.CT)   #Liver: 0.004056**; Heart: 0.003226**; Spleen: 0.0001342***, Kidney: 0.003226**; Lung: 0.0002051***

organ.TM <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Tumor.Model, data = data.log)
summary(organ.TM)     # Tumor model is a significant predictor, p = 0.0003155***
summary.aov(organ.TM)   #Liver: 9.945e-05***; Heart: 0.021*; Spleen: 0.000607***, Kidney: 0.2257; Lung: 0.001477**

organ.shape <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ NM.Shape, data = data.log)
summary(organ.shape)     # Shape is a significant predictor, p = 2.517e-06 ***
summary.aov(organ.shape)   #Liver: 0.02264*; Heart: 0.8676; Spleen: 0.01359*, Kidney: 0.3582; Lung: 0.2666

organ.HD <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ HD.category, data = data.log)
summary(organ.HD)     # HD category is a significant predictor, p = 7.484e-12***
summary.aov(organ.HD)   #Liver: 1.371e-06 ***; Heart: 0.005069*; Spleen: 2.875e-06***, Kidney: 0.06328; Lung: 7.748e-06***

organ.SC <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Surface.Charge, data = data.log)
summary(organ.SC)     # Surface charge is not a significant predictor, p = 0.03223*
summary.aov(organ.SC)   #Liver: 0.05537*; Heart: 0.001381**; Spleen: 0.13, Kidney: 0.002604*; Lung: 0.09748


#Y <- cbind(data.log$log.DE_liver, data.log$log.DE_heart, data.log$log.DE_spleen, data.log$log.DE_kidney, data.log$log.DE_lung)

#fit <- manova(Y ~ Particle.Type + material + Targeting.Strategy +  Cancer + Tumor.Model + NM.Shape + HD.category + Surface.Charge, data = data.log)
#summary(fit, test = "Pillai")
#summary.aov(fit)

