library(dplyr)
library(olsrr)
#Import the data of AUC-based (Method 1) in the unit of %ID
data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data[2:7])

#Convert variables
data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))%>%
  mutate(ONM.category = recode(Organic.Material,
                               "Polymeric" = "Polymeric",
                               "Dendrimer" = "Dendrimer",
                               "Liposome"  = "Liposome",
                               "Hydrogel"  = "Hydrogel",
                               .default    = "ONM others"))%>%
  mutate(material = ifelse(Particle.Type == "Inorganic",INM.category,
                           ifelse(Particle.Type == "Organic",ONM.category,"Hybrid")))%>%
  mutate(Cancer = recode(Cancer.type,
                         "Brain"  = "Brain",
                         "Breast" = "Breast",
                         "Cervix" = "Cervix",
                         "Colon"  = "Colon",
                         "Glioma" = "Glioma",
                         "Liver"  = "Liver",
                         "Lung"   = "Lung",
                         "Ovary"  = "Ovary",
                         "Pancreas" = "Pancreas",
                         "Prostate" = "Prostate",
                         "Sarcoma"= "Sarcoma",
                         "Skin"   = "Skin",
                         .default = "Others"))%>% 
  mutate(NM.Shape = recode(NM.Shape, 
                           "Rod" = "Rod",
                           "Spherical" = "Spherical",
                           "Plate" = "Plate",
                           .default = "Others"))%>%
  mutate(HD.category = cut(NM.Hydrodnamic.Size.nm., breaks = c(0,10,100,200,Inf), 
                           labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))

#Fit the best model of multivariate linear regression for all nanoparticles.

fit_best <- lm(log.DE_tumor ~ Particle.Type + material + Targeting.Strategy + Cancer + Tumor.Model + NM.Shape + log.HD + Zeta.potential.mV.+ PDI, data = data)
best <- ols_step_best_subset(fit_best)
print(best) # The best subsets of predictors are: material, Cancer, NM.Shape, log.HD, zeta.potential, PDI

best_final <- lm(log.DE_tumor ~ material + Cancer + NM.Shape + log.HD + Zeta.potential.mV.+ PDI, data = data)
summary(best_final)

#Recode the nanoparticle features with the regression coefficients

data.sim <- data %>% mutate(MAT = recode(material,
                                         "Gold" = -0.661316,
                                         "Hybrid" = -0.548219,
                                         "Hydrogel" = -2.051404,
                                         "Iron Oxide" = -0.988474,
                                         "Liposome" = -1.919897,
                                         "ONM others" = -1.639240,
                                         "Other" = -1.073552,
                                         "Polymeric" = -1.279044,
                                         "Silica" = -1.050073,
                                         .default = 0),
                            cancer = recode(Cancer.type,
                                            "Breast" = 0.350700,
                                            "Cervix" = 0.494481,
                                            "Colon" = 0.224512,
                                            "Liver" = 0.271296,
                                            "Lung" = 0.285555,
                                            "Others" = 0.496565,
                                            "Ovary" = 0.134035,
                                            "Pancreas" = -0.215385,
                                            "Prostate" = -0.312144,
                                            "Sarcoma" = 0.905299,
                                            "Skin" = 0.601072,
                                            .default = 0),
                            SP = recode(NM.Shape,
                                        "Plate" = 0.774130,
                                        "Rod" = 0.827525,
                                        "Spherical" = 0.997919,
                                        "Others" = 0))



#Simulate the independent variables in the best model
df <- data.frame(MAT = sample(data.sim$MAT, 10000, replace = TRUE),
                 SP  = sample(data.sim$SP, 10000, replace = TRUE),
                 Cancer = sample(data.sim$cancer, 10000, replace = TRUE),
                 log.HD = runif(10000, min = median(data.sim$log.HD, na.rm = TRUE), max = max(data.sim$log.HD, na.rm = TRUE)),
                 zeta = runif(10000, min = median(data.sim$Zeta.potential.mV., na.rm = TRUE), max = max(data.sim$Zeta.potential.mV., na.rm = TRUE)),
                 PDI = runif(10000, min = 0.5, max = 1.0))

df <- df %>% mutate(log.DE = -0.366018 + MAT + SP + 0.120009 * log.HD  + Cancer + 0.001036 * zeta + 0.052522 * PDI,
                    DE = 10^log.DE)

#Convert the results to nanoparticle information 
df.results <- df %>% mutate(Material =  recode(MAT, 
                                          "-0.661316" = "Gold"  ,
                                          "-1.050073" = "Silica" ,
                                          "-0.988474" = "Iron Oxide",
                                          "-1.073552" = "Other",
                                          "-0.548219" = "Hybrid",
                                          "-1.279044" = "Polymeric",
                                          "-1.919897" = "Liposome",
                                          "-2.051404" = "Hydrogel",
                                          "-1.639240" = "ONM others",
                                          .default = "Dendrimer"),
                                    Shape = recode(SP,
                                                   "0.997919" = "Spherical",
                                                   "0.774130" = "Plate",
                                                   "0.827525" = "Rod",
                                                   .default = "Others"),
                                    CCer = recode(Cancer,
                                                  "0.494481" = "Cervix",
                                                  "0.224512" = "Colon",
                                                  "0.271296" = "Liver",
                                                  "0.285555" = "Lung",
                                                  "0.350700" = "Breast",
                                                  "0.134035" = "Ovary",
                                                  "0.601072" = "Skin",
                                                  "-0.312144" = "Prostate",
                                                  "-0.215385" = "Pancreas",
                                                  "0.905299" = "Sarcoma",
                                                  "0.496565" = "Others",
                                                  .default = "Brain"))

#Categorize the NP features
df.results <- df.results %>% arrange(-DE) %>% 
  mutate(HD = 10^log.HD) %>%
  mutate(HD.category = cut(HD, breaks = c(0,10,100,200,Inf), 
                           labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE),
         surface.charge = cut(zeta, breaks = c(-Inf, -10, 10, Inf), labels = c("Negative", "Neutral", "Positive"), include.lowest = TRUE)) %>%
  select(Material, Shape, CCer,HD.category, surface.charge, DE)


write.csv(df.results, "DE strategy.csv")
