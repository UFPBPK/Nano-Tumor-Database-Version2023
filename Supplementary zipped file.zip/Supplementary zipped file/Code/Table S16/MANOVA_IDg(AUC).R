library(dplyr)

data <- readRDS("Delivery efficiency_IDg.RDS")
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data)

data.log <- data %>% mutate(log.DE_liver = log(DE_liver, 10),
                            log.DE_heart = log(DE_heart, 10),
                            log.DE_spleen = log(DE_spleen, 10),
                            log.DE_kidney = log(DE_kidney, 10),
                            log.DE_lung  = log(DE_lung, 10))



organ.Type <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Particle.Type, data = data.log)
summary(organ.Type)   # Particle Type is a significant predictor, p = 0.0006915**
summary.aov(organ.Type)   #Liver: 0.004951**; Heart: 0.183; Spleen: 0.0006618***, Kidney: 0.2759; Lung: 0.4213

organ.MAT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ material, data = data.log)
summary(organ.MAT)    # Materials is a significant predictor, p = 3.105e-06***
summary.aov(organ.MAT)   #Liver: 0.01794*; Heart: 0.005822*; Spleen: 0.0003885***, Kidney: 0.002167**; Lung: 0.225

organ.TS <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Targeting.Strategy, data = data.log)
summary(organ.TS)     # Targeting strategy is not a significant predictor, p = 0.16
summary.aov(organ.TS)   #Liver: 0.3835; Heart: 0.948; Spleen: 0.167, Kidney: 0.298; Lung: 0.5055

organ.CT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Cancer, data = data.log)
summary(organ.CT)     # Cancer is a significant predictor, p = 5.921e-07***
summary.aov(organ.CT)   #Liver: 0.004211**; Heart: 0.005233**; Spleen: 0.0001485***, Kidney: 0.001805**; Lung: 0.0004404***

organ.TM <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Tumor.Model, data = data.log)
summary(organ.TM)     # Tumor model is a significant predictor, p = 8.879e-06***
summary.aov(organ.TM)   #Liver: 3.966e-05***; Heart: 0.01834*; Spleen: 0.0002302***, Kidney: 0.2456; Lung: 0.001817**

organ.shape <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ NM.Shape, data = data.log)
summary(organ.shape)     # Shape is a significant predictor, p = 4.203e-06 ***
summary.aov(organ.shape)   #Liver: 0.02928*; Heart: 0.8501; Spleen: 0.01461*, Kidney: 0.3233; Lung: 0.2013

organ.HD <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ HD.category, data = data.log)
summary(organ.HD)     # HD category is a significant predictor, p = 1.537e-10 ***
summary.aov(organ.HD)   #Liver: 7.78e-06 ***; Heart: 0.01465*; Spleen: 2.791e-06***, Kidney: 0.07351; Lung: 2.637e-05***

organ.SC <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Surface.Charge, data = data.log)
summary(organ.SC)     # Surface charge is not a significant predictor, p = 0.08153
summary.aov(organ.SC)   #Liver: 0.04927 *; Heart: 0.01969 *; Spleen: 0.2117, Kidney: 0.001065 **; Lung: 0.09197


#Y <- cbind(data.log$log.DE_liver, data.log$log.DE_heart, data.log$log.DE_spleen, data.log$log.DE_kidney, data.log$log.DE_lung)

#fit <- manova(Y ~ Particle.Type + material + Targeting.Strategy +  Cancer + Tumor.Model + NM.Shape + HD.category + Surface.Charge, data = data.log)
#summary(fit, test = "Pillai")
#summary.aov(fit)

