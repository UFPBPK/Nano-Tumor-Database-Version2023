library(dplyr)

data <- readRDS("AUC ratio_IDg.RDS")
info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, data)

data.log <- data %>% mutate(log.DE_liver  = log(AUC_liver, 10),
                            log.DE_heart  = log(AUC_heart, 10),
                            log.DE_spleen = log(AUC_spleen, 10),
                            log.DE_kidney = log(AUC_kidney, 10),
                            log.DE_lung   = log(AUC_lung, 10))


organ.Type <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Particle.Type, data = data.log)
summary(organ.Type)   # Particle Type is a significant predictor, p = 0.02929 *
summary.aov(organ.Type)   #Liver: 0.1555; Heart: 0.2095; Spleen:  0.0171*, Kidney: 0.4698; Lung: 0.3079

organ.MAT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ material, data = data.log)
summary(organ.MAT)    # Materials is a significant predictor, p = 4.037e-07***
summary.aov(organ.MAT)   #Liver: 0.002731**; Heart: 0.0698; Spleen: 2.622e-05***, Kidney: 0.000236***; Lung: 0.01364

organ.TS <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Targeting.Strategy, data = data.log)
summary(organ.TS)     # Targeting strategy is not a significant predictor, p = 0.4519
summary.aov(organ.TS)   #Liver: 0.9792; Heart:0.8974; Spleen: 0.9726, Kidney: 0.3355; Lung: 0.8728

organ.CT <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Cancer, data = data.log)
summary(organ.CT)     # Cancer is a significant predictor, p = 2.621e-07 ***
summary.aov(organ.CT)   #Liver: 0.002634**; Heart: 0.002777**; Spleen: 7.18e-06***, Kidney: 0.001298**; Lung: 0.0009198***

organ.TM <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Tumor.Model, data = data.log)
summary(organ.TM)     # Tumor model is a significant predictor, p = 0.007027**
summary.aov(organ.TM)   #Liver: 0.9474; Heart: 0.9546; Spleen: 0.5875, Kidney:0.9302; Lung: 0.6328

organ.shape <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ NM.Shape, data = data.log)
summary(organ.shape)     # Shape is a significant predictor, p = 4.935e-05 ***
summary.aov(organ.shape)   #Liver: 0.0009689 ***; Heart: 0.08838 ; Spleen: 0.0005839 ***, Kidney: 0.101; Lung: 0.006869 **

organ.HD <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ HD.category, data = data.log)
summary(organ.HD)     # HD category is a significant predictor, p = 0.0004914 ***
summary.aov(organ.HD)   #Liver: 0.02514*; Heart: 0.04427; Spleen: 0.008558**, Kidney: 0.0552; Lung: 0.01698*

organ.SC <- manova(cbind(log.DE_liver, log.DE_heart, log.DE_spleen, log.DE_kidney, log.DE_lung) ~ Surface.Charge, data = data.log)
summary(organ.SC)     # Surface charge is not a significant predictor, p = 0.5312
summary.aov(organ.SC)   #Liver: 0.4276; Heart: 0.3794; Spleen: 0.3997, Kidney: 0.1378; Lung: 0.354


#Y <- cbind(data.log$log.DE_liver, data.log$log.DE_heart, data.log$log.DE_spleen, data.log$log.DE_kidney, data.log$log.DE_lung)

#fit <- manova(Y ~ Particle.Type + material + Targeting.Strategy +  Cancer + Tumor.Model + NM.Shape + HD.category + Surface.Charge, data = data.log)
#summary(fit, test = "Pillai")
#summary.aov(fit)

