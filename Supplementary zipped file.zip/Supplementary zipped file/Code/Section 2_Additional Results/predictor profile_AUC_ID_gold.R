library(ggpubr)

data <- read.csv("Delivery efficiency_AUC.csv",header = TRUE)
info <- readRDS("nano info.RDS")
data <- cbind.data.frame(info, data[2:7])

data <- data %>%
  mutate(log.DE_tumor = log10(DE_tumor))

data <- data %>% mutate(gold.category = recode(Organic.Material,
                                              "Polymeric" = "Polymeric",
                                              "Dendrimer" = "Dendrimer",
                                              "Liposome"  = "Liposome",
                                              "Hydrogel"  = "Hydrogel",
                                              .default    = "gold others"))%>%
  mutate(material = ifelse(Particle.Type == "Inorganic",gold.category,
                           ifelse(Particle.Type == "Organic",gold.category,"Hybrid")))

data <- data %>% mutate(Cancer = recode(Cancer.type,
                                        "Brain"  = "Brain",
                                        "Breast" = "Breast",
                                        "Cervix" = "Cervix",
                                        "Colon"  = "Colon",
                                        "Glioma" = "Glioma",
                                        "Liver"  = "Liver",
                                        "Lung"   = "Lung",
                                        "Ovary"  = "Ovary",
                                        "Pancreas" = "Pancreas",
                                        "Prostate" = "Prostate",
                                        "Sarcoma"= "Sarcoma",
                                        "Skin"   = "Skin",
                                        .default = "Others"))

data <- data %>% mutate(NM.Shape = recode(NM.Shape, 
                                          "Rod" = "Rod",
                                          "Spherical" = "Spherical",
                                          "Plate" = "Plate",
                                          .default = "Others"))

gold <- data %>%  filter(Particle.Type == "Inorganic" & Inorganic.Material == "Gold")

gold.sim <- gold %>% mutate(TS = recode (Targeting.Strategy,
                                       "Passive" = -0.40440,
                                       "Active" = 0),
                          CCer = recode(Cancer,
                                        "Ovary" = -1.81412,
                                        "Skin" = 0.08294,
                                        "Prostate" = -1.39118,
                                        "Pancreas" = -1.60827,
                                        "Others"  = -0.62592,
                                        .default = 0))

set.seed(1234)

#Profile predictor of zeta potential
zeta.min <- min(gold.sim$Zeta.potential.mV., na.rm = TRUE)
zeta.max <- max(gold.sim$Zeta.potential.mV., na.rm = TRUE)
zeta.random <- runif(n = 1000, min = zeta.min, max = zeta.max)

DE.sim.zeta <- NULL
for (i in 1:1000){
  
  zeta <- zeta.random[i]
  log.DE <- 1.31860 + gold.sim$TS  + gold.sim$CCer - 0.003201 * zeta - 2.74053 *gold.sim$PDI
  DE <- 10^log.DE
  DEs <- c(Zeta = zeta, 
           DE.median = median(DE, na.rm = TRUE),
           DE.bottom = quantile(DE, 0.075, na.rm = TRUE),
           DE.top = quantile(DE, 0.975, na.rm = TRUE))
  DE.sim.zeta <- rbind.data.frame(DE.sim.zeta, DEs)
  
}

colnames(DE.sim.zeta) <- c("Zeta", "Median", "Bottom","Top")
P.ZP <- ggplot(DE.sim.zeta, aes(Zeta, Median))+
  geom_smooth(method = loess, color = "darkgreen", size = 1)+
  geom_ribbon(aes(ymin = Bottom, ymax = Top), alpha = 0.2, fill = "pink", color = "white")+
  geom_line(aes(Zeta, Bottom), color = "pink", size = 0.5, linetype = "longdash")+
  geom_line(aes(Zeta, Top), color = "pink", size = 0.5, linetype = "longdash")+
  geom_hline(yintercept = 1, color = "blue", size = 0.5, linetype = "twodash")+
  geom_hline(yintercept = 3, color = "#422256", size = 0.5, linetype = "twodash")+
  scale_y_continuous(limits = c(10^(-2.5), 10^(2.5)), breaks = c(10^(-2.5), 10^(-1.5), 10^(-0.5), 10^0.5, 10^1.5, 10^2.5), labels = c("-2.5", "-1.5", "-0.5", "0.5", "1.5", "2.5"), trans = "log10")+
  #  ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab("Zeta potential (mV)")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 14, family = "serif"))

#Targeting Strategy
DE.sim.TS <- NULL
N.TS <- unique(gold.sim$TS)
TS.name <- c("Active", "Passive")
for (i in 1:length(N.TS)){
  
  log.DE <- 1.31860 + N.TS[i]  + gold.sim$CCer - 0.003201 * gold.sim$Zeta.potential.mV. - 2.74053 *gold.sim$PDI
  summary <- c(TS = TS.name[i],
               Median = median(log.DE, na.rm = TRUE),
               bottom = quantile(log.DE, 0.025, na.rm = TRUE),
               top = quantile(log.DE, 0.975, na.rm  = TRUE))
  DE.sim.TS <- rbind.data.frame(DE.sim.TS, summary)
}

colnames(DE.sim.TS) <- c("TS","Median","Bottom","Top")
DE.sim.TS$Median = as.numeric(DE.sim.TS$Median)
DE.sim.TS$Bottom = as.numeric(DE.sim.TS$Bottom)
DE.sim.TS$Top  =as.numeric(DE.sim.TS$Top)
DE.sim.TS$TS <- factor(DE.sim.TS$TS, levels = c("Passive", "Active"))


P.TS <- ggplot()+
  geom_line(data = DE.sim.TS, aes(x = TS, y = Median, group = 1), color = "darkgreen")+
  scale_y_continuous(limits = c(-2.5,2.5), breaks = c(-2.5,-1.5,-0.5,0.5,1.5,2.5))+
  geom_errorbar(data = DE.sim.TS, aes(x = TS, ymin = Bottom, ymax = Top, color = "darkgreen"), width = 0.2)+
  scale_color_manual(values = "darkgreen")+
  geom_point(data = DE.sim.TS, aes(x = TS, y = Median), color = "#d12920", size = 3)+
  geom_hline(yintercept = log10(1), color = "blue", size = 0.5, linetype = "twodash")+
  geom_hline(yintercept = log10(3), color = "#422256", size = 0.5, linetype = "twodash")+
  #ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab("Targeting Strategy")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 10, family = "serif"))

#Cancer type

DE.sim.CCer <- NULL
N.CCer <- unique(gold.sim$CCer)
CCer.name <- c("Brain","Skin","Prostate", "Others","Ovary", "Pancreas")
for (i in 1:length(N.CCer)){
  
  log.DE <- 1.31860 + gold.sim$TS + N.CCer[i] - 0.003201 * gold.sim$Zeta.potential.mV. - 2.74053 *gold.sim$PDI
  summary <- c(CCer = CCer.name[i],
               Median = median(log.DE, na.rm = TRUE),
               bottom = quantile(log.DE, 0.025, na.rm = TRUE),
               top = quantile(log.DE, 0.975, na.rm  = TRUE))
  DE.sim.CCer <- rbind.data.frame(DE.sim.CCer, summary)
}

colnames(DE.sim.CCer) <- c("Cancer","Median","Bottom","Top")
DE.sim.CCer$Median = as.numeric(DE.sim.CCer$Median)
DE.sim.CCer$Bottom = as.numeric(DE.sim.CCer$Bottom)
DE.sim.CCer$Top  =as.numeric(DE.sim.CCer$Top)
DE.sim.CCer$Cancer <- factor(DE.sim.CCer$Cancer, levels = c("Brain", "Breast", "Cervix", "Colon", "Lung", "Ovary", "Pancreas", "Prostate", "Skin", "Others"))


P.Cancer <- ggplot()+
  geom_line(data = DE.sim.CCer, aes(x = Cancer, y = Median, group = 1), color = "darkgreen")+
  scale_y_continuous(limits = c(-2.5,2.5), breaks = c(-2.5,-1.5,-0.5,0.5,1.5,2.5))+
  geom_errorbar(data = DE.sim.CCer, aes(x = Cancer, ymin = Bottom, ymax = Top, color = "darkgreen"), width = 0.2)+
  scale_color_manual(values = "darkgreen")+
  geom_point(data = DE.sim.CCer, aes(x = Cancer, y = Median), color = "#d12920", size = 3)+
  geom_hline(yintercept = log10(1), color = "blue", size = 0.5, linetype = "twodash")+
  geom_hline(yintercept = log10(3), color = "#422256", size = 0.5, linetype = "twodash")+
  ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  #  ylab("")+
  xlab("Cancer Type")+
  theme_bw()+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none")+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 10, family = "serif"),
        axis.text.y = element_text(size = 10, family = "serif"))


#PDI
set.seed(1234)
PDI.random <- runif(n = 1000, min = 0, max = 1)

DE.sim.PDI <- NULL

for (i in 1:1000){
  
  PDI <- PDI.random[i]
  log.DE <- 1.31860 + gold.sim$TS  + gold.sim$CCer - 0.003201 * gold.sim$Zeta.potential.mV. - 2.74053 *gold.sim$PDI
  DE <- 10^log.DE
  DEs <- c(PDI = PDI, 
           DE.median = median(DE, na.rm = TRUE),
           DE.bottom = quantile(DE, 0.075, na.rm = TRUE),
           DE.top = quantile(DE, 0.975, na.rm = TRUE))
  DE.sim.PDI <- rbind.data.frame(DE.sim.PDI, DEs)
  
}

colnames(DE.sim.PDI) <- c("PDI", "Median", "Bottom","Top")

P.PDI <- ggplot(DE.sim.PDI, aes(PDI, Median))+
  geom_smooth(method = loess, color = "darkgreen", size = 1)+
  geom_ribbon(aes(ymin = Bottom, ymax = Top), alpha = 0.2, fill = "pink", color = "white")+
  geom_line(aes(PDI, Bottom), color = "pink", size = 0.5, linetype = "longdash")+
  geom_line(aes(PDI, Top), color = "pink", size = 0.5, linetype = "longdash")+
  geom_hline(yintercept = 1, color = "blue", size = 0.5, linetype = "twodash")+
  geom_hline(yintercept = 3, color = "#422256", size = 0.5, linetype = "twodash")+
  scale_y_continuous(limits = c(10^(-2.5), 10^(2.5)), breaks = c(10^(-2.5), 10^(-1.5), 10^(-0.5), 10^0.5, 10^1.5, 10^2.5), labels = c("-2.5", "-1.5", "-0.5", "0.5", "1.5", "2.5"), trans = "log10")+
  #ylab(expression(Log[10]~"Tumor delivery efficiency (%ID)"))+
  ylab("")+
  xlab("Polydispersity Index")+
  theme_bw()+
  theme(axis.text.y = element_blank())+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        axis.line = element_line(),
        legend.position = "none",
        axis.ticks.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 16),
        axis.title.y = element_text(family = "serif",size = 16),
        axis.text.x = element_text(size = 14, family = "serif"))

p.ZP <- P.ZP + theme(plot.margin = unit(c(0.5, 0.5, 0, 0.5),"cm"))
p.Cancer <- P.Cancer+ theme(plot.margin = unit(c(0.5, 0.5, 0, 0.5), "cm"))
p.TS <- P.TS  + theme(plot.margin = unit(c(0.5, 0.5, 0, 0.5), "cm"))
p.PDI <- P.PDI + theme(plot.margin = unit(c(0.5, 0.5, 0, 0.5), "cm"))


ggsave("gold_ZP_AUC_ID.tiff", scale = 1,
       plot = p.ZP,
       path = "C:/Users/chenqiran/OneDrive - University of Florida/Nano data analysis/Submission_ACS Nano/new plots",
       width = 12, height = 10, units = "cm", dpi = 320)

ggsave("gold_Cancer_AUC_ID.tiff", scale = 1,
       plot = p.Cancer,
       path = "C:/Users/chenqiran/OneDrive - University of Florida/Nano data analysis/Submission_ACS Nano/new plots",
       width = 14, height = 10, units = "cm", dpi = 320)

ggsave("gold_TS_AUC_ID.tiff", scale = 1,
       plot = p.TS,
       path = "C:/Users/chenqiran/OneDrive - University of Florida/Nano data analysis/Submission_ACS Nano/new plots",
       width = 5, height = 10, units = "cm", dpi = 320)

ggsave("gold_PDI_AUC_ID.tiff", scale = 1,
       plot = p.PDI,
       path = "C:/Users/chenqiran/OneDrive - University of Florida/Nano data analysis/Submission_ACS Nano/new plots",
       width = 10, height = 10, units = "cm", dpi = 320)
