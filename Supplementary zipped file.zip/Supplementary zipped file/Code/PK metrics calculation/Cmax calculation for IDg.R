library(PKNCA)
library(tidyr)

data <- read.csv("R dataset_0713.csv",header=TRUE)
Dataset.no <- na.omit(data[,39])
data <- data %>% fill(Dataset.No.)

Cmax <- matrix(NA, nrow = length(Dataset.no), ncol = 6)

for(i in 1: length(Dataset.no)){

  dataset <- data[data$Dataset.No. == i,23:35]
  colnames(dataset) <- c("time","tumor_IDg","tumor_ID","heart_IDg", "heart_ID",
                         "liver_IDg", "liver_ID","spleen_IDg", "spleen_ID", "lung_IDg",
                         "lung_ID", "kidney_IDg", "kidney_ID")
  Cmax[i,] <- c(Cmax.tumor = pk.calc.cmax(dataset$tumor_IDg),
                Cmax.heart = pk.calc.cmax(dataset$heart_IDg),
                Cmax.liver = pk.calc.cmax(dataset$liver_IDg),
                Cmax.spleen = pk.calc.cmax(dataset$spleen_IDg),
                Cmax.lung = pk.calc.cmax(dataset$lung_IDg),
                Cmax.kidney = pk.calc.cmax(dataset$kidney_IDg))
}
colnames(Cmax) <-c("Cmax.tumor","Cmax.heart","Cmax.liver","Cmax.spleen","Cmax.lung","Cmax.kidney")
saveRDS(Cmax, file = "Cmax results_IDg.RDS")

info <- readRDS("nano info.RDS")

data <- cbind.data.frame(info, Cmax)

Median.all <- median(data$Cmax.tumor)
Mean.all <- mean(data$Cmax.tumor)

#Summary by year
data.year <- data %>% mutate(Year.category = cut(Year, breaks = c(0, 2010, 2016, Inf), labels = c("2005-2009", "2010-2015", "2016-2021"), include.lowest = TRUE, na.rm = TRUE))

Cmax.year <- data.year %>%
  group_by(group = Year.category)%>%
  summarise(count = length(Year),
            Median = median(Cmax.tumor),
            mean = mean(Cmax.tumor),
            p.ANOVA = summary(aov(Cmax.tumor~Year.category, data = data.year))[[1]][["Pr(>F)"]][1])

#Summary by particle type

Cmax.Pt <- data %>% 
  group_by(group = Particle.Type) %>%
  summarize(count = length(Particle.Type),
            Median = median(Cmax.tumor, na.rm = TRUE),
            mean = mean(Cmax.tumor,na.rm = TRUE),
            p.ANOVA = summary(aov(Cmax.tumor~Particle.Type, data = data))[[1]][["Pr(>F)"]][1])


#Summary by targeting strategy

Cmax.TS <- data %>% 
  group_by(group = Targeting.Strategy) %>%
  summarize(count = length(Targeting.Strategy),
            Median = median(Cmax.tumor, na.rm = TRUE),
            mean = mean(Cmax.tumor,na.rm = TRUE),
            p.ANOVA = summary(aov(Cmax.tumor~Targeting.Strategy, data = data))[[1]][["Pr(>F)"]][1])

#Summary by inoranic material

Cmax.INM <- data %>% 
  filter(Particle.Type == "Inorganic")%>%
  group_by(group = INM.category) %>%
  summarize(count = length(INM.category),
            Median = median(Cmax.tumor, na.rm = TRUE),
            mean = mean(Cmax.tumor, na.rm = TRUE),
            p.ANOVA = summary(aov(Cmax.tumor~INM.category, data = data))[[1]][["Pr(>F)"]][1])

#Summary by organic material

data.ONM <- data %>% filter(Particle.Type == "Organic") %>%
  mutate(ONM.category = recode(Organic.Material,
                               "Polymeric" = "Polymeric",
                               "Dendrimer" = "Dendrimer",
                               "Liposome"  = "Liposome",
                               "Hydrogel"  = "Hydrogel",
                               .default    = "ONM others"))

Cmax.ONM <- data.ONM %>%
  filter(Particle.Type == "Organic")%>%
  group_by(group = ONM.category) %>%
  summarize(count = length(ONM.category),
            Median = median(Cmax.tumor, na.rm = TRUE),
            mean = mean(Cmax.tumor, na.rm = TRUE),
            p.ANOVA = summary(aov(Cmax.tumor~ONM.category, data = data.ONM))[[1]][["Pr(>F)"]][1])

#Summary by cancer type

data.cancer <- data %>% mutate(Cancer = recode(Cancer.type,
                                               "Brain"  = "Brain",
                                               "Breast" = "Breast",
                                               "Cervix" = "Cervix",
                                               "Colon"  = "Colon",
                                               "Glioma" = "Glioma",
                                               "Liver"  = "Liver",
                                               "Lung"   = "Lung",
                                               "Ovary"  = "Ovary",
                                               "Pancreas" = "Pancreas",
                                               "Prostate" = "Prostate",
                                               "Sarcoma"= "Sarcoma",
                                               "Skin"   = "Skin",
                                               .default = "Others"))

Cmax.cancer <- data.cancer %>%
  group_by(group = Cancer) %>%
  summarize(count = length(Cancer),
            Median = median(Cmax.tumor, na.rm = TRUE),
            mean = mean(Cmax.tumor, na.rm = TRUE),
            p.ANOVA = summary(aov(Cmax.tumor~Cancer, data = data.cancer))[[1]][["Pr(>F)"]][1])

#Summary by shape

data.shape <- data %>% mutate(Shape = recode(NM.Shape,
                                             "Plate"     = "Plate",
                                             "Rod"       = "Rod",
                                             "Spherical" = "Spherical",
                                             .default    = "Others"))

Cmax.shape <- data.shape %>%
  group_by(group = Shape) %>%
  summarize(count = length(Shape),
            Median = median(Cmax.tumor, na.rm = TRUE),
            mean = mean(Cmax.tumor, na.rm = TRUE),
            p.ANOVA = summary(aov(Cmax.tumor~Shape, data = data.shape))[[1]][["Pr(>F)"]][1])

#Summary by tumor model

Cmax.TM <- data %>%
  group_by(group = Tumor.Model) %>%
  summarize(count = length(Tumor.Model),
            Median = median(Cmax.tumor, na.rm = TRUE),
            mean = mean(Cmax.tumor, na.rm = TRUE),
            p.ANOVA = summary(aov(Cmax.tumor~Tumor.Model, data = data))[[1]][["Pr(>F)"]][1])


#Summary by surface charge

Cmax.zeta <- data %>%
  group_by(group = Surface.Charge) %>%
  summarize(count = length(Surface.Charge),
            Median = median(Cmax.tumor, na.rm = TRUE),
            mean = mean(Cmax.tumor, na.rm = TRUE),
            p.ANOVA = summary(aov(Cmax.tumor~Surface.Charge, data = data))[[1]][["Pr(>F)"]][1])

#Summary by HD
data.HD <- data %>%  mutate(HD.category = cut(NM.Hydrodnamic.Size.nm., breaks = c(0,10,100,200,Inf), labels = c("<10", "10-100", "100-200",">200"),include.lowest = TRUE, na.rm = TRUE))

Cmax.HD <- data.HD %>%
  group_by(group = HD.category) %>%
  summarize(count = length(HD.category),
            Median = median(Cmax.tumor, na.rm = TRUE),
            mean = mean(Cmax.tumor, na.rm = TRUE),
            p.ANOVA = summary(aov(Cmax.tumor~HD.category, data = data.HD))[[1]][["Pr(>F)"]][1])


Results.Cmax.IDg <- rbind.data.frame(Cmax.year, Cmax.TS, Cmax.Pt, Cmax.INM, Cmax.ONM,
                                     Cmax.shape, Cmax.HD, Cmax.zeta, Cmax.TM, Cmax.cancer)

write.csv(Results.Cmax.IDg, "Cmax_IDg_0813.csv")
saveRDS(Results.Cmax.IDg, "Cmax_IDg_0813.RDS")
