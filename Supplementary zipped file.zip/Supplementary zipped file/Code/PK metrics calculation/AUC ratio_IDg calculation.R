library(tidyr)
library(dplyr)
library(PKNCA)

plasma <- readRDS("Plasma_0802.RDS")
Organs <- readRDS("AUC_IDg_0811.RDS")
N <- max(plasma$Dataset.No., na.rm = TRUE)
plasma <- plasma %>% fill(Dataset.No.)
#The calculation of plasma AUC in the unit of %ID/g
AUC.plasma <- rep(NA, N)

for (i in 1:N){
  dataset <- plasma[plasma$Dataset.No.==i,23:25]
  dataset_2 <- dataset[complete.cases(dataset),]
  colnames(dataset_2) <-c("time", "plasma_IDg", "plasma_ID")
  time <- c(0, as.numeric(dataset_2$time))
  plasma_IDg  <- c(0, as.numeric(dataset_2$plasma_IDg))
  if(length(plasma_IDg) == 1){
    AUC.plasma[i] <- NA
  }else{
    AUC.plasma[i] <- pk.calc.auc(conc = plasma_IDg, time = time)
  }
}
AUC.ratio <- Organs/AUC.plasma   #AUC ratio in the unit of %ID/g is Parameter #3

saveRDS(AUC.ratio,"AUC ratio_IDg.RDS")
