library(dplyr)
library(ggplot2)
library(ggdist)
library(ggsci)
library(ggpubr)

DE_ID <- readRDS("AUC_total_0811.RDS")
DE_IDg <- readRDS("AUC ratio_IDg.RDS")
DE_IDg <- as.data.frame(DE_IDg)

heart_ID <- na.omit(cbind(Organ = "Heart", DE = DE_ID$AUC_heart/DE_ID$AUC.plasma))
liver_ID <- na.omit(cbind(Organ = "Liver", DE = DE_ID$AUC_liver/DE_ID$AUC.plasma))
lung_ID  <- na.omit(cbind(Organ = "Lung", DE = DE_ID$AUC_lung/DE_ID$AUC.plasma)) 
spleen_ID <- na.omit(cbind(Organ = "Spleen", DE = DE_ID$AUC_spleen/DE_ID$AUC.plasma))
kidney_ID <- na.omit(cbind(Organ = "Kidney", DE = DE_ID$AUC_kidney/DE_ID$AUC.plasma))

Organs_ID <- rbind.data.frame(heart_ID, liver_ID, lung_ID, spleen_ID, kidney_ID)
Organs.log_ID <- Organs_ID %>% mutate(DE.log = log(as.numeric(DE),10))

p1 <- ggplot(Organs.log_ID,aes(Organ, DE.log))+
  ggdist::stat_halfeye(aes(color = Organ, fill = Organ), adjust = 0.5, width = 0.7, .width = 0, justification = -0.2, point_colour = NA)+
  geom_boxplot(aes(color = Organ),width = 0.2, outlier.shape = NA)+
  geom_jitter(aes(color = Organ), width = 0.05, alpha = 0.2)+
  scale_x_discrete(limits = c("Kidney","Spleen", "Lung", "Liver","Heart" ))+
  coord_flip()+
  scale_color_jco()+
  scale_fill_jco()+
  ylab("Log DC_%ID")+
  xlab("")+
  theme_bw()+
  theme(panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        axis.line.x = element_line(),
        axis.line.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 14, margin = margin(t = 20)),
        axis.title.y = element_text(family = "serif",size = 12),
        axis.text.y = element_text(size = 12, family = "serif", face = "bold"),
        axis.text.x = element_text(size = 12, family = "serif"),
        plot.title = element_text(size = 12, family = "serif"),
        plot.title.position = "plot")+
  theme(legend.position = "none")

heart_IDg <- na.omit(cbind(Organ = "Heart", DE = DE_IDg$AUC_heart))
liver_IDg <- na.omit(cbind(Organ = "Liver", DE = DE_IDg$AUC_liver))
lung_IDg  <- na.omit(cbind(Organ = "Lung", DE = DE_IDg$AUC_lung)) 
spleen_IDg <- na.omit(cbind(Organ = "Spleen", DE = DE_IDg$AUC_spleen))
kidney_IDg <- na.omit(cbind(Organ = "Kidney", DE = DE_IDg$AUC_kidney))

Organs_IDg <- rbind.data.frame(heart_IDg, liver_IDg, lung_IDg, spleen_IDg, kidney_IDg)
Organs.log_IDg <- Organs_IDg %>% mutate(DE.log = log(as.numeric(DE),10))

p2 <- ggplot(Organs.log_IDg,aes(Organ, DE.log))+
  ggdist::stat_halfeye(aes(color = Organ, fill = Organ), adjust = 0.5, width = 0.7, .width = 0, justification = -0.2, point_colour = NA)+
  geom_boxplot(aes(color = Organ),width = 0.2, outlier.shape = NA)+
  geom_jitter(aes(color = Organ), width = 0.05, alpha = 0.2)+
  scale_x_discrete(limits = c("Kidney","Spleen", "Lung", "Liver","Heart" ))+
  coord_flip()+
  scale_color_jco()+
  scale_fill_jco()+
  ylab("Log Distribution Coefficient")+
  xlab("")+
  theme_bw()+
  theme(panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        axis.line.x = element_line(),
        axis.line.y = element_blank())+
  theme(axis.title.x = element_text(family = "serif",size = 14, margin = margin(t = 20)),
        axis.title.y = element_text(family = "serif",size = 12),
        axis.text.y = element_text(size = 12, family = "serif", face = "bold"),
        axis.text.x = element_text(size = 12, family = "serif"),
        plot.title = element_text(size = 12, family = "serif"),
        plot.title.position = "plot")+
  theme(plot.margin = margin(t = 1, unit = "cm"))+
  theme(legend.position = "none")

p.cb <- ggarrange(p1 + rremove("xlab"),p2,
                  ncol = 1, nrow = 2, labels = c("A.", "B."), heights = c(5,6.5),
                  font.label = list(size = 14, face = "bold", family = "serif"))+
  theme(plot.margin = margin(1,1,1,1,"cm"))

ggsave("Figure 5.tiff", scale = 1,
       plot = p.cb,
       path = "C:/Users/chenqiran/Desktop",
       width = 20, height = 30, units = "cm", dpi = 320)
